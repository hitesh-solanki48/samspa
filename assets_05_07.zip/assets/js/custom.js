$(document).ready(function(){
	"use strict";
    /*
  ==============================================================
     STICKY HEADER  Script Start
  ==============================================================
   */
  if($('header').length){
   $(window).scroll(function() {
  	  if ($(this).scrollTop() > 0){  
  		  $('header.absolute').addClass("sticky");
  	  }
  	  else{
  		  $('header').removeClass("sticky");
  	  }
   	 });
  }

    /*
  ==============================================================
     COUNTDOWN  Script Start
  ==============================================================
   */
  if($('.countdown').length){
    $('.countdown').downCount({ date: '08/08/2016 12:00:00', offset: +1 });
  }
    /*
  ==============================================================
     COUNTER  Script Start
  ==============================================================
   */
  if($('.counter').length){
    $('.counter').counterUp({
      delay: 10,
      time: 1000
    });
  }
    /*
  ==============================================================
     SEARCH BAR TOGGLE  Script Start
  ==============================================================
   */
	if($('.show').length){
		$(document).ready(function(){
		  $(".show").on('click',function(){
			$(".searchform").toggle();
		  });
		});
	}
    /*
  ==============================================================
       Banner Bx-Slider Script Start
  ==============================================================
   */
  if($('.bxslider').length){
        jQuery('.bxslider').bxSlider({
            auto: true,
            mode: 'fade',
            pager: false,
            speed: 1000,
            easing:'ease',
            autoDelay: 1000
         });
    }  

    /*
  ==============================================================
       TESTIMONIAL SLIDER Script Start
  ==============================================================
   */
  $(document).ready(function(){
    $('.slider1').bxSlider({
      minSlides: 1,
      maxSlides: 1,
      slideMargin: 0
    });
  });

    /*
  ==============================================================
       BRAND PARTNER SLIDER Script Start
  ==============================================================
   */
  $(function () {
    $('[data-toggle="tooltip"]').tooltip()
  })
    /*
  ==============================================================
      Google Map Function for Custom Style
  ==============================================================
   */

  if($('#map-canvas').length){
      google.maps.event.addDomListener(window, 'load', initialize);
    }
    function initialize() {
      var MY_MAPTYPE_ID = 'custom_style';
      var map;
      var brooklyn = new google.maps.LatLng(40.6743890, -73.9455);
      var featureOpts = [
        {
          stylers: [
          { hue: '#f9f9f9' },     
          { visibility: 'simplified' },
          { gamma: 0.7 },
          { saturation: -200 },
          { lightness: 45 },
          { weight: 0.6 }
          ]
        },
        {
        featureType: "road",
          elementType: "geometry",
          stylers: [
          { lightness: 200 },
          { visibility: "simplified" }
          ]
        },
        {
          elementType: 'labels',
          stylers: [      
          { visibility: 'on' }
          ]
        },
        {
          featureType: 'water',
          stylers: [
          { color: '#ffffff' }
          ]
        }
      ];  
    
      var mapOptions = {
        zoom: 15,
        scrollwheel: false,
        center: brooklyn,
        mapTypeControlOptions: {
          mapTypeIds: [google.maps.MapTypeId.ROADMAP, MY_MAPTYPE_ID]
        },
        mapTypeId: MY_MAPTYPE_ID
      };
    
      map = new google.maps.Map(document.getElementById('map-canvas'),
          mapOptions);
    
      var styledMapOptions = {
        name: 'Custom Style'
      };

      var customMapType = new google.maps.StyledMapType(featureOpts, styledMapOptions);

      map.mapTypes.set(MY_MAPTYPE_ID, customMapType);
        var marker=new google.maps.Marker({
          position:brooklyn,
          icon:'extra-images/map.png'
      });

      marker.setMap(map);
    }

    /*
  ==============================================================
      DL Responsive Menu Script Start
  ==============================================================
   */
  if(typeof($.fn.dlmenu) == 'function'){
		$('#kode-responsive-navigation').each(function(){
		  $(this).find('.dl-submenu').each(function(){
			if( $(this).siblings('a').attr('href') && $(this).siblings('a').attr('href') != '#' ){
			  var parent_nav = $('<li class="menu-item kode-parent-menu"></li>');
			  parent_nav.append($(this).siblings('a').clone());
			  
			  $(this).prepend(parent_nav);
			}
		  });
		  $(this).dlmenu();
		});
  }

  /*
  ==============================================================
      FILTERABLE Script Start
  ==============================================================
   */
  if($('#filterable-item-holder-1').length){
    jQuery(window).load(function($) {
      var filter_container = jQuery('#filterable-item-holder-1');

      filter_container.children().css('position','relative'); 
      filter_container.masonry({
        singleMode: true,
        itemSelector: '.filterable-item:not(.hide)',
        animate: true,
        animationOptions:{ duration: 800, queue: false }
      }); 
      jQuery(window).resize(function(){
        var temp_width =  filter_container.children().filter(':first').width();
        filter_container.masonry({
          columnWidth: temp_width,
          singleMode: true,
          itemSelector: '.filterable-item:not(.hide)',
          animate: true,
          animationOptions:{ duration: 800, queue: false }
        });   
      }); 
      jQuery('ul#filterable-item-filter-1 a').on('click',function(e){ 

        jQuery(this).addClass("active");
        jQuery(this).parents("li").siblings().children("a").removeClass("active");
        e.preventDefault();
        
        var select_filter = jQuery(this).attr('data-value');
        
        if( select_filter == "All" || jQuery(this).parent().index() == 0 ){   
          filter_container.children().each(function(){
            if( jQuery(this).hasClass('hide') ){
              jQuery(this).removeClass('hide');
              jQuery(this).fadeIn();
            }
          });
        }else{
          filter_container.children().not('.' + select_filter).each(function(){
            if( !jQuery(this).hasClass('hide') ){
              jQuery(this).addClass('hide');
              jQuery(this).fadeOut();
            }
          });
          filter_container.children('.' + select_filter).each(function(){
            if( jQuery(this).hasClass('hide') ){
              jQuery(this).removeClass('hide');
              jQuery(this).fadeIn();
            }
          });
        }
        
        filter_container.masonry(); 
        
      });
    });
  }

    /*
  ==============================================================
     Pretty Photo  Script Start
  ==============================================================
   */
  if($("a[data-rel^='prettyPhoto']").length){
    $("a[data-rel^='prettyPhoto']").prettyPhoto();
  }

    /*
  ==============================================================
     Back to Top  Script Start
  ==============================================================
   */
  $(window).scroll(function () {
      if ($(this).scrollTop() > 400) {
          $('.go-up').fadeIn();
      } else {
          $('.go-up').fadeOut();
      }
  });
  $('.go-up').on('click', function () {
      $("html, body").animate({
          scrollTop: 0
      }, 600);
      return false;
  });

})
