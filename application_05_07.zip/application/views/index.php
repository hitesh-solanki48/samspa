<?php include('common/header.php');?>
  
   

    <section class="font-1 py-5">
    <div class="container">
      <div class="row">
        
			<?php include('common/leftmenu.php'); ?>
		
        
        
        <div class="col-lg-9 px-0">
        <div class="container text-center">
        <div class="row mb-6">
        <div class="col">
              <h3 class="fs-2 fs-md-3"> Premium Listing</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
	  
	  <?php 
		
			$CI =& get_instance();
			$CI->load->model('Common_model');
			$getPaidListG = $CI->Common_model->getPaidListG();	
			$getPaidListP = $CI->Common_model->getPaidListP();	
			
			$getFreeList = $CI->Common_model->getFreeList();	
			
			$getServices = $CI->Common_model->getServices();
			
			function limit_words($string, $word_limit){
				$words = explode(" ",$string);
				return implode(" ", array_splice($words, 0, $word_limit));
			}
	  ?>
	  
	  
      <div class="row">
	
		<?php 
		
				if(isset($getPaidListG)){
					foreach($getPaidListG as $val){
			
		
					
		  ?>

        <div class="col-lg-4  mb-3 mt-3 imgp">
    	 <a  class="cuadroa" href="<?php echo base_url(); ?>Category/listing/paid"><div class="cuadro_intro_hover ">
		<p style="text-align:center;">
	    <img src="<?php  echo base_url(); ?>assets/images/add_data/<?php echo $val['image']; ?>" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3><?php echo limit_words( $val['title'],4); ?></h3>
		<p><b>You will enjoy different kinds.</b> </p>
		
        <p class="bgp"><?php echo limit_words($val['description'],10); ?>.</p>
		</div>
		</div>
		</div></a>
		</div>

			<?php }} ?>
			
			
		<?php 
		
				if(isset($getPaidListP)){
					foreach($getPaidListP as $val){
			
		
					
		  ?>

        <div class="col-lg-4  mb-3 mt-3 imgp">
    	 <a  class="cuadroa" href="<?php echo base_url(); ?>Category/listing/paid"><div class="cuadro_intro_hover ">
		<p style="text-align:center;">
	    <img src="<?php  echo base_url(); ?>assets/images/add_data/<?php echo $val['image']; ?>" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3><?php echo limit_words( $val['title'],4); ?></h3>
		<p><b>You will enjoy different kinds.</b> </p>
		
        <p class="bgp"><?php echo limit_words($val['description'],10); ?>.</p>
		</div>
		</div>
		</div></a>
		</div>

			<?php }} ?>

      </div>
      </div>


      <div class="container text-center">

      <div class="row mb-6">
        <div class="col">
              <h3 class="fs-2 fs-md-3">Services</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
    <div data-dots="true" data-nav="true" data-items='{"0":{"items":2},"600":{"items":2}}' data-autoplay="true" data-margin="30" data-loop="true" class="owl-carousel owl-theme owl-nav-outer  owl-dot-round">
          <?php 
		
				if(isset($getServices)){
					foreach($getServices as $val){
			
		//echo '<pre>'; print_r($val);
					
		  ?>
		  <div class="item"><a href="<?php  echo base_url(); ?>Category/index/<?php echo $val['category_id']; ?>"><img src="<?php  echo base_url(); ?>assets/images/category/<?php echo $val['image']; ?>" style="height: 250px;" class="radius-primary"/></a></div>
		<?php }} ?>
        </div>
        </div>



<div class="container text-center mt-5">
          <div class="row mb-6">
        <div class="col">
              <h3 class="fs-2 fs-md-3"> Free Listing</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
      <div class="row">
	
		<?php 
		
				if(isset($getFreeList)){
					foreach($getFreeList as $val){
			
		
					
		  ?>

        <div class="col-lg-4  mb-3 mt-3 imgp">
    	 <a  class="cuadroa" href="<?php echo base_url(); ?>Category/listing/free"><div class="cuadro_intro_hover ">
		<p style="text-align:center;">
	    <img src="<?php  echo base_url(); ?>assets/images/add_data/<?php echo $val['image']; ?>" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3><?php echo limit_words( $val['title'],4); ?></h3>
		<p><b>You will enjoy different kinds.</b> </p>
		
        <p class="bgp"><?php echo limit_words($val['description'],10); ?>.</p>
		</div>
		</div>
		</div></a>
		</div>

			<?php }} ?>

      </div>


      
    </div>






        </div>
      </div>
 </div>
</section>


     

       

<?php include('common/footer.php');?>
     