<?php //include('common/header1.php');?>
      <section class="font-1 p-0  mb-4 mt-4">
    <div class="container">
      <div class="row">
         
        <div class="col-lg-8 m-auto p-3 border">
        <div class="container ">
        <div class="row mb-6 text-center">
        <div class="col">
              <h3 class="fs-2 fs-md-3 color-primary">Free Listing</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
   
         <h5 class="color-primary">List your business for <b>FREE</b> with India's leading local search engine</h5>
         <p>Enter your details below</p>
         
         <form class="zform mt-3">
              <div class="row">

         <div class="col-lg-6 mb-4 mb-lg-4">
         <input class="form-control background-white" type="text" placeholder="Company Name*" required>
        </div>

         <div class="col-lg-6 mb-4 mb-lg-4">
         <input class="form-control background-white" type="text" placeholder="Delhi / NCR" required>
        </div>

         <div class="col-lg-2 mb-4 mb-lg-4">
         <select class="form-control background-white" >
         <option>Title</option>
         <option>Mr</option>
         <option>Mrs</option>
         <option>Ms</option>
         <option>Dr</option>
         </select>
        </div>

         <div class="col-lg-5 mb-4 mb-lg-4">
        <input class="form-control background-white" type="text" placeholder="Name" required>
        </div>

         <div class="col-lg-5 mb-4 mb-lg-4">
         <input class="form-control background-white" type="text" placeholder="Last Name" required>
        </div>

         <div class="col-lg-6 mb-4 mb-lg-4">
        <div class="num"><span>+91</span> <input class="form-control background-white" type="text" placeholder="Mobile No*" required></div> 
        <a href="#" class="pluse"><i class="fa fa-plus"></i></a>
        </div>

         <div class="col-lg-6 mb-4 mb-lg-4">
        <div class="num">
        <div class="dropdown">
  <button class="btn dropdown-toggle" type="button" data-toggle="dropdown">11
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="#">11</a></li>
    <li><a href="#">120</a></li>
  </ul>
</div>

        <input class="form-control background-white" type="text" placeholder="Landline Number" required></div> 
        <a href="#" class="pluse"><i class="fa fa-plus"></i></a>
        </div>


<div class="col-lg-9 mb-4 mb-lg-4">
        <span class="mand">* denotes mandatory fields</span>
        </div>
 <div class="col-lg-3 mb-4 mb-lg-4">
                  <div class="row">
                    <div class="col-auto">
                      <button class="btn btn-md-lg btn-primary" type="Submit"> <span class="color-white fw-600">Submit</span></button>
                    </div>
                    <div class="col">
                      <div class="zform-feedback"></div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
        

      
      </div>


        </div>
      </div>
 </div>
</section>
<?php //include('common/footer1.php');?>

