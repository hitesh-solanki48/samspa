
  
      <section class="font-1 p-0 mt-5 mb-5">
    <div class="container">
      <div class="row">
        
        <div class="col-lg-12">
        <div class="container ">
        <div class="row mb-6 text-center">
        <div class="col">
              <h3 class="fs-2 fs-md-3">Sign Up</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
         <div class="row">

         <div class="col-lg-7 m-auto border">
         <div class="background-white radius-secondary p-2 p-md-5 mt-0" data-zanim="{&quot;delay&quot;:0.1}" style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
            <h4 class="text-uppercase fs-0 fs-md-1">Sign Up with Sam Spa Center</h4>
            <form class="text-left mt-4">
              <div class="row align-items-center">
                <div class="col-12 mb-2 mb-sm-4">
                  <div class="input-group">
                    <div class="input-group-addon background-11 fs-2 icon-box"><span class="fa fa-user"></span></div>
                    <input class="form-control" type="text" placeholder="Your First Name">
                  </div>
                </div>
                <div class="col-12  mb-2 mb-sm-4">
                  <div class="input-group">
                    <div class="input-group-addon background-11 fs-2 icon-box"><span class="fa fa-user"></span></div>
                    <input class="form-control" type="text" placeholder="Your Last Name">
                  </div>
                </div>
                <div class="col-12  mb-2 mb-sm-4">
                  <div class="input-group">
                    <div class="input-group-addon background-11 fs-2 icon-box"><span class="fa fa-envelope"></span></div>
                    <input class="form-control" type="text" placeholder="Your Email">
                  </div>
                </div>
                <div class="col-12  mb-2 mb-sm-4">
                  <div class="input-group">
                    <div class="input-group-addon background-11 fs-2 icon-box"><span class="fa fa-lock"></span></div>
                    <input class="form-control" type="text" placeholder="Password">
                  </div>
                </div>
                <div class="col-12 mb-2 mb-sm-4">
                  <div class="input-group">
                    <div class="input-group-addon background-11 fs-2 icon-box"><span class="fa fa-repeat"></span></div>
                    <input class="form-control" type="text" placeholder="Password">
                  </div>
                </div>
              </div>
              <div class="row align-items-center mb-3">
                <div class="col-8"></div>
                <div class="col-4 mb-2 mb-sm-3">
                  <button class="btn btn-primary " type="submit">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>

      </div>
      </div>


        </div>
      </div>
 </div>
</section>

