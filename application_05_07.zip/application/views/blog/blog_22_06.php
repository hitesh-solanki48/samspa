<?php $this->load->view('common/header1'); ?>
<section class="background-white  px-3 mt-2 ">
    <div class="container">
    <div class="row mb-6 text-center">
        <div class="col">
              <h3 class="fs-2 fs-md-3"> Blog</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
	  <?php //echo '<pre>'; print_r($blogData); ?>
	  <div class="posts">
	  <?php 
			if(isset($blogData)){
				foreach($blogData as $val){
	  ?>
      <div class="row dummy">
       <div class="col-lg-2  mb-3 mt-3"><img src="<?php echo base_url(); ?>assets/newimg/blog/<?php echo $val['image']; ?>" class="img-fluid z-depth-1 rounded-circle" alt="<?php if(isset($val['alt_tag'])){ echo $val['alt_tag']; } else { echo 'image'; } ?>"></div>    
       <div class="col-lg-10  mb-3 mt-3">
       <p><span class="float-right color-danger"><?php echo date("jS \of F Y h:i:s A", strtotime($val['created'])); ?></span></p>
       <p><b><?php echo $val['title']; ?></b></p>
       <p><?php echo $val['description']; ?>.
       <!--<a class="nav-link mt-2 pl-0 color-primary" href="<?php echo base_url(); ?>Blog/blog_desc/<?php echo $val['id']; ?>">Read More</a>-->
       </p>
       </div> 
      </div>
	
      <hr />
	  
			<?php }} ?>
			</div>
		
  <!--/.row--></div>
  
    <!--/.container--></section>
<?php $this->load->view('common/footer1.php');  ?>
<script>

  	var page = 0;
	$(window).scroll(function() {
	    if($(window).scrollTop() + $(window).height() >= $(document).height()) {
	        page++;
	        loadMoreData(page);
	    }
	});

	function loadMoreData(page){
		//var url = '<?php echo base_url(); ?>admin/Page/getSubCategoryByID';
		var dataStr = 'page='+page;
		var url = '<?php echo base_url(); ?>Blog/loadBlog';
		$.ajax({
			url: url,
			type: "post",
			data: dataStr ,
			success: function(response) {
				//alert(response);
				$('.posts').append(response);
				//$('#loading').hide();
			}
		});
		}
	</script>
<script>
		$readMoreJS.init({
			target: '.dummy p',
			numOfWords: 50,
			toggle: true,
			moreLink: 'read more ...',
			lessLink: 'read less'
		});
	</script>