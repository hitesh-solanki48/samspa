<?php $this->load->view('admin/partials/admin_header.php'); ?>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Add Category</h3>
            </div>
        </div>
       

		<div class="row">
            <div class="col-md-8 col-md-offset-2">
            
            <?php echo validation_errors(); ?> 
			<?php //echo '<pre>'; print_r($userRow); ?> 
			<?php echo form_open_multipart('admin/SetUp/edit_category/'.$userRow[0]['category_id']); ?>
                <fieldset>
                    <div class="row">
                        <div class="col-xs-6">
                            <label>Category</label>
						<input type="hidden" name="category_id" value="<?php echo $userRow[0]['category_id']; ?>">                            
                            <input type="text" class="form-control" name="category" value="<?php echo $userRow[0]['category']; ?>">    
                        </div>
                        <div class="col-xs-6">
                            <br>
                            <label for="gear">Status:</label>
                            <select name="status" id="status" class="form-control">
                                <option value="1" <?php if($userRow[0]['status'] == 1){ echo 'selected'; } ?>>Active</option>
                                <option value="0" <?php if($userRow[0]['status'] == 0){ echo 'selected'; } ?>>In Active</option>
                            </select>
                        </div>
						 <div class="col-xs-4">
                        <br>
                            <label for="mileage">Image:</label>
                            <input type="file" class="form-control" value="" name="image"/>
							<input type="hidden" name="image_hidd" value="<?php echo $userRow[0]['image']; ?>">    
                        </div>
                    </div>
					<br>
					<?php if($userRow[0]['image'] != ''){ ?> 
						<div class="row">
							<img src=" <?php echo base_url().'assets/images/category/'. $userRow[0]['image']?>" width="100px" height="100px" />
						</div>
					<?php } ?>
                    <br>
					<div class="row appRow">
					<?php $i = 1; if(!empty($metaDesc)) { foreach($metaDesc as $val){ ?>
						<div class='element' id='div_<?php echo $i; ?>'>
							<div class="col-xs-4">
							<input type="hidden" value="<?php echo $val['meta_id']; ?>" name="meta_id[]">
							<br>
								<label for="mileage">Meta Name:</label>
								<input type="text" value="<?php echo $val['meta_name']; ?>" class="form-control" name="meta_name[]">
							</div>
							<div class="col-xs-6">
							<br>
								<label for="mileage">Meta Description:</label>
								<input type="text" class="form-control" value="<?php echo $val['meta_description']; ?>" name="meta_description[]">
							</div>
							<div class="col-xs-2">
							<br>
								<label for="mileage">Button:</label>
								<span class='add form-control'>+</span>
							</div>
						</div>
					<?php $i++; } } else { ?>
						<div class='element' id='div_1'>
							<div class="col-xs-4">
							<br>
								<label for="mileage">Meta Name:</label>
								<input type="text" class="form-control" name="meta_name[]">
							</div>
							<div class="col-xs-6">
							<br>
								<label for="mileage">Meta Description:</label>
								<input type="text" class="form-control" name="meta_description[]">
							</div>
							<div class="col-xs-2">
							<br>
								<label for="mileage">Button:</label>
								<span class='add form-control'>+</span>
							</div>
						</div>
					<?php } ?>
                    </div>
					<br>
                    <input class="btn btn-primary" type="submit" name="buttonSubmit" value="Add Category" />
                                                            
                </fieldset>         
            </form>
            <br>
           
        </div> <!-- /row --> 

        	
        <!-- all models --> 
        

    </div>
</div> <!-- /.col-right --> 
<!-- /page content -->

<?php $this->load->view('admin/partials/admin_footer.php'); ?>

<script>

$(document).ready(function(){
	$(".add").click(function(){
	var total_element = $(".element").length;
	var lastid = $(".element:last").attr("id");
	var split_id = lastid.split("_");
	var nextindex = Number(split_id[1]) + 1;

	var max = 5;
  
	if(total_element < max ){
   
		$(".element:last").after("<div class='element' id='div_"+ nextindex +"'></div>");
 
		//html ='<div class="row" id="main_div_'+nextindex+'">';
		html ='	<div class="col-xs-4">';
		html +='	<input type="hidden" value="" name="meta_id[]">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Name:</label>';
		html +='		<input type="text" class="form-control" name="meta_name[]">';
		html +='	</div>';
		html +='	<div class="col-xs-6">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Description:</label>';
		html +='		<input type="text" class="form-control" name="meta_description[]">';
		html +='	</div>';
		html +='	<div class="col-xs-2">';
		html +='	<br>';
		html +='		<label for="mileage">Button:</label>';
		html +='		<span id="remove_' + nextindex + '" class="remove form-control">X</span>';
		html +='	</div>';
		//html +='</div>';
		$("#div_" + nextindex).append(html);
  }
 
 });
	
});

$('.appRow').on('click','.remove',function(){
 
  var id = this.id;
  var split_id = id.split("_");
  var deleteindex = split_id[1];

  // Remove <div> with id
  $("#div_" + deleteindex).remove();

 }); 
	function appendDiv(){
		/* var b = "<?php echo $b; ?>";
		b++;
		html ='<div class="row" id="main_div_'+b+'">';
		html +='	<div class="col-xs-4">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Name:</label>';
		html +='		<input type="text" class="form-control" name="meta_name[]">';
		html +='	</div>';
		html +='	<div class="col-xs-6">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Description:</label>';
		html +='		<input type="text" class="form-control" name="meta_description">';
		html +='	</div>';
		html +='	<div class="col-xs-2">';
		html +='	<br>';
		html +='		<label for="mileage">Button:</label>';
		html +='		<button id="remove_button_'+b+'" class="form-control" onclick="removeDiv();" name="remove_button" >Add</button>';
		html +='	</div>';
		html +='</div>'; */
		
	}
</script>

<?php if($this->session->flashdata('message') != NULL) : ?>
    <script>
        swal({
          title: "Success",
          text: "<?php echo $this->session->flashdata('message'); ?>",
          type: "success",
          timer: 1500,
          showConfirmButton: false
        });
    </script>
<?php endif ?>


<?php if($this->session->flashdata('message') != NULL) : ?>
<script>
    swal({
      title: "Success",
      text: "<?php echo $this->session->flashdata('message'); ?>",
      type: "success",
      timer: 1500,
      showConfirmButton: false
    });
</script>
<?php endif ?>