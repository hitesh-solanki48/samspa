<?php $this->load->view('admin/partials/admin_header.php'); ?>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Edit Policy</h3>
            </div>
        </div>
       

		<div class="row">
            <div class="col-md-8 col-md-offset-2">
            
            <?php echo validation_errors(); ?> 
			<?php //echo '<pre>'; print_r($userRow); die; ?> 
			<?php echo form_open_multipart('admin/Page/edit_policy/'.$userRow[0]['id']); ?>
                <fieldset>
                    <div class="row">
                        <div class="col-xs-4">
                            <label>Title</label>
							
							<input type="hidden" name="id" value="<?php echo $userRow[0]['id']; ?>">                            
                            <input type="text" class="form-control" name="title" value="<?php echo $userRow[0]['title']; ?>">    
                        </div>
						<div class="col-xs-4">
                            
                            <label for="gear">Policy Type:</label>
                            <select name="type" id="type" class="form-control">
                                <option value="1" <?php if($userRow[0]['type'] == 1){ echo 'selected'; } ?>>Policy Term </option>
                                <option value="2" <?php if($userRow[0]['type'] == 2){ echo 'selected'; } ?>>Term & Condition</option>
                            </select>
                        </div>
						<div class="col-xs-4">
                            
                            <label for="gear">Status:</label>
                            <select name="status" id="status" class="form-control">
                                <option value="1" <?php if($userRow[0]['status'] == 1){ echo 'selected'; } ?>>Active</option>
                                <option value="0" <?php if($userRow[0]['status'] == 0){ echo 'selected'; } ?>>In Active</option>
                            </select>
                        </div>
                        
                    </div>
                            
                    <br>
                    <div class="row">
                       
                        <div class="col-xs-12">
                            <label>Description</label>
							<textarea id="description" name="description" rows="8" class="form-control"><?php echo $userRow[0]['description']; ?></textarea>	
                        </div>
                       
						
                        
                    </div>
					
                    <br>
                    <input class="btn btn-primary" type="submit" name="buttonSubmit" value="Add Faq" />
                                                            
                </fieldset>         
            </form>
            <br>
           
        </div> <!-- /row --> 

        	
        <!-- all models --> 
        

    </div>
</div> <!-- /.col-right --> 
<!-- /page content -->

<?php $this->load->view('admin/partials/admin_footer.php'); ?>



<?php if($this->session->flashdata('message') != NULL) : ?>
    <script>
        swal({
          title: "Success",
          text: "<?php echo $this->session->flashdata('message'); ?>",
          type: "success",
          timer: 1500,
          showConfirmButton: false
        });
    </script>
<?php endif ?>
<!--
    <script src="<?php echo base_url("assets/vendors/datatables.net/js/jquery.dataTables.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/buttons.flash.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/buttons.html5.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/buttons.print.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-scroller/js/datatables.scroller.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/jszip/dist/jszip.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/pdfmake/build/pdfmake.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/pdfmake/build/vfs_fonts.js"); ?>"></script>
    
    -->

<?php if($this->session->flashdata('message') != NULL) : ?>
<script>
    swal({
      title: "Success",
      text: "<?php echo $this->session->flashdata('message'); ?>",
      type: "success",
      timer: 1500,
      showConfirmButton: false
    });
</script>
<?php endif ?>