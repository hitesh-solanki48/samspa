<?php $this->load->view('admin/partials/admin_header.php'); ?>
<style>
.error {
color:red;
font-size:13px;
margin-bottom:-15px
}
</style>
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Add Post</h3>
            </div>
        </div>
       
	<?php 
		$sesData = $this->session->userdata; 
		
		if($sesData['type'] == 'user'){
			if($setData['user_type'] == 'pu'){
				$post_type = 'p';
				if($setData['pkg_type'] == 'g'){
					$pkg_type = 'gp';
				} else {
					$pkg_type = 'pp';
				}
			} else {
				$post_type = 'f';
				$pkg_type = 'fp';
			}
		} else {
			$post_type = 'p';
			$pkg_type = 'pp';
		}
		
	?>
		<div class="row">
            <div class="col-md-8 col-md-offset-2">
            
            <?php  //echo '<pre>'; print_r($udata);  //echo validation_errors(); ?> 
			<?php echo form_open_multipart('admin/Page/add_add_data'); ?>
                <fieldset>
                    <div class="row">
						<div class="col-xs-6">
						 <br>
                            <label>Category</label> 
							<input type="hidden" name="user_id" value="<?php echo $sesData['id']; ?>">
							<input type="hidden" name="post_pack" value="<?php echo $pkg_type; ?>">
							<input type="hidden" name="post_type" value="<?php echo $post_type; ?>">							
                            <select name="category_id" onchange="getSubCat(this.value);" id="category_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($category as $val){  ?>
								<option value="<?php echo $val['category_id']; ?>"><?php echo $val['category']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
						<div class="col-xs-6">
						 <br>
                            <label>Sub Category</label>                            
                            <select name="sub_category_id" id="sub_category_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($subCategory as $val){  ?>
								<option value="<?php echo $val['sub_category_id']; ?>"><?php echo $val['sub_category']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
						
					</div>
					<div class="row">
						<div class="col-xs-4">
                            <label>Country Name</label>                            
                            <select name="country_id" id="country_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($countList as $val){  ?>
								<option value="<?php echo $val['country_id']; ?>"><?php echo $val['country_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
						<div class="col-xs-4">
                            <label>State Name</label>                            
                            <select name="state_id" id="state_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($stateList as $val){  ?>
								<option value="<?php echo $val['state_id']; ?>"><?php echo $val['state_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
						<div class="col-xs-4">
                            <label>City Name</label>                            
                            <select name="city_id" id="city_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($cityList as $val){  ?>
								<option value="<?php echo $val['city_id']; ?>"><?php echo $val['city_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
					</div>
					<div class="row">
						<!--<div class="col-xs-4">
						 <br>
                            <label>City/Country</label>                            
                            <select name="city_country_id" id="city_country_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($countCity as $val){  ?>
								<option value="<?php echo $val['city_country_id']; ?>"><?php echo $val['title']; ?></option>
                                <?php } ?>
                            </select>
                        </div>-->
						<div class="col-xs-4">
						 <br>
                            <label>Title</label>                            
                            <input type="text" class="form-control" name="title" value=""> 
							<br>
							<?php echo form_error('title'); ?>	
                        </div>
                       
                        <div class="col-xs-4">
                        <br>
                            <label for="mileage">Image:</label>
                            <input type="file" class="form-control" name="image" >
                        </div>
						
					</div>
					<div class="row">
					
                        <div class="col-xs-4">
						 <br>
                            <label>Contact Person</label>                            
                            <input type="text" class="form-control" name="contact_person" value="">    
                        </div>
                       
                        <div class="col-xs-4">
                        <br>
                            <label for="mileage">Phone:</label>
                            <input type="text" class="form-control" name="cont_number" >
                        </div>
						
						<div class="col-xs-4">
                            <br>
                            <label for="gear">Status:</label>
                            <select name="status" id="status" class="form-control">
                                <option value="1">Active</option>
                                <option value="0">In Active</option>
                            </select>
                        </div>
                    </div>
					<div class="row">
					
                        <div class="col-xs-4">
						 <br>
                            <label>Email</label>                            
                            <input type="text" class="form-control" name="email" value="">    
                        </div>
                       
                        <!--<div class="col-xs-4">
                        <br>
                            <label for="mileage">Map Link:</label>
                            <input type="text" class="form-control" name="map_link">
                        </div>-->
						<div class="col-xs-4">
                        <br>
                            <label for="mileage">Location:</label>
                            <input type="text" class="form-control" placeholder="west mumbai" name="location" >
                        </div>
						
                        <div class="col-xs-4">
						 <br>
                            <label>Alt Tag Image</label>                            
                            <input type="text" class="form-control" name="alt_tag" value="">    
                        </div>
                    </div>
					<div class="row">
					
						<div class="col-xs-4">
						 <br>
                            <label>Com. Address</label>                            
                            <input type="text" class="form-control" name="address" value="">    
                        </div>
                       
                        
                    </div>
					<div class="row">
					
                       <div class="col-xs-12">
						 <br>
                            <label>Description</label>                            
                            <textarea class="form-control" name="description"></textarea>    
                        </div>
                        
                    </div>
					<div class="row">
					
                        <div class="col-xs-4">
						 <br>
                            <label>Page Title</label>                            
                            <input type="text" class="form-control" name="page_title" value="">    
                        </div>
						<div class="col-xs-4">
						 <br>
                            <label>Meta Title</label>                            
                            <input type="text" class="form-control" name="meta_title" value="">    
                        </div>
						<div class="col-xs-4">
						 <br>
                            <label>Meta type</label>                            
                            <select name="type" id="type" class="form-control">
                                <option value="0">--select--</option>
								<option value="1">city</option>
                                <option value="2">country</option>
								<option value="3">state</option>
                            </select>    
                        </div>
                       
						
                    </div>
					<div class="row appRow">
						<div class='element' id='div_1'>
							<div class="col-xs-4">
							<br>
								<label for="mileage">Meta Name:</label>
								<input type="text" class="form-control" name="meta_name[]">
							</div>
							<div class="col-xs-6">
							<br>
								<label for="mileage">Meta Description:</label>
								<input type="text" class="form-control" name="meta_description[]">
							</div>
							<div class="col-xs-2">
							<br>
								<label for="mileage">Button:</label>
								<span class='add form-control'>+</span>
							</div>
						</div>
                    </div>
					
                    <br>
					<input class="btn btn-primary" type="submit" name="buttonSubmit" value="Add Post" />
                                                            
                </fieldset>         
            </form>
            <br>
           
        </div> <!-- /row --> 

        	
        <!-- all models --> 
        

    </div>
</div> <!-- /.col-right --> 
<!-- /page content -->


<?php $this->load->view('admin/partials/admin_footer.php'); ?>



<?php if($this->session->flashdata('message') != NULL) : ?>


    <script>
        swal({
          title: "Success",
          text: "<?php echo $this->session->flashdata('message'); ?>",
          type: "success",
          timer: 1500,
          showConfirmButton: false
        });
    </script>
<?php endif ?>
<!--
    <script src="<?php echo base_url("assets/vendors/datatables.net/js/jquery.dataTables.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/buttons.flash.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/buttons.html5.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/buttons.print.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-scroller/js/datatables.scroller.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/jszip/dist/jszip.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/pdfmake/build/pdfmake.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/pdfmake/build/vfs_fonts.js"); ?>"></script>
    
    -->

<script>
	function getSubCat(cat_id){
		var dataStr = 'cat_id='+cat_id;
		var url = '<?php echo base_url(); ?>admin/Page/getSubCategoryByID';
		 $.ajax({
			url: url,
			type: "post",
			data: dataStr ,
			success: function (response) {
				$("#sub_category_id").html(response);
				
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
		});
	}
</script>
<script>

$(document).ready(function(){
	$(".add").click(function(){
	var total_element = $(".element").length;
	var lastid = $(".element:last").attr("id");
	var split_id = lastid.split("_");
	var nextindex = Number(split_id[1]) + 1;

	var max = 5;
  
	if(total_element < max ){
   
		$(".element:last").after("<div class='element' id='div_"+ nextindex +"'></div>");
 
		html ='<div class="row" id="main_div_'+nextindex+'">';
		html +='	<div class="col-xs-4">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Name:</label>';
		html +='		<input type="text" class="form-control" name="meta_name[]">';
		html +='	</div>';
		html +='	<div class="col-xs-6">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Description:</label>';
		html +='		<input type="text" class="form-control" name="meta_description[]">';
		html +='	</div>';
		html +='	<div class="col-xs-2">';
		html +='	<br>';
		html +='		<label for="mileage">Button:</label>';
		html +='		<span id="remove_' + nextindex + '" class="remove form-control">X</span>';
		html +='	</div>';
		html +='</div>';
		$("#div_" + nextindex).append(html);
  }
 
 });
	
});

$('.appRow').on('click','.remove',function(){
 
  var id = this.id;
  var split_id = id.split("_");
  var deleteindex = split_id[1];

  // Remove <div> with id
  $("#div_" + deleteindex).remove();

 }); 
	function appendDiv(){
		/* var b = "<?php echo $b; ?>";
		b++;
		html ='<div class="row" id="main_div_'+b+'">';
		html +='	<div class="col-xs-4">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Name:</label>';
		html +='		<input type="text" class="form-control" name="meta_name[]">';
		html +='	</div>';
		html +='	<div class="col-xs-6">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Description:</label>';
		html +='		<input type="text" class="form-control" name="meta_description">';
		html +='	</div>';
		html +='	<div class="col-xs-2">';
		html +='	<br>';
		html +='		<label for="mileage">Button:</label>';
		html +='		<button id="remove_button_'+b+'" class="form-control" onclick="removeDiv();" name="remove_button" >Add</button>';
		html +='	</div>';
		html +='</div>'; */
		
	}
</script>
	
<?php if($this->session->flashdata('message') != NULL) : ?>
<script>
    swal({
      title: "Success",
      text: "<?php echo $this->session->flashdata('message'); ?>",
      type: "success",
      timer: 1500,
      showConfirmButton: false
    });
</script>
<?php endif ?>