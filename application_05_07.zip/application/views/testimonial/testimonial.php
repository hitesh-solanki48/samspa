
  <section class="font-1 p-0 mt-4">
    <div class="container">
      <div class="row">
         <div class="col-lg-3">

          <div class="vertical-menu">
          <h5>Also Listed in</h5>
          <hr class="color-9 my-2">
            <ul>
              <li><a href="<?php echo base_url(); ?>Contact_Us">Contact Us</a></li>
              <li><a href="<?php echo base_url(); ?>Blog">Blog</a></li>
              <li><a href="<?php echo base_url(); ?>Faq">FAQ</a></li>
              <li><a href="<?php echo base_url(); ?>Testimonial">Testimonial</a></li>
              <li><a href="<?php echo base_url(); ?>Feedback">Feedback</a></li>
              <li><a href="<?php echo base_url(); ?>Business_Badge">Business Badge</a></li>

            </ul>
          </div>
          
       


        </div>




        <div class="col-lg-9 pl-lg-3">
          <div class="row pb-3 align-items-center">
            <div class="col">
              <p class="mb-0"><strong>Testimonial </strong></p>
            </div>
          </div>
            <div id="demo2" class="tabcontent">
  <div class="row">

 <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>

  <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>

  <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="<?php echo base_url(); ?>assets/images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>



  <div class="col-sm-12 businfo seoshow ">
								<p class="heading lng_commn_all">Business Information</p>
								<span class="detl lng_commn_all"><h6>Rose Body Massage in Chakkarpur, Delhi</h6><p>Rose Body Massage in Delhi. Massage Services For Men At Home with Address, Contact Number, Photos, Maps. View Rose Body Massage, Delhi on Justdial.</p>
				<p></p><h6>Location and Overview:</h6><p></p>
				<p>Established in the year 2013, Rose Body Massage in Chakkarpur, Delhi is a top player in the category Massage Services For Men At Home in the Delhi. This well-known establishment acts as a one-stop destination servicing customers both local and from other parts of Delhi. Over the course of its journey, this business has established a firm foothold in it�s industry. The belief that customer satisfaction is as important as their products and services, have helped this establishment garner a vast base of customers, which continues to grow by the day. This business employs individuals that are dedicated towards their respective roles and put in a lot of effort to achieve the common vision and larger goals of the company. In the near future, this business aims to expand its line of products and services and cater to a larger client base. In Delhi, this establishment occupies a prominent location in Chakkarpur. It is an effortless task in commuting to this establishment as there are various modes of transport readily available. It is at 0, Near Galleria Market, which makes it easy for first-time visitors in locating this establishment. The popularity of this business is evident from the 90+ reviews it has received from Justdial users. It is known to provide top service in the following categories: Massage Services For Men At Home, Body Massage Centres, 24 Hours Body Massage Centres. </p>

				<p></p><h6>Products and Services offered:</h6><p></p>
				<p>Rose Body Massage in Chakkarpur has a wide range of products and services to cater to the varied requirements of their customers. The staff at this establishment are courteous and prompt at providing any assistance. They readily answer any queries or questions that you may have. Pay for the product or service with ease by using any of the available modes of payment, such as Cash, Master Card, Visa Card, Debit Cards, Cheques, American Express Card, Credit Card. This establishment is functional from 00:00 - 23:59. </p><p>Please scroll to the top for the address and contact details of Rose Body Massage at Chakkarpur, Delhi. </p></span>
								<!-- </section> -->
							</div>
  </div>
</div>


          </div>

         
        </div>
      </div>
      <!--/.row-->
    <!--/.container--></section>
