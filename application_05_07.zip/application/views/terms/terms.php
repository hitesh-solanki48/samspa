﻿  <section class="background-white  px-3 mt-2">
    <div class="container">
      <?php if(isset($termsData[0]['title']) && isset($termsData[0]['description'])){ ?>
      <div class="row mt-2">
        <div class="col">
          <h3 class="text-center fs-2 fs-md-3"><?php echo $termsData[0]['title']; ?></h3>
          <hr class="short" data-zanim='{"from":{"opacity":0,"width":0},"to":{"opacity":1,"width":"4.20873rem"},"duration":0.8}' data-zanim-trigger="scroll"/>
        </div>
        <div class="col-12">
			<div>
			<?php echo $termsData[0]['description']; ?>
			</div>
        </div>
      </div>
      <?php } ?>
      <!--/.row--></div>
    <!--/.container--></section>
