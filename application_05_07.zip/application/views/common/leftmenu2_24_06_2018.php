 <div class="col-lg-3">
          <h5>Sam Spa</h5>
          <hr class="color-9 my-2">
          <div class="row p-3">
          <div class="col-lg-4 m-0 p-1"><img src="<?php echo base_url(); ?>assets/images/Premium-1.jpg"/></div>
          <div class="col-lg-4 m-0 p-1"><img src="<?php echo base_url(); ?>assets/images/Premium-2.jpg" /></div>
          <div class="col-lg-4 m-0 p-1"><img src="<?php echo base_url(); ?>assets/images/Premium-3.jpg" /></div>
          <div class="col-lg-4 m-0 p-1"><img src="<?php echo base_url(); ?>assets/images/Premium-4.jpg" /></div>
          
          </div>

            <div class="color-5 mt-2"><a class="color-5 fs--1" href="#"> <span class="fa fa-volume-control-phone mr-1"></span>+91-0000 000 000</a></div>
              <div class="color-5 mt-2"> <span class="fa fa-location-arrow mr-1"></span><span class="color-5 fs--1" >281, East Of Kailash, delhi - 110065, Iskcon Temple (Map)</span></div>
              <div class="color-5 mt-2 mb-4"><a class="color-5 fs--1" href="#"> <span class="fa fa-arrow-circle-right mr-1"></span>Body Massage Centres	, Beauty Spas ...more</a></div>
            
            <h5>Hours of Operation (Show less)</h5>
            <hr class="color-9 my-2">
            <table class="table mb-4">
            <tr>
            <td>Monday Open</td>
            <td>24 Hrs</td>
            </tr>
            <tr>
            <td>Tuesday Open</td>
            <td>24 Hrs</td>
            </tr>

            <tr>
            <td>Wednesday Open</td>
            <td>24 Hrs</td>
            </tr>

            <tr>
            <td>Thursday Open</td>
            <td>24 Hrs</td>
            </tr>

            <tr>
            <td>Friday Open</td>
            <td>24 Hrs</td>
            </tr>

            <tr>
            <td>Saturday Open</td>
            <td>24 Hrs</td>
            </tr>

            <tr>
            <td>Sunday Open</td>
            <td>24 Hrs</td>
            </tr>
            </table>

            
          
          
          <div class="vertical-menu">
          <h5>Also Listed in</h5>
          <hr class="color-9 my-2">
            <ul>
              <li><a href="all-area.html">All Area</a></li>
              <li><a href="gurgaon.html">Gurgaon</a></li>
              <li><a href="new-delhi.html">New Delhi</a></li>
              <li><a href="rohini.html">Rohini</a></li>
              <li><a href="#">kaLaxmi Nagar</a></li>
              <li><a href="#">Karol Bagh</a></li>
              <li><a href="#">Connaught Place</a></li>
              <li><a href="#">Poorvi Pitampura</a></li>
              <li><a href="#">Uttam Nagar</a></li>
            </ul>
          </div>
          
          <div class="vertical-menu">
          <h5>Services</h5>
          <hr class="color-9 my-2">
            <ul>
              <li><a href="#">Thai Therapies</a></li>
              <li><a href="#">Facials</a></li>
              
            </ul>
          </div>

         
          <div class="vertical-menu">
           <h5>Modes of Payment</h5>
          <hr class="color-9 my-2">
            <ul>
              <li><a href="#">Cash</a></li>
              <li><a href="#">Debit Cards</a></li>
              <li><a href="#">Cheques</a></li>
              <li><a href="#">American Express Card</a></li>
              <li><a href="#">Credit Card</a></li> 
             
              </ul>
          </div>

          
          <div class="vertical-menu">
          <h5>Year Established</h5>
          <hr class="color-9 my-2">
            <ul>
              <li><a href="#">2018</a></li>
                            
            </ul>
          </div>




        </div>




        