<!DOCTYPE html>
<html lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--  -->
<!--    Document Title-->
<!-- =============================================-->

<!--  -->
<!--    Favicons-->
<!--    =============================================-->


<?php 
	
	$getController = $this->router->fetch_class();
	$getMethod = $this->router->fetch_method();
	$id = $this->uri->segment(3);
	
	if($getController = 'Category' && $getMethod = 'Book_Details'){
	 
		
			$CI =& get_instance();
			$CI->load->model('Common_model');
			$getAllMetaCat = $CI->Common_model->getAllMetaPostByID($id);
			$getPostByID = $CI->Common_model->getPostByID($id);			
			if(isset($getAllMetaCat)){
			foreach($getAllMetaCat as $valCat){
				
	  ?>
		<meta name="<?php echo $valCat['meta_name']; ?>" content="<?php echo $valCat['meta_description']; ?>">
		
  <?php 
			}
		}
  
	}
	
	
	
 ?>
<title><?php echo $getPostByID[0]['page_title']; ?></title> <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<meta name="theme-color" content="#ffffff">

<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
<!-- Template specific stylesheets-->
<link href="<?php echo base_url(); ?>assets/css/loaders.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/iconsmind.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/ionicons.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/hamburgers.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/css/owl.carousel.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/owl.theme.default.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/remodal.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/remodal-default-theme.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/flexslider.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/lightbox.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/StyleSheet.css" rel="stylesheet" type="text/css" />
<!--<link href="<?php echo base_url(); ?>assets/css/demo-style.css" rel="stylesheet" type="text/css" />-->
<!-- Main stylesheet and color file-->
<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
<!--    <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet">-->
<style type="text/css">
iframe#_hjRemoteVarsFrame {
	display: none !important;
	width: 1px !important;
	height: 1px !important;
	opacity: 0 !important;
	pointer-events: none !important;
}
</style>
</head>
<body data-spy="scroll"  data-offset="60">
    <main class=" box-shadow-wide">

    <div class="main-box">
   
    <section class="font-1 p-0">
    <div class="container">
     <div class="znav-white znav-container sticky-top navbar-samspa p-2" id="znav-container">
    
          <nav class="navbar navbar-expand-lg"><a class="navbar-brand overflow-hidden pr-3 mr-2" href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/SamSpa.png" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger hamburger--emphatic">
          <div class="hamburger-box">
                <div class="hamburger-inner"></div>
              </div>
        </div>
            </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <ul class="navbar-nav fs-0 fw-700">
              <li>
              <div class="search-box">
              <input type="text"  placeholder="Beauty-Parlours" autocomplete="OFF" value="" />
              <button class="search-button" ><i class="fa fa-search"></i></button>
              </div></li>
             <li ><a href="<?php echo base_url(); ?>Free_Listing">Free Listing</a></li>
            <li><a href="<?php echo base_url(); ?>Advertise">Advertise</a></li>
            <li class="has-dropdown"><a href="#">Language</a>
            <ul class="dropdown fs--1">
            <li><a href="<?php echo base_url(); ?>">Hindi</a></li>
            <li><a href="<?php echo base_url(); ?>">English</a></li>
             </ul>
                </li>
            <li><a href="<?php echo base_url(); ?>Users/Login">Login</a> </li>
            <li><a class="d-block" href="<?php echo base_url(); ?>Users/Signup">Signup</a></li>
            </ul>
              
            </div>
      </nav>
        
  </div>

  <div class="flexslider flexslider-simple">
  <?php //echo '<pre>'; print_r($getPostByID); ?>
  <img src="<?php echo base_url(); ?>assets/images/add_data/<?php echo $getPostByID[0]['image']; ?>" height="320px;" />
  <div id="fixedbg">
  <div class="col-sm-6 color-1">
  <p class="lead color-primary fw-600"><?php echo $getPostByID[0]['title']; ?><span class="share"><i class="fa fa-share-alt-square"></i></span></p>
  <div class="color-warning"><span class="fa fa-star mr-1 color-warning"></span><span class="fa fa-star mr-1 color-warning"></span><span class="fa fa-star mr-1 color-warning"></span><span class="fa fa-star mr-1 color-warning"></span><span class="fa fa-star mr-1 color-warning"></span></div>
  <div class="color-5 mt-2">
  <?php 
 
		   $str = $getPostByID[0]['description'];
			$string = strip_tags($str);
			if (strlen($string) > 40) { $stringCut = substr($string, 0, 40);$string = substr($stringCut, 0, strrpos($stringCut, ' '));}
			

	?>
		<a class="color-5 fs--1" href="<?php echo base_url(); ?>Category/Book_Details/<?php echo $getPostByID[0]['post_id']; ?>"> 
			<span class="fa fa-address-book mr-1"></span><?php echo $string; ?>..
		</a> | <a class="color-5 fs--1" href="<?php echo base_url(); ?>Category/Book_Details/<?php echo $getPostByID[0]['post_id']; ?>">More</a></div>
  <div class="color-5 mt-2"><a class="color-5 fs--1" href="#"> <span class="fa fa-volume-control-phone mr-1"></span><?php echo $getPostByID[0]['cont_number']; ?></a></div>  
  <div class="color-5 mt-2"><a class="color-5 fs--1" href="#"> <span class="fa fa-whatsapp mr-1"></span>Message on WhatsApp</a></div>
  </div>


  <div class="row mt-3 p-5">
  <div class="col-lg-2 text-center">
  <a href="#">
	<span class="ico-mapicn"><i class="fa fa-map-marker"></i></span>
	<span class="wrtrvtxt">Map</span>
	</a>
  </div>
  <div class="col-lg-2 text-center">
  <a href="#">
	<span class="ico-mapicn"><i class="fa fa-envelope-o"></i></span>
	<span class="wrtrvtxt">SMS/Email</span>
	</a>
  </div>
<div class="col-lg-2 text-center">
  <a href="#">
	<span class="ico-mapicn"><i class="fa fa-pencil-square"></i></span>
	<span class="wrtrvtxt">Write a Review</span>
	</a>
  </div>

  <div class="col-lg-2 text-center">
  <a href="#">
	<span class="ico-mapicn"><i class="fa fa-pencil-square-o"></i></span>
	<span class="wrtrvtxt">Edit This</span>
	</a>
  </div>

  <div class="col-lg-2 text-center">
  <a href="#">
	<span class="ico-mapicn"><i class="fa fa-user"></i></span>
	<span class="wrtrvtxt">Manage Campaign</span>
	</a>
  </div>

  <div class="col-lg-2 text-center">
  <a href="#">
	<span class="ico-mapicn"><i class="fa fa-hand-o-right"></i></span>
	<span class="wrtrvtxt">Jd Verified</span>
	</a>
  </div>

  
  </div>
  </div>
  </div>
    </div>
 </section>



