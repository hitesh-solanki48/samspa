<footer style="background-color: #f6c42d;">
      <div class="container">
          <div class="row align-items-center">



          <div class="col-sm-6 col-lg-9 color-white ml-lg-auto">
              <ul class="list-unstyled">
                <li class="mb-3"><a class="color-white" href="<?php  echo base_url(); ?>Contact_Us">Contact Us</a></li>
                <li class="mb-3"><a class="color-white" href="<?php  echo base_url(); ?>Blog">Blog</a></li><li class="mb-3"><a class="color-white" href="<?php  echo base_url(); ?>Faq">FAQ</a></li>
                <li class="mb-3"><a class="color-white" href="<?php  echo base_url(); ?>Testimonial">Testimonial</a></li>
                <li class="mb-3"><a class="color-white" href="<?php  echo base_url(); ?>Feedback">Feedback</a></li><li class="mb-3"><a class="color-white" href="<?php  echo base_url(); ?>Business_Badge">Business Badge</a></li>
               
                
              </ul>  
              <div class="clearfix"></div>
              <hr />
			  
              <p>
				<?php
				
				$CI =& get_instance();
				$CI->load->model('Common_model');
				$getCityList = $CI->Common_model->getCityListFooter();	
					if(isset($getCityList)){
						foreach($getCityList as $val){
				?>
				<a href="<?php echo base_url(); ?>Category/city/<?php echo $val['city_id']; ?>"><?php echo $val['city_name']; ?></a> / 
				<?php 
						}
					}
				?>
			  </p>

        
          </div>
           
            <div class="col-sm-6 col-lg-3 ">
            <img src="<?php  echo base_url(); ?>assets/images/visa.jpg" style="width:100%" />
            <div class="clearfix"></div>
            <br />

            <div class="socilbg">
              <a href="<?php  echo base_url(); ?>#">

                  <div class="background-primary text-center d-flex align-items-center radius-primary" style="height: 40px; width: 40px; float:right; margin-right:5px;"><span class="w-100 fa fa-linkedin color-warning"></span></div>
           
              </a>
              <a href="<?php  echo base_url(); ?>#">
          
                  <div class="background-primary text-center d-flex align-items-center radius-primary" style="height: 40px; width: 40px; float:right; margin-right:5px;"><span class="w-100 fa fa-twitter color-warning"></span></div>
              
              </a><a href="<?php  echo base_url(); ?>#">
              
                  <div class="background-primary text-center d-flex align-items-center radius-primary" style="height: 40px; width: 40px; float:right; margin-right:5px;"><span class="w-100 fa fa-facebook color-warning"></span></div>
               
              </a><a href="<?php  echo base_url(); ?>#">
       
                  <div class="background-primary text-center d-flex align-items-center radius-primary" style="height: 40px; width: 40px; float:right; margin-right:5px;"><span class="w-100 fa fa-google-plus color-warning"></span></div>
              
              </a>
            
            </div>
            </div>
      </div>

</div>
</footer>

  <section class="fpm">
   <div class="container">

<p class="fp">Spa Company is one of the best and leading companies in India known for delivering the quality services. It gives the unique experience to the clients by our special treatment and massage therapies. Spa experts of our company have designed natural treatments where you will come across with different herbal and ancient techniques, which gives the best mode in the field of relaxation. Our Spa experts are trained and professionals who provide customized services according to the customers need. These experts are friendlier in nature and solve the problem of the clients in an effective way.</p>
  </div>
    </section>
  
  
      <section class="background-primary text-center py-4">
    <div class="container">
          <div class="row align-items-center" style="opacity: 0.85;">
        <div class="col-sm-3 text-sm-left"><!--<a href="<?php  echo base_url(); ?>#"><img src="<?php  echo base_url(); ?>assets/<?php  echo base_url(); ?>assets/<?php  echo base_url(); ?>assets/<?php  echo base_url(); ?>assets/<?php  echo base_url(); ?>assets/images/logo-light.png" alt=""></a>--></div>
        <div class="col-sm-6 mt-3 mt-sm-0">
              <p class="color-warning lh-6 mb-0 fw-600 cp">&copy; Copyright 2018 Sam Spa Center &nbsp;&nbsp;&nbsp;<a class="color-warning" href="<?php  echo base_url(); ?>Privacy_Policy">Privacy Policy</a> | <a class="color-warning " href="<?php  echo base_url(); ?>Terms">Terms of Use</a></p> 
            </div>
        <div class="col text-sm-right mt-3 mt-sm-0"><!--<a class="color-white" href="<?php  echo base_url(); ?>#" target="_blank"> Designed by Themewagon</a>--></div>
      </div>
          <!--/.row--></div>
    <!--/.container--></section> 
    <div class="rightfixed">
    <a href="<?php  echo base_url(); ?>Free_Listing" class="frilst "></a>
    <a  href="<?php  echo base_url(); ?>Customer_Care" class="cscare "></a>
    </div>

    

     </div>
    </main>
    <!--  -->
    <!--    JavaScripts-->
    <!--    =============================================-->
    <script src="<?php  echo base_url(); ?>assets/js/modernizr.min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/popper.min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/imagesloaded.pkgd.min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/TweenMax.min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/ScrollToPlugin.min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/CustomEase.min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/config.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/zanimation.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/owl.carousel.min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/remodal.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/lightbox.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/jquery.flexslider-min.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/core.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/main.js" type="text/javascript"></script>
    <script src="<?php  echo base_url(); ?>assets/js/js.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/readMoreJS.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/readMoreJS.min.js" type="text/javascript"></script>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
		<script>
		$readMoreJS.init({
			target: '.dummy p ',
			numOfWords: 50,
			toggle: true,
			moreLink: 'read more ...',
			lessLink: 'read less'
		});
	</script>
</body>
</html>

