   <?php 
	$CI =& get_instance();
	$CI->load->model('Common_model');
	$category = $CI->Common_model->getCat();
	$subCategory = $CI->Common_model->getSubCat();
	$getCityList = $CI->Common_model->getCityList();
	

   ?>
   <div class="col-lg-3 mr-0">
          <div class="vertical-menu">
          <h5>Categories</h5>
          <hr class="color-9 my-2">
            <ul>
			<?php foreach($category as $valCat){ ?>
              <li><a href="<?php echo base_url(); ?>Category/index/<?php echo $valCat['category_id']; ?>"><span class="personal-icon icon1"></span> <?php echo $valCat['category']; ?></a></li>
            <?php } ?>
             </ul>
          </div>
         
          
          <div class="vertical-menu">
          <h5>Popular Areas</h5>
          <hr class="color-9 my-2">
            <ul>
              <?php foreach($getCityList as $valCity){ ?>
              <li><a href="<?php echo base_url(); ?>Category/city/<?php echo $valCity['city_id']; ?>"><span class="personal-icon icon1"></span> <?php echo $valCity['city_name']; ?></a></li>
            <?php } ?>
              <!--<li><a href="#">See More <span><i class="fa fa-chevron-right readmore"></i></span></a></li>-->
            </ul>
            </div>
          
          <div class="vertical-menu">
          <h5>Also use for:</h5>
          <hr class="color-9 my-2">
            <ul>
             <?php foreach($subCategory as $valSubCat){ ?>
              <li><a href="<?php echo base_url(); ?>Category/subCat/<?php echo $valSubCat['sub_category_id']; ?>"><span class="personal-icon icon1"></span> <?php echo $valSubCat['sub_category']; ?></a></li>
            <?php } ?>
			</ul>
            </div>
        </div>