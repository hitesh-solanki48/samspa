<section class="font-1 pt-2 pl-0 pb-0 pr-0">
<div class="container">
<h1 class="gglsrc lng_commn">Beauty Parlours in Delhi-NCR	</h1>
<div class="row">

<div class="col-lg-2 pl-3 pr-0 pb-0 pt-0"><a class="sortbyresult" href="#">SORT RESULTS BY</a><i class="left_arrow"></i></div>
<div class="col-lg-10 row pl-0 pr-0 pb-0 pt-0">
<div class="col-lg-2 topsbar"><a href="top-results.html">Top Results</a></div>
<div class="col-lg-2 topsbar"><a href="popularity.html">Popularity</a></div>
<div class="col-lg-2 topsbar"><a href="#"id="myBtn">Location</a></div>
<div class="col-lg-2 topsbar">
<div class="dropdown">
    <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">Distance
    <span class="caret"></span></button>
    <ul class="dropdown-menu">
      <li><a href="#">1 km</a></li>
      <li><a href="#">2 km</a></li>
      <li><a href="#">3 km</a></li>
      <li><a href="#">4 km</a></li>
      <li><a href="#">5 km</a></li>
    </ul>
  </div>
  </div>
<div class="col-lg-2 topsbar"><a href="ratings.html">Ratings <i class="fa fa-long-arrow-up"></i></a></div>
<div class="col-lg-2 topsbar"><a href="special-offer.html">Special Offer</a></div>
<div class="clearfix"></div>

</div>
  </div>
  </div>
  </section>