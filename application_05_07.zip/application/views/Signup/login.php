
  
      <section class="font-1 p-0 mt-5 mb-5">
    <div class="container">
      <div class="row">
        
        <div class="col-lg-12">
        <div class="container ">
        <div class="row mb-6 text-center">
        <div class="col">
              <h3 class="fs-2 fs-md-3">Login</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
         <div class="row">

         <div class="col-lg-7 m-auto border">
         <div class="background-white radius-secondary p-2 p-md-5 mt-0" data-zanim="{&quot;delay&quot;:0.1}" style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
            <h4 class="text-uppercase fs-0 fs-md-1">Sign Up with Sam Spa Center</h4>
            <form class="text-left mt-4">
              <div class="row align-items-center">
                <div class="col-12">
                  <div class="input-group">
                    <div class="input-group-addon background-11 fs-2"><span class="fa fa-user"></span></div>
                    <input class="form-control" type="text" placeholder="Email or username" />
                  </div>
                </div>
                <div class="col-12 mt-2 mt-sm-4">
                  <div class="input-group">
                    <div class="input-group-addon background-11 fs-2"><span class="fa fa-lock"></span></div>
                    <input  class="form-control" type="Password" placeholder="Password" value="" />
                  </div>
                </div>
              </div>
              <div class="row align-items-center mt-3">
                <div class="col-8">
                <a href="#"><span class="ftpd">Forgot password?</span></a>
                  <!--<label class="form-check-label">
                    <input class="form-check-input" type="checkbox">
                    <span class="color-7">Remember Me</span></label>-->
                </div>
                <div class="col-4 mt-2 mt-sm-3">
                  <button class="btn btn-primary btn-block" type="submit">Login</button>
                </div>
              </div>
            </form>
          </div>
        </div>

      </div>
      </div>


        </div>
      </div>
 </div>
</section>

