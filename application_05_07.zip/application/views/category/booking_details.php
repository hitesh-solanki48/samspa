<?php $this->load->view('common/search.php'); ?>

<section class="font-1 pt-2 pl-0 pb-0 pr-0">
<div class="container">
<div class="row">
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <span class="ptxt">Sort By Location</span>
		<p>Where in Delhi</p>
    <p>
     <div class="search-container">
    <form action="#">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit">Go</button>
    </form>
  </div>
    </p>
  </div>

</div>

<script>
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal 
    btn.onclick = function () {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>


</div>
</div>
</section>

<?php //echo '<pre>'; print_r($getPostReviewByID); ?>
 
  <section class="font-1 py-5">
    <div class="container">
      <div class="row">
        <?php $this->load->view('common/leftmenu2.php'); ?>
		<div class="col-lg-9 pl-lg-2">
          <div class="row pb-3 align-items-center">
            <div class="col">
              <p class="mb-0"><strong><?php echo $getDetail[0]['title']; ?> </strong></p>
            </div>
          </div>
          <div class="row align-items-center border color-9 m-2 p-3">
            <div class="col-sm-4 icon-box1 p-3 ">
            <a href="#">
            <span class="fa fa-pencil-square-o mr-2" style=" float:left;"></span> <h5>Reviews</h5>
            <p class="ml-5"> Mr. Sonu Singh</p>
            <p class="ml-5">has rated 5.0 stars</p>
            <i class="fa fa-chevron-right" style=" float:right; font-size:14px;"></i></a>
            </div>
           
            <div class="col-sm-4 icon-box2 p-3">
            <a href="#">
            <span class="fa fa-info-circle mr-2" style=" float:left;"></span> <h5>More Information</h5>
            <p class="ml-5">Phone number, Address</p>
            <p class="ml-5">Official website</p>
             <i class="fa fa-chevron-right" style=" float:right; font-size:14px;"></i></a>
            </div>
            
            <div class="col-sm-4 icon-box3 p-3">
            <a href="#">
            <span class="fa fa-hourglass-start mr-2" style=" float:left;"></span> <h5>Hours Of Operation</h5>
            <p class="ml-5"> Today : Open 24 Hrs</p>
            <p class="ml-5">(View all)</p>
            <i class="fa fa-chevron-right" style=" float:right; font-size:14px;"></i></a>
            </div>


            <div class="clearfix"></div>


           <div class="tab mb-4">
  <button class="tablinks btn-primary" onclick="openCity(event, 'demo1')"> <span class="fa fa-pencil-square-o mr-2"></span> WRITE A REVIEW</button>
  <button class="tablinks btn-primary" onclick="openCity(event, 'demo2')" id="defaultOpen"> <span class="fa fa-star mr-2"></span> REVIEWS &amp; RATINGS</button>
  
</div>

<div id="demo1" class="tabcontent">
<?php echo form_open_multipart('Category/add_review', 'id=myForm onsubmit="return validateAll();" '); ?>
<div class="row  mb-3">
  <div class="col-sm-6"><h5> Please rate your experience</h5></div>
  <div class="col-sm-6">

  <div class="rating">
  <input name="post_id" value="<?php echo $getDetail[0]['post_id']; ?>" type="hidden">
	<input type="hidden" id="php1_hidden" value="1">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php1" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
	<input type="hidden" id="php2_hidden" value="2">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php2" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
	<input type="hidden" id="php3_hidden" value="3">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php3" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
	<input type="hidden" id="php4_hidden" value="4">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php4" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
	<input type="hidden" id="php5_hidden" value="5">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php5" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
	<input type="hidden" id="php6_hidden" value="6">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php6" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
	<input type="hidden" id="php7_hidden" value="7">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php7" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
	<input type="hidden" id="php8_hidden" value="8">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php8" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
	<input type="hidden" id="php9_hidden" value="9">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php9" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
	<input type="hidden" id="php10_hidden" value="10">
	<img src="<?php echo base_url(); ?>assets/images/rate/star1.png" onmouseover="change(this.id);" id="php10" onmouseover="change(this.id);" class="fa fa-star mr-1 color-warning">
  
    <!--<span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span>
    <span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span>
    <span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span>
    <span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span>
    <span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span>
    <span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span>
    <span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span>
    <span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span>
    <span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span>
    <span class="fa fa-star mr-1 color-warning" onmouseover="change(this.id);"  ></span> -->
    </div>
	
	<input type="hidden" name="phprating" id="phprating" value="0">
	<span id="errprRate" style="color:red"></span>
	<?php //echo form_error('phprating'); ?>
  </div>
  </div>




  <div class="background-10 p-3  rounded mb-3">
  <b class="mb-2">Add Review</b>
  <textarea name="review_text" id="review_text"></textarea>
  <?php echo form_error('review_text'); ?>

  </div>
  <div class="row">
  <div class="col-sm-3"><h5>Share with friends</h5></div>
  <div class="col-sm-9">
  <div class="form-check mb-4"> 
  <label class="form-check-label fw-400">
  <input class="form-check-input mr-2" type="checkbox">Facbooke</label>
  <label class="form-check-label fw-400">
  <input class="form-check-input mr-2" type="checkbox">Twitter</label>

  </div>
  </div>
  <div class="col-sm-12"><!--<a href="#" class="btn btn-info mb-4">Submit</a>-->
  <input type="button" name="buttonSubmit" onclick="return checkValidate(event);" value="Submit" class="btn btn-info  mb-4"  data-toggle="modal" data-target="#myModal_1">
   <!---<button type="button" value="buttonSubmit" class="btn btn-info  mb-4"  data-toggle="modal" data-target="#myModal_1">Submit</button>--></div>
  </div>
   <!---- pOP Up Model Start --->
 <div class="modal fade popupidc" id="myModal_1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Fill Form</h4>
        </div>
        <div class="modal-body">
          <p>To submit your ratings, please provide the following information.</p>
		  Name : <input type="text" id="po_name" value="" name="name"><br/>
		  <span id="errprRatename" style="color:red"></span>
			Mobile : <input type="text" id="po_mobile" value="" name="mobile"><br/>
		  <span id="errprRatephone" style="color:red"></span>
		  Email : <input type="text" id="po_email" value="" name="email"><br/>
		  <span id="errprRateemail" style="color:red"></span>
		  <input type="submit" value="submit" name="submit">
        </div>
		
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
   </form>
  
  <h4><?php echo $getDetail[0]['page_title']; ?></h4>
<div class="clearfix"></div>
<p> <?php echo $getDetail[0]['description']; ?></p>
</div>

<div id="demo2" class="tabcontent">
  <div class="row">
  <div class="col-sm-6 mb-4"><img src="images/chart.gif" /></div>
  <div class="col-sm-6 mb-4"><img src="images/chart1.gif" /></div>
  
<?php 
	if(isset($getPostReviewByID)){
		foreach($getPostReviewByID as $val){
			$rate = $val['phprating'] / 2;
			$getRate =  ceil($rate);
?>
  
 <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b><?php echo $val['name']; ?></b> </span>&nbsp;&nbsp;&nbsp;
    <?php for($k = 0; $k < $getRate; $k++){ ?>
    <span class="fa fa-star mr-1 color-warning"></span>
	<?php } ?>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;"><?php echo date("F j, Y", strtotime($val['created'])); ?></span>
    </div>
  <hr />
 <p>
 <?php 
	if($getRate >= 0 && $getRate <= 1){
		echo 'Poor';
	} else  if($getRate >= 2 && $getRate <= 3){
		echo 'Good';
	} else  if($getRate >= 4 && $getRate <= 5){
		echo 'Very Good';
	} else  if($getRate >= 5 && $getRate == 5){
		echo 'Excellent';
	} else {
		echo '';
	}
 ?>
 </p> 
  </div>
 <div class="clearfix"></div>

 <?php 
		}
	}
 ?> 



  <div class="col-sm-12 businfo seoshow ">
								<p class="heading lng_commn_all"><?php echo $getDetail[0]['page_title']; ?></p>
								<span class="detl lng_commn_all"><p><?php echo $getDetail[0]['description']; ?> </p></span>
								<!-- </section> -->
							</div>
  </div>
</div>









</div>
          </div>

        
        </div>
      </div>
	  
	   
  

 <----pOP Up Model Start --->
      <!--/.row-->
    <!--/.container--></section>
<script type="text/javascript">

function checkValidate(e){
	e.preventDefault();
	var rateVal = $("#phprating").val();
	
	if(rateVal == '0'){
		$("#errprRate").html('Please Select Rating'); 
		$("#myModal_1").attr("id",""); 
		return false;
		
	} else {
		$(".popupidc").attr("id","myModal_1"); 
	}
}

function validateAll(){
	var name = $("#po_name").val();
	var email = $("#po_email").val();
	var phone = $("#po_mobile").val();
	if(name == ''){
		$("#errprRatename").html('Please Insert Name');
		return false;
	}
	
	if(phone == ''){
		$("#errprRateemail").html('Please Insert Phone');
		return false;
	}
	
	if(email == ''){
		$("#errprRatephone").html('Please Insert Email');
		return false;
	}
}

</script>
	
	  <script type="text/javascript">
  
   function change(id)
   {
	   
	    
      //var cname=document.getElementById(id).className;
      var ab=document.getElementById(id+"_hidden").value;
      //alert(cname);
	  document.getElementById("phprating").value=ab;

      for(var i=ab;i>=1;i--)
      {
         document.getElementById("php"+i).src="<?php echo base_url(); ?>assets/images/rate/star2.png";
      }
      var id=parseInt(ab)+1;
      for(var j=id;j<=10;j++)
      {
         document.getElementById("php"+j).src="<?php echo base_url(); ?>assets/images/rate/star1.png";
      }
   }

</script>