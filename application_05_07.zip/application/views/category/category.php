<?php //$this->load->view('common/header2.php'); ?>
<?php $this->load->view('common/search.php'); ?>



<section class="font-1 pt-2 pl-0 pb-0 pr-0">
<div class="container">
<div class="row">
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <span class="ptxt">Sort By Location</span>
		<p>Where in Delhi</p>
    <p>
     <div class="search-container">
    <form action="#">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit">Go</button>
    </form>
  </div>
    </p>
  </div>

</div>

<script>
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal 
    btn.onclick = function () {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>


</div>
</div>
</section>


   <section class="font-1 p-0">
    <div class="container">
      <div class="row">
         <?php $this->load->view('common/leftmenu.php'); ?>
        <div class="col-lg-9 pl-0">
        
         <div class="row">
           <div class="col-lg-12">
			  <?php foreach($cateData as $val){ ?>
			  <div class="row align-items-center box-shadow border color-9 mb-3 mx-0 pt-3 pb-1">
				<div class="col-sm-3">
						<a href="<?php echo base_url(); ?>Category/Book_Details/<?php echo $val['post_id']; ?>"> 
							<?php if($val['image'] != ''){ ?>
							<img class="w-100" src="<?php echo base_url(); ?>assets/images/add_data/<?php echo $val['image']; ?>">
							<?php } else { ?>
							<img class="w-100" src="<?php echo base_url(); ?>assets/images/demo.gif">
							<?php } ?>
						</a>
					</div>
				<div class="col-sm-6 color-1">
					<p class="lead color-primary fw-600 mb-0"><?php echo $val['title']; ?></p>
				  
					<div class="color-warning">
						<span class="fa fa-star mr-1 color-warning"></span>
						<span class="fa fa-star mr-1 color-warning"></span>
						<span class="fa fa-star mr-1 color-warning"></span>
						<span class="fa fa-star mr-1 color-warning"></span>
						<span class="fa fa-star mr-1 color-warning"></span>
					</div>
					<div class="color-5 mt-2">
						<a class="color-5 fs--1" href="<?php echo base_url(); ?>Category/Book_Details/<?php echo $val['post_id']; ?>"> 
							<span class="fa fa-volume-control-phone mr-1"></span>+91-<?php echo $val['cont_number']; ?>
						</a>
					</div>
				  <?php 
 
						   $str = $val['description'];
							$string = strip_tags($str);
							if (strlen($string) > 40) { $stringCut = substr($string, 0, 40);$string = substr($stringCut, 0, strrpos($stringCut, ' '));}
							

					?>
					<div class="color-5 mt-2">
						<a class="color-5 fs--1" href="<?php echo base_url(); ?>Category/Book_Details/<?php echo $val['post_id']; ?>"> 
							<span class="fa fa-address-book mr-1"></span><?php echo $string; ?>..
						</a> | <a class="color-5 fs--1" href="<?php echo base_url(); ?>Category/Book_Details/<?php echo $val['post_id']; ?>">More</a>
					</div>
					<div class="color-5 mt-2">
						<a class="color-5 fs--1" href="<?php echo base_url(); ?>Category/Book_Details/<?php echo $val['post_id']; ?>"> 
							<span class="fa fa-arrow-circle-right mr-1"></span><?php echo $val['page_title']; ?>,
						</a>
					</div>
				</div>
				<div class="col-sm-3 color-1">
				<a href="<?php echo base_url(); ?>Category/Booking/<?php echo $val['post_id']; ?>" class="btn btn-icon btn-primary btn-icon-right btn-capsule fr">
				 <span class="fa fa-arrow-circle-right color-warning"></span> Book Online</a>
				</div>
				<div class="rating"> 
					<a href="<?php echo base_url(); ?>Category/Book_Details/<?php echo $val['post_id']; ?>">
						<span class="fa fa-star mr-1 color-warning"></span> Click here to view your <b>friends rating</b>
					</a>
				</div>
				</div>
				<?php } ?>

          <nav class="font-1 mt-5" aria-label="Page navigation example">
            <ul class="pagination justify-content-center pagination-warning">
              <li class="page-item"><a class="page-link" href="#" aria-label="Previous"><span aria-hidden="true"><i class="fa fa-chevron-left"></i></span><span class="sr-only">Previous</span></a></li>
              <li class="page-item active"><a class="page-link" href="#">1</a></li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
              <li class="page-item"><a class="page-link" href="#">4</a></li>
              <li class="page-item"><a class="page-link" href="#" aria-label="Next"><span aria-hidden="true"><i class="fa fa-chevron-right"></i></span><span class="sr-only">Next</span></a></li>
            </ul>
          </nav> 
        </div>

      </div>
      


        </div>
      </div>
 </div>
</section>



<?php //$this->load->view('common/header2.php'); ?>
