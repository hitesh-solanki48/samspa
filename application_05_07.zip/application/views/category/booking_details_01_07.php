<?php $this->load->view('common/search.php'); ?>

<section class="font-1 pt-2 pl-0 pb-0 pr-0">
<div class="container">
<div class="row">
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <span class="ptxt">Sort By Location</span>
		<p>Where in Delhi</p>
    <p>
     <div class="search-container">
    <form action="#">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit">Go</button>
    </form>
  </div>
    </p>
  </div>

</div>

<script>
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal 
    btn.onclick = function () {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>


</div>
</div>
</section>


 
  <section class="font-1 py-5">
    <div class="container">
      <div class="row">
        <?php $this->load->view('common/leftmenu2.php'); ?>
		<div class="col-lg-9 pl-lg-2">
          <div class="row pb-3 align-items-center">
            <div class="col">
              <p class="mb-0"><strong>Spa Center Noida </strong></p>
            </div>
          </div>
          <div class="row align-items-center border color-9 m-2 p-3">
            <div class="col-sm-4 icon-box1 p-3 ">
            <a href="#">
            <span class="fa fa-pencil-square-o mr-2" style=" float:left;"></span> <h5>Reviews</h5>
            <p class="ml-5"> Mr. Sonu Singh</p>
            <p class="ml-5">has rated 5.0 stars</p>
            <i class="fa fa-chevron-right" style=" float:right; font-size:14px;"></i></a>
            </div>
           
            <div class="col-sm-4 icon-box2 p-3">
            <a href="#">
            <span class="fa fa-info-circle mr-2" style=" float:left;"></span> <h5>More Information</h5>
            <p class="ml-5">Phone number, Address</p>
            <p class="ml-5">Official website</p>
             <i class="fa fa-chevron-right" style=" float:right; font-size:14px;"></i></a>
            </div>
            
            <div class="col-sm-4 icon-box3 p-3">
            <a href="#">
            <span class="fa fa-hourglass-start mr-2" style=" float:left;"></span> <h5>Hours Of Operation</h5>
            <p class="ml-5"> Today : Open 24 Hrs</p>
            <p class="ml-5">(View all)</p>
            <i class="fa fa-chevron-right" style=" float:right; font-size:14px;"></i></a>
            </div>


            <div class="clearfix"></div>


           <div class="tab mb-4">
  <button class="tablinks btn-primary" onclick="openCity(event, 'demo1')"> <span class="fa fa-pencil-square-o mr-2"></span> WRITE A REVIEW</button>
  <button class="tablinks btn-primary" onclick="openCity(event, 'demo2')" id="defaultOpen"> <span class="fa fa-star mr-2"></span> REVIEWS &amp; RATINGS</button>
  
</div>

<div id="demo1" class="tabcontent">

<div class="row  mb-3">
  <div class="col-sm-6"><h5> Please rate your experience</h5></div>
  <div class="col-sm-6">

  <div class="rating">
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    </div>
  </div>
  </div>



  <div class="background-10 p-3  rounded mb-3">
  <b class="mb-2">Add Review</b>
  <textarea></textarea>
  </div>
  <div class="row">
  <div class="col-sm-3"><h5>Share with friends</h5></div>
  <div class="col-sm-9">
  <div class="form-check mb-4"> 
  <label class="form-check-label fw-400">
  <input class="form-check-input mr-2" type="checkbox">Facbooke</label>
  <label class="form-check-label fw-400">
  <input class="form-check-input mr-2" type="checkbox">Twitter</label>

  </div>
  </div>
  <div class="col-sm-12"><a href="#" class="btn btn-info mb-4">Submit</a></div>
  
  </div>
  
  
  <h4>Business Information</h4>
<div class="clearfix"></div>
<b> Body Massage in Chakkarpur, Delhi</b>
<p>Rose Body Massage in Delhi. Massage Services For Men At Home with Address, Contact Number, Photos, Maps. View Rose Body Massage, Delhi on Justdial.
</p>
<b>Location and Overview:</b>
<p>Established in the year 2013, Rose Body Massage in Chakkarpur, Delhi is a top player in the category Massage Services For Men At Home in the Delhi. This well-known establishment acts as a one-stop destination servicing customers both local and from other parts of Delhi. Over the course of its journey, this business has established a firm foothold in it’s industry. The belief that customer satisfaction is as important as their products and services, have helped this establishment garner a vast base of customers, which continues to grow by the day. This business employs individuals that are dedicated towards their respective roles and put in a lot of effort to achieve the common vision and larger goals of the company. In the near future, this business aims to expand its line of products and services and cater to a larger client base. In Delhi, this establishment occupies a prominent location in Chakkarpur. It is an effortless task in commuting to this establishment as there are various modes of transport readily available. It is at 0, Near Galleria Market, which makes it easy for first-time visitors in locating this establishment. The popularity of this business is evident from the 90+ reviews it has received from Justdial users. It is known to provide top service in the following categories: Massage Services For Men At Home, Body Massage Centres, 24 Hours Body Massage Centres.
</p>
<b>Products and Services offered:</b>
<p>Rose Body Massage in Chakkarpur has a wide range of products and services to cater to the varied requirements of their customers. The staff at this establishment are courteous and prompt at providing any assistance. They readily answer any queries or questions that you may have. Pay for the product or service with ease by using any of the available modes of payment, such as Cash, Master Card, Visa Card, Debit Cards, Cheques, American Express Card, Credit Card. This establishment is functional from 00:00 - 23:59.
</p>
<p>
Please scroll to the top for the address and contact details of Rose Body Massage at Chakkarpur, Delhi.</p>
</div>

<div id="demo2" class="tabcontent">
  <div class="row">
  <div class="col-sm-6 mb-4"><img src="images/chart.gif" /></div>
  <div class="col-sm-6 mb-4"><img src="images/chart1.gif" /></div>
  

 <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>

  <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>

  <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>


  <div class="allratL ml-3 mb-2"><img src="images/he.gif" /></div>
  <div class="allratR  mb-2 ">
   <div class="color-warning">
   <span class="color-primary"><b>Mr Rajan Pande</b> </span>&nbsp;&nbsp;&nbsp;
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="fa fa-star mr-1 color-warning"></span>
    <span class="color-primary" style="text-align:right; float:right;  font-size:14px;">7th Mar, 2018</span>
    </div>
  <hr />
 <p>Excellent</p> 
  </div>
 <div class="clearfix"></div>



  <div class="col-sm-12 businfo seoshow ">
								<p class="heading lng_commn_all">Business Information</p>
								<span class="detl lng_commn_all"><h6>Rose Body Massage in Chakkarpur, Delhi</h6><p>Rose Body Massage in Delhi. Massage Services For Men At Home with Address, Contact Number, Photos, Maps. View Rose Body Massage, Delhi on Justdial.</p>
				<p></p><h6>Location and Overview:</h6><p></p>
				<p>Established in the year 2013, Rose Body Massage in Chakkarpur, Delhi is a top player in the category Massage Services For Men At Home in the Delhi. This well-known establishment acts as a one-stop destination servicing customers both local and from other parts of Delhi. Over the course of its journey, this business has established a firm foothold in it’s industry. The belief that customer satisfaction is as important as their products and services, have helped this establishment garner a vast base of customers, which continues to grow by the day. This business employs individuals that are dedicated towards their respective roles and put in a lot of effort to achieve the common vision and larger goals of the company. In the near future, this business aims to expand its line of products and services and cater to a larger client base. In Delhi, this establishment occupies a prominent location in Chakkarpur. It is an effortless task in commuting to this establishment as there are various modes of transport readily available. It is at 0, Near Galleria Market, which makes it easy for first-time visitors in locating this establishment. The popularity of this business is evident from the 90+ reviews it has received from Justdial users. It is known to provide top service in the following categories: Massage Services For Men At Home, Body Massage Centres, 24 Hours Body Massage Centres. </p>

				<p></p><h6>Products and Services offered:</h6><p></p>
				<p>Rose Body Massage in Chakkarpur has a wide range of products and services to cater to the varied requirements of their customers. The staff at this establishment are courteous and prompt at providing any assistance. They readily answer any queries or questions that you may have. Pay for the product or service with ease by using any of the available modes of payment, such as Cash, Master Card, Visa Card, Debit Cards, Cheques, American Express Card, Credit Card. This establishment is functional from 00:00 - 23:59. </p><p>Please scroll to the top for the address and contact details of Rose Body Massage at Chakkarpur, Delhi. </p></span>
								<!-- </section> -->
							</div>
  </div>
</div>









</div>
          </div>

         
        </div>
      </div>
      <!--/.row-->
    <!--/.container--></section>