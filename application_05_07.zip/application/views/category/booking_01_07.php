<?php $this->load->view('common/search.php'); ?>

<section class="font-1 pt-2 pl-0 pb-0 pr-0">
<div class="container">
<div class="row">
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <span class="ptxt">Sort By Location</span>
		<p>Where in Delhi</p>
    <p>
     <div class="search-container">
    <form action="#">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit">Go</button>
    </form>
  </div>
    </p>
  </div>

</div>

<script>
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal 
    btn.onclick = function () {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>


</div>
</div>
</section>

  
      <section class="font-1 p-0">
    <div class="container">
      <div class="row">
        <?php $this->load->view('common/leftmenu.php'); ?>
        <div class="col-lg-9 pl-0">
        <div class="container ">
        <div class="row mb-6 text-center">
        <div class="col">
              <h3 class="fs-2 fs-md-3">Booking</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
         <div class="row">

         <div class="col-lg-12 ">
         <form class="zform mt-3">
              <div class="row">

         <div class="col-lg-4 mb-4 mb-lg-4">
        <label class="color-primary">Name</label>
        <input class="form-control background-white" type="Name" placeholder="Name" required>
        </div>

         <div class="col-lg-4 mb-4 mb-lg-4">
         <label class="color-primary">Email</label>
        <input class="form-control background-white" type="email" placeholder="Email" required>
        </div>

         <div class="col-lg-4 mb-4 mb-lg-4">
         <label class="color-primary">Phone Number</label>
        <input class="form-control background-white" type="Phone Number" placeholder="Phone Number" required>
        </div>

         <div class="col-lg-4 mb-4 mb-lg-4">
        <label class="color-primary">Location</label>
        <input class="form-control background-white" type="Location" placeholder="Location" required>
        </div>

         <div class="col-lg-4 mb-4 mb-lg-4">
         <label class="color-primary">Country</label>
        <input class="form-control background-white" type="Country" placeholder="Country" required>
        </div>

         <div class="col-lg-4 mb-4 mb-lg-4">
         <label class="color-primary">City</label>
        <input class="form-control background-white" type="City" placeholder="City" required>
        </div>

        <div class="col-12 mt-4">
                  <textarea class="form-control  background-white textarea" rows="8" placeholder="Enter your descriptions here..." required></textarea>
                </div>

         <div class="col-12 mt-4">
                  <div class="row">
                    <div class="col-auto">
                      <button class="btn btn-md-lg btn-primary" type="Submit"> <span class="color-white fw-600">Send Now</span></button>
                    </div>
                    <div class="col">
                      <div class="zform-feedback"></div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
        </div>

      </div>
      </div>


        </div>
      </div>
 </div>
</section>


     