
  <section class="background-11 textp color-primary">
    <div class="container">
    <div class="col">
          <h3 class="text-center fs-2 fs-md-3">Contact Us</h3>
          <hr class="short" data-zanim='{"from":{"opacity":0,"width":0},"to":{"opacity":1,"width":"4.20873rem"},"duration":0.8}' data-zanim-trigger="scroll"/>
        </div>
	
      <div class="row align-items-stretch justify-content-center">
        	
		<?php
				
			$CI =& get_instance();
			$CI->load->model('Common_model');
			$getContDet = $CI->Common_model->getContDet();	
				if(isset($getContDet)){
					foreach($getContDet as $val){
					
				
			
		  ?>
		<div class="col-lg-4 mb-4 mb-lg-0">
          <div class="h-100 px-5 py-4 background-white radius-secondary color-primary">
            <h5 class="mb-3 color-primary"><?php echo $val['address_1']; ?></h5>
           <p class="color-black"><?php echo $val['address_2']; ?>,<br>
            <?php echo $val['state']; ?> <?php echo $val['pin_code']; ?>,<br>
            <?php echo $val['state']; ?></p></div>
        </div>
		
		<?php }} ?>
        <div class="col-lg-4">
          <div class="h-100 px-5 py-4 background-white radius-secondary">
            <h5 class="color-primary">Socials</h5>
            <a class="d-inline-block mt-2" href="#"><span class="fa fa-linkedin-square fs-2 mr-2 color-primary"></span></a><a class="d-inline-block mt-2" href="#"><span class="fa fa-twitter-square fs-2 mx-2 color-primary"></span></a><a class="d-inline-block mt-2" href="#"><span class="fa fa-facebook-square fs-2 mx-2 color-primary"></span></a><a class="d-inline-block mt-2" href="#"><span class="fa fa-google-plus-square fs-2 ml-2 color-primary"></span></a></div>
        </div>
        <div class="col-12 mt-4">
          <div class="background-white p-5 radius-secondary">

          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14016.51122232298!2d77.3152768!3d28.5810688!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m3!3e6!4m0!4m0!5e0!3m2!1sen!2sin!4v1518594780765"  height="450" frameborder="0" style="border:0; width:100%" allowfullscreen></iframe>
            <!--<div class="googlemap" data-latlng="48.8583701,2.2922873,17" data-scrollwheel="false" data-icon="assets/images/map-marker.png" data-zoom="17" data-theme="Tripitty">
              <div class="marker-content py-3">
                <h5>Eiffel Tower</h5>
                <p>Gustave Eiffel's iconic, wrought-iron 1889 tower,<br>
                  with steps and elevators to observation decks.</p>
              </div>
            </div>-->
          </div>
        </div>
        <div class="col-12 mt-4">
          <div class="background-white p-5 h-100 radius-secondary">
            <h5 class="color-primary">Write to us</h5>
            <?php echo validation_errors(); ?> 
			<?php echo form_open_multipart('Contact_Us/add'); ?>
              <div class="row">
                <div class="col-12">
                  <input class="form-control" type="hidden" name="to" value="user@domain.extension">
                  <input class="form-control background-white" name="name" type="text" placeholder="Your Name" required>
                </div>
                <div class="col-12 mt-4">
                  <input class="form-control background-white" name="email" type="email" placeholder="Email" required>
                </div>
                <div class="col-12 mt-4">
                  <textarea class="form-control background-white" name="comment" rows="11" placeholder="Enter your descriptions here..." required></textarea>
                </div>
                <div class="col-12 mt-4">
                  <div class="row">
                    <div class="col-auto">
                      
					  <input class="btn btn-md-lg btn-primary" type="submit" name="Submit" value="Send Now" />
                    </div>
                    <div class="col">
                      <div class="zform-feedback"></div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <!--/.row--></div>
    <!--/.container--></section>
