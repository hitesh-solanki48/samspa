
  <section class="background-white  px-3 mt-2 ">
    <div class="container">
    <div class="row mb-6 text-center">
        <div class="col">
              <h3 class="fs-2 fs-md-3"> Feedback</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
      <div class="row">
       <div class="col-lg-8  m-auto">
    <div class="feedback-menu">
    <ul>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    <li><a href="#">    I am a Registered customer of Sam Spa Center. </a></li>
    </ul>
    </div>
       </div> 
      </div>

      
  <!--/.row--></div>
    <!--/.container--></section>
