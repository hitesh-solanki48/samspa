<?php include('common/header1.php'); ?>
<!--Home Page Banner Start-->

<div class="kode-home-banner inner-banner">
<h6>City</h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>City</h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>index">Home</a></li>
<li><a href="<?php echo base_url(); ?>city">City</a></li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->

<div class="kf_content_wrap">
<!--Massage Categories Wrap Start-->

<section>
<div class="container">
<!--Heading 1 Start-->
<div class="kf-heading-1" style="margin-bottom: 0">
<span class="icon-icon-36491"><i class="hd-bdr"></i><i class="hd-bdl"></i></span>
<h1>Spa Treatments in India</h1>
</div>
<!--Heading 1 End-->
<div class="row">
<div class="kf_content_wrap">
<div class="blog-sidebar">
<div class="container">
<div class="row">
<!--Gallery Wrap Start-->
<div class="kf-gallery-wrap">
<!--Gallery Thumb Start-->
<hr>
<div class="kf-gallery-thumb col-md-3">
<a href="Body-Spa-in-Mumbai.php"><div class="kf-blog-thumb">
<img src="assets/images/city/mumbai.jpg" width="100%" height="180" alt="spa center in mumbai ">
<div class="text">
<h4>Mumbai</h4>
</div>
</div></a>
</div> 
<div class="kf-gallery-thumb col-md-3">
<a href="Body-Spa-in-Bangalore.php"><div class="kf-blog-thumb">
<img src="assets/images/city/bangalore.jpg" width="100%" height="180" alt="bangalore spa">
<div class="text">
<h4>Bangalore</h4>
</div>
</div></a>
</div> 
<div class="kf-gallery-thumb col-md-3">
<a href="Body-Spa-in-Delhi.php"><div class="kf-blog-thumb">
<img src="assets/images/city/delhi.jpg" width="100%" height="180" alt="spa deals in delhi">
<div class="text">
<h4>Delhi</h4>
</div>
</div></a>
</div>
<div class="kf-gallery-thumb col-md-3">
<a href="Spa-Center-in-Pune.php"><div class="kf-blog-thumb">
<img src="assets/images/city/pune.jpg" width="100%" height="180" alt="thai spa in pune">
<div class="text">
<h4>Pune</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-Center-in-Hyderabad.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Hyderabad.jpg" width="100%" height="180" alt="spa at hyderabad">
<div class="text">
<h4>Hyderabad</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-Center-in-Chennai.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Chennai.jpg" width="100%" height="180" alt="chennai spa centers">
<div class="text">
<h4>Chennai</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-Center-in-Kolkata.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Kolkata.jpg" width="100%" height="180" alt="spa kolkata">
<div class="text">
<h4>Kolkata</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-Center-in-Goa.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Goa.jpg" width="100%" height="180" alt="spa in goa">
<div class="text">
<h4>Goa</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-Center-in-Chandigarh.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Chandigarh.jpg" width="100%" height="180" alt="spa deals in chandigarh">
<div class="text">
<h4>Chandigarh</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-Center-in-Jaipur.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Jaipur.jpg" width="100%" height="180" alt="best spa in jaipur">
<div class="text">
<h4>Jaipur</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-in-Gurgaon.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Gurgaon.jpg" width="100%" height="180" alt="spa gurgaon">
<div class="text">
<h4>Gurgaon</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-in-Bhopal.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Bhopal.jpg" width="100%" height="180" alt="body spa in bhopal">
<div class="text">
<h4>Bhopal</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-in-Ranchi.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Ranchi.jpg" width="100%" height="180" alt="body spa in ranchi">
<div class="text">
<h4>Ranchi</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-in-Surat.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Surat.jpg" width="100%" height="180" alt="spa surat">
<div class="text">
<h4>Surat</h4>
</div>
</div></a>
</div><div class="kf-gallery-thumb col-md-3">
<a href="./Spa-in-Nashik.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Nashik.jpg" width="100%" height="180" alt="spa in nashik">
<div class="text">
<h4>Nashik</h4>
</div>
</div></a>
</div><div class="kf-gallery-thumb col-md-3">
<a href="./Spa-in-Vizag.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Vizag.jpg" width="100%" height="180" alt="spa in vizag">
<div class="text">
<h4>Vizag</h4>
</div>
</div></a>
</div><div class="kf-gallery-thumb col-md-3">
<a href="./Spa-in-Ahmedabad.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Ahmedabad.jpg" width="100%" height="180" alt="spa center in ahmedabad">
<div class="text">
<h4>Ahmedabad</h4>
</div>
</div></a>
</div><div class="kf-gallery-thumb col-md-3">
<a href="./Spa-in-Agra.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Agra.jpg" width="100%" height="180" alt="body spa in agra">
<div class="text">
<h4>Agra</h4>
</div>
</div></a>
</div>
        <div class="kf-gallery-thumb col-md-3">
<a href="./Spa-in-Lucknow.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Lucknow.jpg" width="100%" height="180" alt="spa center in lucknow">
<div class="text">
<h4>Lucknow</h4>
</div>
</div></a>
</div><div class="kf-gallery-thumb col-md-3">
<a href="./Body-Spa-in-Nagpur.php"><div class="kf-blog-thumb">
<img src="assets/images/city/Nagpur.jpg" width="100%" height="180" alt="spa center in nagpur">
<div class="text">
<h4>Nagpur </h4>
</div>
</div></a>
</div>

</div>
</div>
</div>		
</div>
</section>
</div>

</div>
</div>
</section>
<!--Priceing Table End-->

</div>
<?php include('common/footer1.php'); ?>