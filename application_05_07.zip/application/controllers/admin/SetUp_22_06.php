<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SetUp extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin')) { 
            redirect('login');
        }
		
		$this->load->model('Model_Setup');
    }

	/* ------ Country start ------ */
	
	public function list_country()
	{
        $data['udata']=$this->session->userdata;
        $data['country'] = $this->Model_Setup->getAllCountry();
        $this->load->view('admin/setup/view_country', $data);   
    }
	
	public function add_country(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('sortname', 'Sort Name', 'required');
			$this->form_validation->set_rules('country_name', 'Country Name', 'required');
			$this->form_validation->set_rules('phonecode', 'Phone code ', 'required');
			if($this->form_validation->run() == FALSE){
					$this->load->view('admin/setup/add_country');
			} else {
				$data = array(
					'sortname' => $this->input->post('sortname'),
					'country_name' => $this->input->post('country_name'),
					'phonecode' => $this->input->post('phonecode'),
					'status' => $this->input->post('status')
				);
				$this->Model_Setup->insert_country($data);
				$this->session->set_flashdata('message','Country Successfully Created.');
				redirect('admin/SetUp/list_country');
			}
		}else{
			$this->load->view('admin/setup/add_country');
		}
	}
	
	public function edit_country($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Setup->getCountry($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/setup/edit_country', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'sortname' => $this->input->post('sortname'),
					'country_name' => $this->input->post('country_name'),
					'phonecode' => $this->input->post('phonecode'),
					'status' => $this->input->post('status')
				);				
				
				$this->Model_Setup->editCountry($id, $data);
				$this->session->set_flashdata('message','Country Edit Successfully.');
				redirect(base_url('admin/SetUp/list_country'));
			} else {
				redirect(base_url('admin/SetUp/edit_country/'.$id));
			}
		}
        
    }
	
	
	public function deleteCountry($id){
		
        if (isset($id)){	
            $this->Model_Setup->deleteCountry($id);
			$this->session->set_flashdata('message','Country Successfully Deleted.');
            redirect(base_url('admin/SetUp/list_country'));
        } else {
            redirect(base_url('admin/SetUp/list_country'));
	    }
    }

	/* ------ Country end ------ */
	
	
	/* ------ State start ------ */
	
	public function list_state()
	{
        $data['udata']=$this->session->userdata;
        $data['state'] = $this->Model_Setup->getAllState();
        $this->load->view('admin/setup/view_state', $data);   
    }
	
	public function add_state(){
        if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $userRow;
			$this->load->view('admin/setup/add_state', $data);
		} else {
			if($this->input->post('buttonSubmit')){
				$data['message'] = '';
				$this->form_validation->set_rules('state_name', 'State Name', 'required');
				$this->form_validation->set_rules('country_id', 'Country Name', 'required');
				if($this->form_validation->run() == FALSE){
						$this->load->view('admin/setup/add_state');
				} else {
					$data = array(
						'state_name' => $this->input->post('state_name'),
						'country_id' => $this->input->post('country_id'),
						'status' => $this->input->post('status')
					);
					$this->Model_Setup->insert_state($data);
					$this->session->set_flashdata('message','State Successfully Created.');
					redirect('admin/SetUp/list_state');
				}
			}else{
				$this->load->view('admin/setup/add_state');
			}
		}
	}
	
	public function edit_state($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$stateRow = $this->Model_Setup->getState($id);
			$data['userRow'] = $stateRow;
			$userRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $userRow;
			$this->load->view('admin/setup/edit_state', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'state_name' => $this->input->post('state_name'),
					'country_id' => $this->input->post('country_id'),
					'status' => $this->input->post('status')
				);				
				
				$this->Model_Setup->editState($id, $data);
				$this->session->set_flashdata('message','State Edit Successfully.');
				redirect(base_url('admin/SetUp/list_state'));
			} else {
				redirect(base_url('admin/SetUp/edit_state/'.$id));
			}
		}
        
    }
	
	
	public function deleteState($id){
		
        if (isset($id)){	
            $this->Model_Setup->deleteState($id);
			$this->session->set_flashdata('message','State Successfully Deleted.');
            redirect(base_url('admin/SetUp/list_state'));
        } else {
            redirect(base_url('admin/SetUp/list_state'));
	    }
    }

	/* ------ State end ------ */
	
	
	/* ------ City start ------ */
	
	public function list_city()
	{
        $data['udata']=$this->session->userdata;
        $data['city'] = $this->Model_Setup->getAllCity();
        $this->load->view('admin/setup/view_city', $data);   
    }
	
	public function add_city(){
        if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$countRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $countRow;
			$stateRow = $this->Model_Setup->getAllState();
			$data['stateList'] = $stateRow;
			$this->load->view('admin/setup/add_city', $data);
		} else {
			if($this->input->post('buttonSubmit')){
				$data['message'] = '';
				$this->form_validation->set_rules('city_name', 'City Name', 'required');
				$this->form_validation->set_rules('state_id', 'State Name', 'required');
				$this->form_validation->set_rules('country_id', 'Country Name', 'required');
				if($this->form_validation->run() == FALSE){
						$this->load->view('admin/setup/add_city');
				} else {
					$data = array(
						'city_name' => $this->input->post('city_name'),
						'state_id' => $this->input->post('state_id'),
						'country_id' => $this->input->post('country_id'),
						'status' => $this->input->post('status')
					);
					$this->Model_Setup->insert_city($data);
					$this->session->set_flashdata('message','City Successfully Created.');
					redirect('admin/SetUp/list_city');
				}
			}else{
				$this->load->view('admin/setup/add_city');
			}
		}
	}
	
	public function edit_city($id){
		
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Setup->getCity($id);
			$data['userRow'] = $userRow;
			$stateRow = $this->Model_Setup->getAllState();
			$data['stateList'] = $stateRow;
			$countryRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $countryRow;
			$this->load->view('admin/setup/edit_city', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'city_name' => $this->input->post('city_name'),
					'state_id' => $this->input->post('state_id'),
					'country_id' => $this->input->post('country_id'),
					'status' => $this->input->post('status')
				);				
				
				$this->Model_Setup->editCity($id, $data);
				$this->session->set_flashdata('message','City Edit Successfully.');
				redirect(base_url('admin/SetUp/list_city'));
			} else {
				redirect(base_url('admin/SetUp/edit_city/'.$id));
			}
		}
        
    }
	
	
	public function deleteCity($id){
		
        if (isset($id)){	
            $this->Model_Setup->deleteCity($id);
			$this->session->set_flashdata('message','City Successfully Deleted.');
            redirect(base_url('admin/SetUp/list_city'));
        } else {
            redirect(base_url('admin/SetUp/list_city'));
	    }
    }

	/* ------ City end ------ */
	
	/* ------ Contact Details start ------ */
	
	public function list_cont_det()
	{
        $data['udata']=$this->session->userdata;
        $data['contDet'] = $this->Model_Setup->getAllContDet();
        $this->load->view('admin/setup/view_cont_det', $data);   
    }
	
	public function add_cont_det(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('address_1', 'Sort Name', 'required');
			$this->form_validation->set_rules('state', 'State', 'required');
			$this->form_validation->set_rules('phone_1', 'Phone', 'required');
			$this->form_validation->set_rules('pin_code', 'Pin Code', 'required');
			$this->form_validation->set_rules('email_1', 'Email', 'required');
			
			if($this->form_validation->run() == FALSE){
					$this->load->view('admin/setup/add_cont_det');
			} else {
				
				$data = array(
					'address_1' => $this->input->post('address_1'),
					'address_2' => $this->input->post('address_2'),
					'state' => $this->input->post('state'),
					'pin_code' => $this->input->post('pin_code'),
					'phone_1' => $this->input->post('phone_1'),
					'phone_2' => $this->input->post('phone_2'),
					'email_1' => $this->input->post('email_1'),
					'email_2' => $this->input->post('email_2'),
					'email_3' => $this->input->post('email_3'),
					'status' => $this->input->post('status'),
					'created' => date('Y-m-d')
				);
				$this->Model_Setup->insert_cont_det($data);
				$this->session->set_flashdata('message','Contact Details Successfully Created.');
				redirect('admin/SetUp/list_cont_det');
			}
		}else{
			$this->load->view('admin/setup/add_cont_det');
		}
	}
	
	public function edit_cont_det($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Setup->getContDet($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/setup/edit_cont_det', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'address_1' => $this->input->post('address_1'),
					'address_2' => $this->input->post('address_2'),
					'state' => $this->input->post('state'),
					'pin_code' => $this->input->post('pin_code'),
					'phone_1' => $this->input->post('phone_1'),
					'phone_2' => $this->input->post('phone_2'),
					'email_1' => $this->input->post('email_1'),
					'email_2' => $this->input->post('email_2'),
					'email_3' => $this->input->post('email_3'),
					'status' => $this->input->post('status'),
					'modify' => date('Y-m-d')
				);				
				
				$this->Model_Setup->editContDet($id, $data);
				$this->session->set_flashdata('message','Contact Details Edit Successfully.');
				redirect(base_url('admin/SetUp/list_cont_det'));
			} else {
				redirect(base_url('admin/SetUp/edit_cont_det/'.$id));
			}
		}
        
    }
	
	
	public function deleteContDet($id){
		
        if (isset($id)){	
            $this->Model_Setup->deleteContDet($id);
			$this->session->set_flashdata('message','Contact Details Successfully Deleted.');
            redirect(base_url('admin/SetUp/list_cont_det'));
        } else {
            redirect(base_url('admin/SetUp/list_cont_det'));
	    }
    }

	/* ------ Contact Details end ------ */
	
	/* ------ Category start ------ */
	
	public function list_category()
	{
        $data['udata']=$this->session->userdata;
        $data['category'] = $this->Model_Setup->getAllCategory();
        $this->load->view('admin/setup/view_category', $data);   
    }
	
	public function add_category(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('category', 'Category Name', 'required');
			
			if($this->form_validation->run() == FALSE){
					$this->load->view('admin/setup/add_category');
			} else {
				$data = array(
					'category' => $this->input->post('category'),
					
				);
				$this->Model_Setup->insert_category($data);
				$this->session->set_flashdata('message','Category Successfully Created.');
				redirect('admin/SetUp/list_category');
			}
		}else{
			$this->load->view('admin/setup/add_category');
		}
	}
	
	public function edit_category($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Setup->getCategory($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/setup/edit_category', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'category' => $this->input->post('category'),
				);				
				
				$this->Model_Setup->editCategory($id, $data);
				$this->session->set_flashdata('message','Category Edit Successfully.');
				redirect(base_url('admin/SetUp/list_category'));
			} else {
				redirect(base_url('admin/SetUp/edit_category/'.$id));
			}
		}
        
    }
	
	
	public function deleteCategory($id){
		
        if (isset($id)){	
            $this->Model_Setup->deleteCategory($id);
			$this->session->set_flashdata('message','Category Successfully Deleted.');
            redirect(base_url('admin/SetUp/list_category'));
        } else {
            redirect(base_url('admin/SetUp/list_category'));
	    }
    }

	/* ------ Category end ------ */
	
	/* ------ Sub Category start ------ */
	
	public function list_sub_category()
	{
        $data['udata']=$this->session->userdata;
        $data['sub_category'] = $this->Model_Setup->getAllSubCategory();
        $this->load->view('admin/setup/view_sub_category', $data);   
    }
	
	public function add_sub_category(){
        if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$category = $this->Model_Setup->getAllCategory();
			$data['category'] = $category;
			$this->load->view('admin/setup/add_sub_category', $data);
		} else {
			if($this->input->post('buttonSubmit')){
				$data['message'] = '';
				$this->form_validation->set_rules('category_id', 'Category Name', 'required');
				$this->form_validation->set_rules('sub_category', 'Sub Category Name', 'required');
				
				if($this->form_validation->run() == FALSE){
						$this->load->view('admin/setup/add_sub_category');
				} else {
					$data = array(
						'category_id' => $this->input->post('category_id'),
						'sub_category' => $this->input->post('sub_category'),
						
					);
					$this->Model_Setup->insert_sub_category($data);
					$this->session->set_flashdata('message','SUb Category Successfully Created.');
					redirect('admin/SetUp/list_sub_category');
				}
			}else{
				$this->load->view('admin/setup/add_sub_category');
			}
		}
	}
	
	public function edit_sub_category($id){
		
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$category = $this->Model_Setup->getAllCategory();
			$data['category'] = $category;
			$userRow = $this->Model_Setup->getSubCategory($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/setup/edit_sub_category', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'category_id' => $this->input->post('category_id'),
					'sub_category' => $this->input->post('sub_category'),
				);				
				
				$this->Model_Setup->editSubCategory($id, $data);
				$this->session->set_flashdata('message','Sub Category Edit Successfully.');
				redirect(base_url('admin/SetUp/list_sub_category'));
			} else {
				redirect(base_url('admin/SetUp/edit_sub_category/'.$id));
			}
		}
		
    }
	
	
	public function deleteSubCategory($id){
		
        if (isset($id)){	
            $this->Model_Setup->deleteSubCategory($id);
			$this->session->set_flashdata('message','Sub Category Successfully Deleted.');
            redirect(base_url('admin/SetUp/list_sub_category'));
        } else {
            redirect(base_url('admin/SetUp/list_sub_category'));
	    }
    }

	/* ------ Sub Category end ------ */
	
}

