<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SetUp extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin')) { 
            redirect('login');
        }
		
		$this->load->model('Model_Setup');
    }

	/* ------ Country start ------ */
	
	public function list_country()
	{
        $data['udata']=$this->session->userdata;
        $data['country'] = $this->Model_Setup->getAllCountry();
        $this->load->view('admin/setup/view_country', $data);   
    }
	
	public function add_country(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('sortname', 'Sort Name', 'required');
			$this->form_validation->set_rules('country_name', 'Country Name', 'required');
			$this->form_validation->set_rules('phonecode', 'Phone code ', 'required');
			if($this->form_validation->run() == FALSE){
					$this->load->view('admin/setup/add_country');
			} else {
				$data = array(
					'sortname' => $this->input->post('sortname'),
					'country_name' => $this->input->post('country_name'),
					'phonecode' => $this->input->post('phonecode'),
					'status' => $this->input->post('status')
				);
				$this->Model_Setup->insert_country($data);
				$this->session->set_flashdata('message','Country Successfully Created.');
				redirect('admin/SetUp/list_country');
			}
		}else{
			$this->load->view('admin/setup/add_country');
		}
	}
	
	public function edit_country($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Setup->getCountry($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/setup/edit_country', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'sortname' => $this->input->post('sortname'),
					'country_name' => $this->input->post('country_name'),
					'phonecode' => $this->input->post('phonecode'),
					'status' => $this->input->post('status')
				);				
				
				$this->Model_Setup->editCountry($id, $data);
				$this->session->set_flashdata('message','Country Edit Successfully.');
				redirect(base_url('admin/SetUp/list_country'));
			} else {
				redirect(base_url('admin/SetUp/edit_country/'.$id));
			}
		}
        
    }
	
	
	public function deleteCountry($id){
		
        if (isset($id)){	
            $this->Model_Setup->deleteCountry($id);
			$this->session->set_flashdata('message','Country Successfully Deleted.');
            redirect(base_url('admin/SetUp/list_country'));
        } else {
            redirect(base_url('admin/SetUp/list_country'));
	    }
    }

	/* ------ Country end ------ */
	
	
	/* ------ State start ------ */
	
	public function list_state()
	{
        $data['udata']=$this->session->userdata;
        $data['state'] = $this->Model_Setup->getAllState();
        $this->load->view('admin/setup/view_state', $data);   
    }
	
	public function add_state(){
        if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $userRow;
			$this->load->view('admin/setup/add_state', $data);
		} else {
			if($this->input->post('buttonSubmit')){
				$data['message'] = '';
				$this->form_validation->set_rules('state_name', 'State Name', 'required');
				$this->form_validation->set_rules('country_id', 'Country Name', 'required');
				if($this->form_validation->run() == FALSE){
						$this->load->view('admin/setup/add_state');
				} else {
					$data = array(
						'state_name' => $this->input->post('state_name'),
						'country_id' => $this->input->post('country_id'),
						'status' => $this->input->post('status')
					);
					$this->Model_Setup->insert_state($data);
					$this->session->set_flashdata('message','State Successfully Created.');
					redirect('admin/SetUp/list_state');
				}
			}else{
				$this->load->view('admin/setup/add_state');
			}
		}
	}
	
	public function edit_state($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$stateRow = $this->Model_Setup->getState($id);
			$data['userRow'] = $stateRow;
			$userRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $userRow;
			$this->load->view('admin/setup/edit_state', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'state_name' => $this->input->post('state_name'),
					'country_id' => $this->input->post('country_id'),
					'status' => $this->input->post('status')
				);				
				
				$this->Model_Setup->editState($id, $data);
				$this->session->set_flashdata('message','State Edit Successfully.');
				redirect(base_url('admin/SetUp/list_state'));
			} else {
				redirect(base_url('admin/SetUp/edit_state/'.$id));
			}
		}
        
    }
	
	
	public function deleteState($id){
		
        if (isset($id)){	
            $this->Model_Setup->deleteState($id);
			$this->session->set_flashdata('message','State Successfully Deleted.');
            redirect(base_url('admin/SetUp/list_state'));
        } else {
            redirect(base_url('admin/SetUp/list_state'));
	    }
    }

	/* ------ State end ------ */
	
	
	/* ------ City start ------ */
	
	public function list_city()
	{
        $data['udata']=$this->session->userdata;
        $data['city'] = $this->Model_Setup->getAllCity();
        $this->load->view('admin/setup/view_city', $data);   
    }
	
	public function add_city(){
        if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$countRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $countRow;
			$stateRow = $this->Model_Setup->getAllState();
			$data['stateList'] = $stateRow;
			$this->load->view('admin/setup/add_city', $data);
		} else {
			if($this->input->post('buttonSubmit')){
				$data['message'] = '';
				$this->form_validation->set_rules('city_name', 'City Name', 'required');
				$this->form_validation->set_rules('state_id', 'State Name', 'required');
				$this->form_validation->set_rules('country_id', 'Country Name', 'required');
				if($this->form_validation->run() == FALSE){
						$this->load->view('admin/setup/add_city');
				} else {
					$data = array(
						'city_name' => $this->input->post('city_name'),
						'state_id' => $this->input->post('state_id'),
						'country_id' => $this->input->post('country_id'),
						'status' => $this->input->post('status')
					);
					$this->Model_Setup->insert_city($data);
					$this->session->set_flashdata('message','City Successfully Created.');
					redirect('admin/SetUp/list_city');
				}
			}else{
				$this->load->view('admin/setup/add_city');
			}
		}
	}
	
	public function edit_city($id){
		
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Setup->getCity($id);
			$data['userRow'] = $userRow;
			$stateRow = $this->Model_Setup->getAllState();
			$data['stateList'] = $stateRow;
			$countryRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $countryRow;
			$this->load->view('admin/setup/edit_city', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'city_name' => $this->input->post('city_name'),
					'state_id' => $this->input->post('state_id'),
					'country_id' => $this->input->post('country_id'),
					'status' => $this->input->post('status')
				);				
				
				$this->Model_Setup->editCity($id, $data);
				$this->session->set_flashdata('message','City Edit Successfully.');
				redirect(base_url('admin/SetUp/list_city'));
			} else {
				redirect(base_url('admin/SetUp/edit_city/'.$id));
			}
		}
        
    }
	
	
	public function deleteCity($id){
		
        if (isset($id)){	
            $this->Model_Setup->deleteCity($id);
			$this->session->set_flashdata('message','City Successfully Deleted.');
            redirect(base_url('admin/SetUp/list_city'));
        } else {
            redirect(base_url('admin/SetUp/list_city'));
	    }
    }

	/* ------ City end ------ */
	
}

