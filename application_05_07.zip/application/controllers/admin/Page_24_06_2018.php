<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin')) { 
            redirect('login');
        }
		
		$this->load->model('Model_Page');
		$this->load->model('Model_Setup');
    }

	/* ------ About Us start ------ */
	
	public function list_about()
	{
        $data['udata']=$this->session->userdata;
        $data['aboutus'] = $this->Model_Page->getAllAbout();
        $this->load->view('admin/page/view_about', $data);   
    }
	
	public function add_about(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('content', 'Content', 'required');
			if($this->form_validation->run() == FALSE){
				$this->load->view('admin/page/add_about');
			} else {
				$config['upload_path']          = 'assets/newimg/about/';
				$config['allowed_types']        = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);
				$this->upload->do_upload('image');
				$data = $this->upload->data();
				$image = $data['file_name']; 
				
				$data = array(
					'image' => $image,
					'title' => $this->input->post('title'),
					'content' => $this->input->post('content'),
					'status' => $this->input->post('status'),
					'created' => date('Y-m-d')
				);
				$this->Model_Page->insert_about($data);
				$this->session->set_flashdata('message','About Us Successfully Created.');
				redirect('admin/Page/list_about');
			}
		}else{
			$this->load->view('admin/page/add_about');
		}
	}
	
	public function edit_about($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Page->getAbout($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/page/edit_about', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$config['upload_path']          = 'assets/newimg/about/';
				$config['allowed_types']        = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);
				$this->upload->do_upload('image');
				$data = $this->upload->data();
				$image = $data['file_name'];
				
				if($image != ''){
					$userRow = $this->Model_Page->getAbout($id);
					unlink('assets/newimg/about/'.$userRow[0]['image']);
				}else {
					$userRow = $this->Model_Page->getAbout($id);
					$image =$userRow[0]['image'];
				}
				
				$data = array(
					'image' => $image,
					'title' => $this->input->post('title'),
					'content' => $this->input->post('content'),
					'status' => $this->input->post('status'),
					'modify' => date('Y-m-d')
				);				
				
				$this->Model_Page->editAbout($id, $data);
				$this->session->set_flashdata('message','About Us Edit Successfully.');
				redirect(base_url('admin/Page/list_about'));
			} else {
				redirect(base_url('admin/Page/edit_about/'.$id));
			}
		}
        
    }
	
	
	public function deleteAbout($id){
		
        if (isset($id)){
			
			$userRow = $this->Model_Page->getAbout($id);
			unlink('assets/newimg/about/'.$userRow[0]['image']);
				
            $this->Model_Page->deleteAbout($id);
			$this->session->set_flashdata('message','About Us Successfully Deleted.');
            redirect(base_url('admin/Page/list_about'));
        } else {
            redirect(base_url('admin/Page/list_about'));
	    }
    }

	/* ------ About Us end ------ */
	
	/* ------ Membership Plane start ------ */
	
	public function list_memb_ship()
	{
        $data['udata']=$this->session->userdata;
        $data['memship'] = $this->Model_Page->getAllMemShip();
        $this->load->view('admin/page/view_memb_ship', $data);   
    }
	
	public function add_memb_ship(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('image', 'Icon Code', 'required');
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('head_1', 'Head 1', 'required');
			$this->form_validation->set_rules('head_2', 'Head 2', 'required');
			$this->form_validation->set_rules('head_3', 'Head 3', 'required');
			$this->form_validation->set_rules('head_4', 'Head 4', 'required');
			$this->form_validation->set_rules('head_5', 'Head 5', 'required');
			$this->form_validation->set_rules('price', 'Price', 'required');
			
			if($this->form_validation->run() == FALSE){
				$this->load->view('admin/page/add_memb_ship');
			} else {
				$data = array(
					'image' => $this->input->post('image'),
					'title' => $this->input->post('title'),
					'head_1' => $this->input->post('head_1'),
					'head_2' => $this->input->post('head_2'),
					'head_3' => $this->input->post('head_3'),
					'head_4' => $this->input->post('head_4'),
					'head_5' => $this->input->post('head_5'),
					'price' => $this->input->post('price'),
					'curency' => $this->input->post('curency'),
					'status' => $this->input->post('status'),
					'created' => date('Y-m-d')
				);
				$this->Model_Page->insert_memb_ship($data);
				$this->session->set_flashdata('message','Member Ship Successfully Created.');
				redirect('admin/Page/list_memb_ship');
			}
		}else{
			$this->load->view('admin/page/add_memb_ship');
		}
	}
	
	public function edit_memb_ship($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Page->getMemShip($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/page/edit_memb_ship', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'image' => $this->input->post('image'),
					'title' => $this->input->post('title'),
					'head_1' => $this->input->post('head_1'),
					'head_2' => $this->input->post('head_2'),
					'head_3' => $this->input->post('head_3'),
					'head_4' => $this->input->post('head_4'),
					'head_5' => $this->input->post('head_5'),
					'price' => $this->input->post('price'),
					'curency' => $this->input->post('curency'),
					'status' => $this->input->post('status'),
					'modify' => date('Y-m-d')
				);				
				
				$this->Model_Page->editMemShip($id, $data);
				$this->session->set_flashdata('message','Member Ship Edit Successfully.');
				redirect(base_url('admin/Page/list_memb_ship'));
			} else {
				redirect(base_url('admin/Page/edit_memb_ship/'.$id));
			}
		}
        
    }
	
	
	public function deleteMemShip($id){
		
        if (isset($id)){
			$this->Model_Page->deleteMemShip($id);
			$this->session->set_flashdata('message','Member Ship Successfully Deleted.');
            redirect(base_url('admin/Page/list_memb_ship'));
        } else {
            redirect(base_url('admin/Page/list_memb_ship'));
	    }
    }

	/* ------ Membership Plane end ------ */
	
	
	/* ------ Country City start ------ */
	
	public function list_count_city()
	{
        $data['udata']=$this->session->userdata;
        $data['countCity'] = $this->Model_Page->getAllCountCity();
		$this->load->view('admin/page/view_count_city', $data);   
    }
	
	public function add_count_city(){
        if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->load->model('Model_Setup');
			$countRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $countRow;
			$stateRow = $this->Model_Setup->getAllState();
			$data['stateList'] = $stateRow;
			$cityRow = $this->Model_Setup->getAllCity();
			$data['cityList'] = $cityRow;
			$this->load->view('admin/page/add_count_city', $data);
		} else {
			if($this->input->post('buttonSubmit')){
				$data['message'] = '';
				$this->form_validation->set_rules('title', 'Title', 'required');
				$this->form_validation->set_rules('city_id', 'City', 'required');
				$this->form_validation->set_rules('state_id', 'State', 'required');
				$this->form_validation->set_rules('country_id', 'Country', 'required');
				
				if($this->form_validation->run() == FALSE){
					$this->load->view('admin/page/add_count_city');
				} else {
					$config['upload_path']          = 'assets/images/country/';
					$config['allowed_types']        = 'gif|jpg|png|jpeg';
					$this->load->library('upload', $config);
					$this->upload->do_upload('image');
					$data = $this->upload->data();
					$image = $data['file_name']; 
					$data = array(
						'image' => $image,
						'title' => $this->input->post('title'),
						'city_id' => $this->input->post('city_id'),
						'state_id' => $this->input->post('state_id'),
						'country_id' => $this->input->post('country_id'),
						'status' => $this->input->post('status'),
						'created' => date('Y-m-d'),
						'page_title' => $this->input->post('page_title'),
						'meta_title' => $this->input->post('meta_title'),
						'alt_tag' => $this->input->post('alt_tag'),
						'type' => $this->input->post('type'),
					);
					$data['meta_tbl'] = array(
						'meta_name' => $this->input->post('meta_name'),  
						'meta_description' => $this->input->post('meta_description'),
						'page_type' => 'city_count'
					);
					
					$this->Model_Page->insert_count_city($data);
					$this->session->set_flashdata('message','City/Country Successfully Created.');
					redirect('admin/Page/list_count_city');
				}
			}else{
				$this->load->view('admin/page/add_count_city');
			}
		}
	}
	
	public function edit_count_city($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->load->model('Model_Setup');
			$countRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $countRow;
			$stateRow = $this->Model_Setup->getAllState();
			$data['stateList'] = $stateRow;
			$cityRow = $this->Model_Setup->getAllCity();
			$data['cityList'] = $cityRow;
			$metaDesc = $this->Model_Page->getMetaDesc($id);
			$data['metaDesc'] = $metaDesc;
			$userRow = $this->Model_Page->getCountCity($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/page/edit_count_city', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				$this->form_validation->set_rules('image', 'Image', 'required');
				$this->form_validation->set_rules('title', 'Title', 'required');
				$this->form_validation->set_rules('city_id', 'City', 'required');
				$this->form_validation->set_rules('state_id', 'State', 'required');
				$this->form_validation->set_rules('country_id', 'Country', 'required');
				
				$config['upload_path']          = 'assets/images/country/';
				$config['allowed_types']        = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);
				$this->upload->do_upload('image');
				$data = $this->upload->data();
				$image = $data['file_name'];
				
				if($image != ''){
					//$userRow = $this->Model_Page->getCountCity($id);
					unlink('assets/images/country/'.$this->input->post('image_hidd'));
				} else {
					$userRow = $this->Model_Page->getCountCity($id);
					$image =$this->input->post('image_hidd');
				}
								
				$data = array(
					'image' => $image,
					'title' => $this->input->post('title'),
					'city_id' => $this->input->post('city_id'),
					'state_id' => $this->input->post('state_id'),
					'country_id' => $this->input->post('country_id'),
					'status' => $this->input->post('status'),
					'modify' => date('Y-m-d'),
					'page_title' => $this->input->post('page_title'),
					'meta_title' => $this->input->post('meta_title'),
					'alt_tag' => $this->input->post('alt_tag'),
					'type' => $this->input->post('type'),
					
				);
				$data['meta_tbl'] = array(
					'meta_id' => $this->input->post('meta_id'),  
					'meta_name' => $this->input->post('meta_name'),  
					'meta_description' => $this->input->post('meta_description'),
					'page_type' => 'city_count'
				);
				//echo '<pre>'; print_r($data); die; 
				$this->Model_Page->editCountCity($id, $data);
				$this->session->set_flashdata('message','City/Country Edit Successfully.');
				redirect(base_url('admin/Page/list_count_city'));
			} else {
				redirect(base_url('admin/Page/edit_count_city/'.$id));
			}
		}
        
    }
	
	
	public function deleteCountCity($id){
		
        if (isset($id)){
			
			$userRow = $this->Model_Page->getCountCity($id);
			unlink('assets/images/country/'.$userRow[0]['image']);
				
            $this->Model_Page->deleteCountCity($id);
			$this->session->set_flashdata('message','City/Country Successfully Deleted.');
            redirect(base_url('admin/Page/list_count_city'));
        } else {
            redirect(base_url('admin/Page/list_count_city'));
	    }
    }

	/* ------ Country City end ------ */
	
	
	/* ------ Add Data start ------ */
	
	public function list_add_data()
	{
        $data['udata']=$this->session->userdata;
        $data['addData'] = $this->Model_Page->getAllAddData($data['udata']['id']);
		$this->load->view('admin/page/view_add_data', $data);   
    }
	
	public function add_add_data(){
		
        if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->load->model('Model_Setup');
			$data['category'] = $this->Model_Setup->getAllCategory();
			$data['subCategory'] = $this->Model_Setup->getAllSubCategory();
			$data['countCity'] = $this->Model_Page->getAllCountCityForPost();
			$countRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $countRow;
			$stateRow = $this->Model_Setup->getAllState();
			$data['stateList'] = $stateRow;
			$cityRow = $this->Model_Setup->getAllCity();
			$data['cityList'] = $cityRow;
			//$data['udata']=$this->session->userdata;
			$this->load->view('admin/page/add_add_data', $data);
		} else {
			if($this->input->post('buttonSubmit')){
				$data['message'] = '';
				$this->form_validation->set_rules('category_id', 'Category', 'required');
				$this->form_validation->set_rules('title', 'Title', 'required');
				$this->form_validation->set_rules('description', 'Description', 'required');
				//$this->form_validation->set_rules('city_country_id', 'City/Country', 'required');
				$this->form_validation->set_rules('location', 'Location/Address', 'required');
				$this->form_validation->set_rules('contact_person', 'Contact Person', 'required');
				$this->form_validation->set_rules('cont_number', 'Contact Number ', 'required');
				$this->form_validation->set_rules('email', 'Email', 'required');
				
				$this->form_validation->set_rules('city_id', 'City', 'required');
				$this->form_validation->set_rules('state_id', 'State', 'required');
				$this->form_validation->set_rules('country_id', 'Country', 'required');
				
				
				if($this->form_validation->run() == FALSE){
					$this->load->view('admin/page/add_add_data');
				} else {
					
					$config['upload_path']          = 'assets/images/add_data/';
					$config['allowed_types']        = 'gif|jpg|png|jpeg';
					$this->load->library('upload', $config);
					$this->upload->do_upload('image');
					$data = $this->upload->data();
					$image = $data['file_name']; 
									
					$data = array(
						'image' => $image,
						'title' => $this->input->post('title'),
						'contact_person' => $this->input->post('contact_person'),
						'cont_number' => $this->input->post('cont_number'),
						'email' => $this->input->post('email'),
						'map_link' => $this->input->post('map_link'),
						//'city_country_id' => $this->input->post('city_country_id'),
						'city_id' => $this->input->post('city_id'),
						'state_id' => $this->input->post('state_id'),
						'country_id' => $this->input->post('country_id'),
						'description' => $this->input->post('description'),
						'location' => $this->input->post('location'),
						'address' => $this->input->post('address'),
						'status' => $this->input->post('status'),
						'created' => date('Y-m-d'),
						'page_title' => $this->input->post('page_title'),
						'meta_title' => $this->input->post('meta_title'),
						'alt_tag' => $this->input->post('alt_tag'),
						'type' => $this->input->post('type'),
						'category_id' => $this->input->post('category_id'),
						'sub_category_id' => $this->input->post('sub_category_id'),
						'user_id' => $this->input->post('user_id'),
					);
					$data['meta_tbl'] = array(
						'meta_name' => $this->input->post('meta_name'),  
						'meta_description' => $this->input->post('meta_description'),
						'page_type' => 'post'
					);
					
					$this->Model_Page->insert_add_data($data);
					$this->session->set_flashdata('message','Post Added Successfully Created.');
					redirect('admin/Page/list_add_data');
				}
			}else{
				$this->load->view('admin/page/add_add_data');
			}
		}
	}
	
	public function edit_add_data($id){
		//
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			
			$data['countCity'] = $this->Model_Page->getAllCountCityForPost();
			//$data['countCity'] = $countCity;
			$this->load->model('Model_Setup');
			$data['category'] = $this->Model_Setup->getAllCategory();
			$data['subCategory'] = $this->Model_Setup->getAllSubCategory();
			$countRow = $this->Model_Setup->getAllCountry();
			$data['countList'] = $countRow;
			$stateRow = $this->Model_Setup->getAllState();
			$data['stateList'] = $stateRow;
			$cityRow = $this->Model_Setup->getAllCity();
			$data['cityList'] = $cityRow;
			$metaDesc = $this->Model_Page->getMetaDescPost($id);
			$data['metaDesc'] = $metaDesc;
			//$data['udata']=$this->session->userdata;
			$userRow = $this->Model_Page->getAddData($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/page/edit_add_data', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				$this->form_validation->set_rules('category_id', 'Category', 'required');
				$this->form_validation->set_rules('title', 'Title', 'required');
				$this->form_validation->set_rules('description', 'Description', 'required');
				//$this->form_validation->set_rules('city_country_id', 'City/Country', 'required');
				$this->form_validation->set_rules('location', 'Location/Address', 'required');
				$this->form_validation->set_rules('contact_person', 'Contact Person', 'required');
				$this->form_validation->set_rules('cont_number', 'Contact Number ', 'required');
				$this->form_validation->set_rules('email', 'Email', 'required');
				$this->form_validation->set_rules('city_id', 'City', 'required');
				$this->form_validation->set_rules('state_id', 'State', 'required');
				$this->form_validation->set_rules('country_id', 'Country', 'required');
				
				$config['upload_path']          = 'assets/images/add_data/';
				$config['allowed_types']        = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);
				$this->upload->do_upload('image');
				$data = $this->upload->data();
				$image = $data['file_name'];
				
				if($image != ''){
					//$userRow = $this->Model_Page->getCountCity($id);
					unlink('assets/images/add_data/'.$this->input->post('image_hidd'));
				} else {
					$userRow = $this->Model_Page->getAddData($id);
					$image =$this->input->post('image_hidd');
				}
								
				$data = array(
						'image' => $image,
						'title' => $this->input->post('title'),
						'contact_person' => $this->input->post('contact_person'),
						'cont_number' => $this->input->post('cont_number'),
						'email' => $this->input->post('email'),
						'map_link' => $this->input->post('map_link'),
						//'city_country_id' => $this->input->post('city_country_id'),
						'city_id' => $this->input->post('city_id'),
						'state_id' => $this->input->post('state_id'),
						'country_id' => $this->input->post('country_id'),
						'description' => $this->input->post('description'),
						'location' => $this->input->post('location'),
						'address' => $this->input->post('address'),
						'status' => $this->input->post('status'),
						'created' => date('Y-m-d'),
						'page_title' => $this->input->post('page_title'),
						'meta_title' => $this->input->post('meta_title'),
						'alt_tag' => $this->input->post('alt_tag'),
						'type' => $this->input->post('type'),
						'category_id' => $this->input->post('category_id'),
						'sub_category_id' => $this->input->post('sub_category_id'),
						'user_id' => $this->input->post('user_id'),
					);
					$data['meta_tbl'] = array(
						'meta_id' => $this->input->post('meta_id'),
						'meta_name' => $this->input->post('meta_name'),  
						'meta_description' => $this->input->post('meta_description'),
						'page_type' => 'post'
					);
				//echo '<pre>'; print_r($data); die; 
				$this->Model_Page->editAddData($id, $data);
				$this->session->set_flashdata('message','Post Added  Edit Successfully.');
				redirect(base_url('admin/Page/list_add_data'));
			} else {
				redirect(base_url('admin/Page/edit_add_data/'.$id));
			}
		}
        
    }
	
	
	public function deleteAddData($id){
		
        if (isset($id)){
			
			$userRow = $this->Model_Page->getAddData($id);
			unlink('assets/images/add_data/'.$userRow[0]['image']);
				
            $this->Model_Page->deleteAddData($id);
			$this->session->set_flashdata('message','Post Successfully Deleted.');
            redirect(base_url('admin/Page/list_add_data'));
        } else {
            redirect(base_url('admin/Page/list_add_data'));
	    }
    }

	/* ------ Country City end ------ */
	
	/* ------ List Contact Us Users ------ */
	
	
	public function list_contact_us()
	{
        $data['udata']=$this->session->userdata;
        $data['allData'] = $this->Model_Page->getAllContactUs();
		$this->load->view('admin/page/view_contact_us', $data);   
    }
	
	/* ------ List Contact Us Users ------ */
	
	
	/* ------ FAQ start ------ */
	
	public function list_faq()
	{
        $data['udata']=$this->session->userdata;
        $data['allFaq'] = $this->Model_Page->getAllFaq();
        $this->load->view('admin/page/view_faq', $data);   
    }
	
	public function add_faq(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('question', 'Question', 'required');
			$this->form_validation->set_rules('answere', 'Answere', 'required');
			if($this->form_validation->run() == FALSE){
				$this->load->view('admin/page/add_faq');
			} else {
				
				
				$data = array(
					
					'question' => $this->input->post('question'),
					'answere' => $this->input->post('answere'),
					'status' => $this->input->post('status'),
					'created' => date('Y-m-d')
				);
				$this->Model_Page->insert_faq($data);
				$this->session->set_flashdata('message','FAQ Successfully Created.');
				redirect('admin/Page/list_faq');
			}
		}else{
			$this->load->view('admin/page/add_faq');
		}
	}
	
	public function edit_faq($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Page->getFaq($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/page/edit_faq', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
			$data['message'] = '';
			$this->form_validation->set_rules('question', 'Question', 'required');
			$this->form_validation->set_rules('answere', 'Answere', 'required');
			if($this->form_validation->run() == FALSE){
				$this->load->view('admin/page/edit_faq');
			} else {
				
				
				$data = array(
					
					'question' => $this->input->post('question'),
					'answere' => $this->input->post('answere'),
					'status' => $this->input->post('status'),
					'modify' => date('Y-m-d')
				);
				
				$this->Model_Page->editFaq($id, $data);
				$this->session->set_flashdata('message','FAQ Edit Successfully.');
				redirect(base_url('admin/Page/list_faq'));
			}	
				
			} else {
				redirect(base_url('admin/Page/edit_faq/'.$id));
			}
		}
        
    }
	
	
	public function deleteFaq($id){
		
        if (isset($id)){
			
			$this->Model_Page->deleteFaq($id);
			$this->session->set_flashdata('message','FAQ Successfully Deleted.');
            redirect(base_url('admin/Page/list_faq'));
        } else {
            redirect(base_url('admin/Page/list_faq'));
	    }
    }

	/* ------ FAQ end ------ */
	
	
	/* ------ Blog start ------ */
	
	public function list_blog()
	{
        $data['udata']=$this->session->userdata;
        $data['allBlog'] = $this->Model_Page->getAllBlog();
        $this->load->view('admin/page/view_blog', $data);   
    }
	
	public function add_blog(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('description', 'Description', 'required');
			if($this->form_validation->run() == FALSE){
				$this->load->view('admin/page/add_boq');
			} else {
				$config['upload_path']          = 'assets/newimg/blog/';
				$config['allowed_types']        = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);
				$this->upload->do_upload('image');
				$data = $this->upload->data();
				$image = $data['file_name']; 
				
				$data = array(
						'image' => $image,
						'title' => $this->input->post('title'),
						'description' => $this->input->post('description'),
						'status' => $this->input->post('status'),
						'page_title' => $this->input->post('page_title'),
						'meta_title' => $this->input->post('meta_title'),
						'alt_tag' => $this->input->post('alt_tag'),
						'type' => $this->input->post('type'),
						'created' => $this->input->post('created'),
					);
					
					$data['meta_tbl'] = array(
						'meta_id' => $this->input->post('meta_id'),
						'meta_name' => $this->input->post('meta_name'),  
						'meta_description' => $this->input->post('meta_description'),
						'page_type' => 'blog'
					);
				$this->Model_Page->insert_blog($data);
				$this->session->set_flashdata('message','Blog Successfully Created.');
				redirect('admin/Page/list_blog');
			}
		}else{
			$this->load->view('admin/page/add_blog');
		}
	}
	
	public function edit_blog($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$metaDesc = $this->Model_Page->getMetaDescBlog($id);
			$data['metaDesc'] = $metaDesc;
			$userRow = $this->Model_Page->getBlog($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/page/edit_blog', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$config['upload_path']          = 'assets/newimg/blog/';
				$config['allowed_types']        = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);
				$this->upload->do_upload('image');
				$data = $this->upload->data();
				$image = $data['file_name'];
				
				if($image != ''){
					$userRow = $this->Model_Page->getBlog($id);
					unlink('assets/newimg/blog/'.$userRow[0]['image']);
				}else {
					$userRow = $this->Model_Page->getBlog($id);
					$image =$userRow[0]['image'];
				}
				
				$data = array(
					'image' => $image,
					'title' => $this->input->post('title'),
					'description' => $this->input->post('description'),
					'status' => $this->input->post('status'),
					'page_title' => $this->input->post('page_title'),
					'meta_title' => $this->input->post('meta_title'),
					'alt_tag' => $this->input->post('alt_tag'),
					'type' => $this->input->post('type'),
					'modify' => date('Y-m-d h:i:s'),
				);
					
					$data['meta_tbl'] = array(
						'meta_id' => $this->input->post('meta_id'),
						'meta_name' => $this->input->post('meta_name'),  
						'meta_description' => $this->input->post('meta_description'),
						'page_type' => 'blog'
					);			
				
				$this->Model_Page->editBlog($id, $data);
				$this->session->set_flashdata('message','Blog Edit Successfully.');
				redirect(base_url('admin/Page/list_blog'));
			} else {
				redirect(base_url('admin/Page/edit_blog/'.$id));
			}
		}
        
    }
	
	
	public function deleteBlog($id){
		
        if (isset($id)){
			
			$userRow = $this->Model_Page->getBlog($id);
			unlink('assets/newimg/blog/'.$userRow[0]['image']);
				
            $this->Model_Page->deleteBlog($id);
			$this->session->set_flashdata('message','Blog Successfully Deleted.');
            redirect(base_url('admin/Page/list_blog'));
        } else {
            redirect(base_url('admin/Page/list_blog'));
	    }
    }

	/* ------ Blog end ------ */
	
	
	/* ------ Policy start ------ */
	
	public function list_policy()
	{
        $data['udata']=$this->session->userdata;
        $data['allPolicy'] = $this->Model_Page->getAllPolicy();
        $this->load->view('admin/page/view_policy', $data);   
    }
	
	public function add_policy(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('discription', 'Description', 'required');
			$this->form_validation->set_rules('type', 'Policy Type', 'required');
			if($this->form_validation->run() == FALSE){
				$this->load->view('admin/page/add_policy');
			} else {
				$data = array(
					
					'title' => $this->input->post('title'),
					'description' => $this->input->post('description'),
					'type' => $this->input->post('type'),
					'status' => $this->input->post('status'),
					'created' => date('Y-m-d')
				);
				$this->Model_Page->insert_policy($data);
				$this->session->set_flashdata('message','Policy Successfully Created.');
				redirect('admin/Page/list_faq');
			}
		}else{
			$this->load->view('admin/page/add_policy');
		}
	}
	
	public function edit_policy($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Page->getpolicy($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/page/edit_policy', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
			$data['message'] = '';
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('discription', 'Description', 'required');
			$this->form_validation->set_rules('type', 'Policy Type', 'required');
			if($this->form_validation->run() == FALSE){
				$this->load->view('admin/page/edit_policy');
			} else {
				
				
				$data = array(
					
					'title' => $this->input->post('title'),
					'discription' => $this->input->post('discription'),
					'type' => $this->input->post('type'),
					'status' => $this->input->post('status'),
					'modify' => date('Y-m-d')
				);
				
				$this->Model_Page->editPolicy($id, $data);
				$this->session->set_flashdata('message','Policy Edit Successfully.');
				redirect(base_url('admin/Page/list_policy'));
			}	
				
			} else {
				redirect(base_url('admin/Page/edit_policy/'.$id));
			}
		}
        
    }
	
	
	public function deletePolicy($id){
		
        if (isset($id)){
			
			$this->Model_Page->deletePolicy($id);
			$this->session->set_flashdata('message','Policy Successfully Deleted.');
            redirect(base_url('admin/Page/list_policy'));
        } else {
            redirect(base_url('admin/Page/list_policy'));
	    }
    }

	/* ------ Policy end ------ */
	
	
	/* Import Post */
	
	
	
	
	function importExcel(){
		$file = $_FILES['upload']['tmp_name'];
		
		$this->load->library('excel');
		
		$objPHPExcel = PHPExcel_IOFactory::load($file);
		
		$cell_collection = $objPHPExcel->getActiveSheet()->getCellCollection();
		
		
		foreach ($cell_collection as $cell) {
		 $column = $objPHPExcel->getActiveSheet()->getCell($cell)->getColumn();
		 $row = $objPHPExcel->getActiveSheet()->getCell($cell)->getRow();
		 $data_value = $objPHPExcel->getActiveSheet()->getCell($cell)->getValue();
		
			 if ($row == 1) {
			 $arr_data[$row][$column] = $data_value;
			 } else {
			 $arr_data[$row][$column] = $data_value;
			 }
			
		}
		$this->Model_Page->insertExcel($arr_data);		
		
	}
	
	/* function importExcel(){
		if ($this->input->post('submit')) {
			$path = 'uploads/excel/';
            require_once APPPATH . "/third_party/Classes/PHPExcel.php";
			echo APPPATH . "third_party/Classes/PHPExcel.php"; die;
            $config['upload_path'] = $path;
            $config['allowed_types'] = 'xlsx|xls';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload', $config);
            $this->upload->initialize($config);            
            echo 'test 1';
			if (!$this->upload->do_upload('uploadFile')) {
                $error = array('error' => $this->upload->display_errors());
            } else {
                $data = array('upload_data' => $this->upload->data());
            }
			echo 'test 2';
            if(empty($error)){
				if (!empty($data['upload_data']['file_name'])) {
					$import_xls_file = $data['upload_data']['file_name'];
				} else {
					$import_xls_file = 0;
				}
				$inputFileName = $path . $import_xls_file;
				print_r($inputFileName); die;
				try {
					$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
					$objReader = PHPExcel_IOFactory::createReader($inputFileType);
					$objPHPExcel = $objReader->load($inputFileName);
					$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
					$flag = true;
					$i=0;
					foreach ($allDataInSheet as $value) {
					  if($flag){
						$flag =false;
						continue;
					  }
					  $inserdata[$i]['org_name'] = $value['A'];
					  $inserdata[$i]['org_code'] = $value['B'];
					  $inserdata[$i]['gst_no'] = $value['C'];
					  $inserdata[$i]['org_type'] = $value['D'];
					  $inserdata[$i]['Address'] = $value['E'];
					  $i++;
					}               
					$result = $this->import->importdata($inserdata);   
					if($result){
					  echo "Imported successfully";
					}else{
					  echo "ERROR !";
					}             
 
				} catch (Exception $e) {
					die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
                        . '": ' .$e->getMessage());
				}
			} else{
              echo $error['error'];
            }
      
		 $this->load->view('admin/page/view_add_data');
		}
	} */
	
	/* Import Post */
	
	/* ajax corner */
	
	function getSubCategoryByID(){
		$this->load->model('Model_Setup');
		$getCatID = $this->input->post('cat_id');
		$data['subCategoryByID'] = $this->Model_Setup->getSubCategory($getCatID);
		$data1 = '';
		$data1 .= '<option value="0">--select--</option>';
		foreach($data['subCategoryByID'] as $val){
			$data1 .= '<option value='.$val["sub_category_id"].'>'.$val["sub_category"].'</option>';
		}
		print_r($data1);
		die;
	}
	
	/* ajax corner */
}

