<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Car_Model extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin') || $this->session->userdata('type')!="admin") { 
            redirect('controller_login');
        }
		
		$this->load->database();
		$this->load->model('Model_Manufacturer');
		$this->load->model('Model_Car_Model');
	}


	public function index()
	{
		$data['manufacturers'] = $this->Model_Manufacturer->getAllManufacturers();
		$data['models'] = $this->Model_Car_Model->getAllModels();
		// $this->load->view('admin/car_model', $data);
		$this->load->view('admin/view_car_model', $data);
	}

	public function addmodel()
	{	
		if(! $this->input->post('buttonSubmit')) {
			redirect(base_url('admin/car_model'));
		}

		else {
			$model_name = $this->input->post('model_name');
			$manufacturer_id = $this->input->post('manufacturer_id');
			$description = $this->input->post('model_description');

			$this->Model_Car_Model->insertmodel($model_name, $manufacturer_id, $description);
			$this->session->set_flashdata('message','Model Created Successfully.');
			redirect(base_url('admin/car_model'));
		}
	}

	public function deleteModel($cid)
	{	
        $this->Model_Car_Model->deleteModel($cid);
        $this->session->set_flashdata('message','Model Deleted Successfully.');
        redirect(base_url('admin/car_model'));
	}
}