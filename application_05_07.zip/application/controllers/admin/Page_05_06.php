<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin')) { 
            redirect('login');
        }
		
		$this->load->model('Model_Page');
    }

	/* ------ About Us start ------ */
	
	public function list_about()
	{
        $data['udata']=$this->session->userdata;
        $data['aboutus'] = $this->Model_Page->getAllAbout();
        $this->load->view('admin/page/view_about', $data);   
    }
	
	public function add_about(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('content', 'Content', 'required');
			if($this->form_validation->run() == FALSE){
				$this->load->view('admin/page/add_about');
			} else {
				$config['upload_path']          = 'assets/newimg/about/';
				$config['allowed_types']        = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);
				$this->upload->do_upload('image');
				$data = $this->upload->data();
				$image = $data['file_name']; 
				
				$data = array(
					'image' => $image,
					'title' => $this->input->post('title'),
					'content' => $this->input->post('content'),
					'status' => $this->input->post('status'),
					'created' => date('Y-m-d')
				);
				$this->Model_Page->insert_about($data);
				$this->session->set_flashdata('message','About Us Successfully Created.');
				redirect('admin/Page/list_about');
			}
		}else{
			$this->load->view('admin/page/add_about');
		}
	}
	
	public function edit_about($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Page->getAbout($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/page/edit_about', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$config['upload_path']          = 'assets/newimg/about/';
				$config['allowed_types']        = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);
				$this->upload->do_upload('image');
				$data = $this->upload->data();
				$image = $data['file_name'];
				
				if($image != ''){
					$userRow = $this->Model_Page->getAbout($id);
					unlink('assets/newimg/about/'.$userRow[0]['image']);
				}
				
				$data = array(
					'image' => $image,
					'title' => $this->input->post('title'),
					'content' => $this->input->post('content'),
					'status' => $this->input->post('status'),
					'modify' => date('Y-m-d')
				);				
				
				$this->Model_Page->editAbout($id, $data);
				$this->session->set_flashdata('message','About Us Edit Successfully.');
				redirect(base_url('admin/Page/list_about'));
			} else {
				redirect(base_url('admin/Page/edit_about/'.$id));
			}
		}
        
    }
	
	
	public function deleteAbout($id){
		
        if (isset($id)){
			
			$userRow = $this->Model_Page->getAbout($id);
			unlink('assets/newimg/about/'.$userRow[0]['image']);
				
            $this->Model_Page->deleteAbout($id);
			$this->session->set_flashdata('message','About Us Successfully Deleted.');
            redirect(base_url('admin/Page/list_about'));
        } else {
            redirect(base_url('admin/Page/list_about'));
	    }
    }

	/* ------ About Us end ------ */
	
	/* ------ Membership Plane start ------ */
	
	public function list_memb_ship()
	{
        $data['udata']=$this->session->userdata;
        $data['memship'] = $this->Model_Page->getAllMemShip();
        $this->load->view('admin/page/view_memb_ship', $data);   
    }
	
	public function add_memb_ship(){
        if($this->input->post('buttonSubmit')){
			$data['message'] = '';
			$this->form_validation->set_rules('image', 'Icon Code', 'required');
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('head_1', 'Head 1', 'required');
			$this->form_validation->set_rules('head_2', 'Head 2', 'required');
			$this->form_validation->set_rules('head_3', 'Head 3', 'required');
			$this->form_validation->set_rules('head_4', 'Head 4', 'required');
			$this->form_validation->set_rules('head_5', 'Head 5', 'required');
			$this->form_validation->set_rules('price', 'Price', 'required');
			
			if($this->form_validation->run() == FALSE){
				$this->load->view('admin/page/add_memb_ship');
			} else {
				$data = array(
					'image' => $this->input->post('image'),
					'title' => $this->input->post('title'),
					'head_1' => $this->input->post('head_1'),
					'head_2' => $this->input->post('head_2'),
					'head_3' => $this->input->post('head_3'),
					'head_4' => $this->input->post('head_4'),
					'head_5' => $this->input->post('head_5'),
					'price' => $this->input->post('price'),
					'curency' => $this->input->post('curency'),
					'status' => $this->input->post('status'),
					'created' => date('Y-m-d')
				);
				$this->Model_Page->insert_memb_ship($data);
				$this->session->set_flashdata('message','Member Ship Successfully Created.');
				redirect('admin/Page/list_memb_ship');
			}
		}else{
			$this->load->view('admin/page/add_memb_ship');
		}
	}
	
	public function edit_memb_ship($id){
		if(!$this->input->post('buttonSubmit')){
			$data['message'] = '';
			$userRow = $this->Model_Page->getMemShip($id);
			$data['userRow'] = $userRow;
			$this->load->view('admin/page/edit_memb_ship', $data);
		} else {
			if ($this->input->server('REQUEST_METHOD') == 'POST'){	
				
				$data = array(
					'image' => $this->input->post('image'),
					'title' => $this->input->post('title'),
					'head_1' => $this->input->post('head_1'),
					'head_2' => $this->input->post('head_2'),
					'head_3' => $this->input->post('head_3'),
					'head_4' => $this->input->post('head_4'),
					'head_5' => $this->input->post('head_5'),
					'price' => $this->input->post('price'),
					'curency' => $this->input->post('curency'),
					'status' => $this->input->post('status'),
					'modify' => date('Y-m-d')
				);				
				
				$this->Model_Page->editMemShip($id, $data);
				$this->session->set_flashdata('message','Member Ship Edit Successfully.');
				redirect(base_url('admin/Page/list_memb_ship'));
			} else {
				redirect(base_url('admin/Page/edit_memb_ship/'.$id));
			}
		}
        
    }
	
	
	public function deleteMemShip($id){
		
        if (isset($id)){
			$this->Model_Page->deleteMemShip($id);
			$this->session->set_flashdata('message','Member Ship Successfully Deleted.');
            redirect(base_url('admin/Page/list_memb_ship'));
        } else {
            redirect(base_url('admin/Page/list_memb_ship'));
	    }
    }

	/* ------ Membership Plane end ------ */
	
}

