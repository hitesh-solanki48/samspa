<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin')) { 
            redirect('login');
        }
		
		$this->load->model('Model_Vehicle');
        $this->load->model('Model_Manufacturer');
        $this->load->model('Model_Car_Model');
        $this->load->model('Model_Employee');
	}

	public function index()
	{

        $data['vehicles'] = $this->Model_Vehicle->getAll();
        $data['customers'] = $this->Model_Vehicle->customerList();
        $data['manufacturers_group'] = $this->Model_Vehicle->getAllByManufacturer();
        $data['manufacturers_group_sold'] = $this->Model_Vehicle->getAllByManufacturerSold();
        
        // $data['vehicle_by_month'] = $this->Model_Vehicle->get_vehicle_by_month();

        $data['employees'] = $this->Model_Employee->getAll();
    	$data['user'] = $this->session->userdata;

    	// die(var_dump($data['manufacturers_group']));

    	$this->load->view('admin/view_index', $data);
	}

	public function logout()
	{

	       $this->session->sess_destroy();
	       //redirect('login');
		   redirect(base_url());
	}
}
