<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact_Us extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_Contact');
	}
   
	public function index(){
		$this->load->view('common/header1');
		$this->load->view('contact_us/contact_us');
		$this->load->view('common/footer1');
	}
	
	public function add(){
        if($this->input->post('Submit')){
			$data['message'] = '';
			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required');
			if($this->form_validation->run() == FALSE){
				$this->load->view('contact_us/contact_us');
			} else {
				
				$data = array(
					'name' => $this->input->post('name'),
					'email' => $this->input->post('email'),
					'comment' => $this->input->post('comment'),
					'created' => date('Y-m-d')
				);
				$this->Model_Contact->add($data);
				$this->session->set_flashdata('message','Detail Send Successfully Created.');
				redirect('Contact_Us');
			}
		}else{
			$this->load->view('contact_us/contact_us');
		}
	}
	
	
}
