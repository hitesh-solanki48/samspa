<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Services extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}
   
	public function index(){
		$this->load->view('common/header1');
		$this->load->view('services/services');
		$this->load->view('common/footer1');
	}
	
	public function spa_package(){
		$this->load->view('common/header1');
		$this->load->view('services/spa_package');
		$this->load->view('common/footer1');
	}
	
	public function body_wrap_and_body_scrub(){
		$this->load->view('common/header1');
		$this->load->view('services/body_wrap_and_body_scrub');
		$this->load->view('common/footer1');
	}
	
	public function hair_services(){
		$this->load->view('common/header1');
		$this->load->view('services/hair_services');
		$this->load->view('common/footer1');
	}
	
	public function pedicures_manicures(){
		$this->load->view('common/header1');
		$this->load->view('services/pedicures_manicures');
		$this->load->view('common/footer1');
	}
	
	public function thai_oil_massage(){
		$this->load->view('common/header1');
		$this->load->view('services/thai_oil_massage');
		$this->load->view('common/footer1');
	}
	
	public function massage(){
		$this->load->view('common/header1');
		$this->load->view('services/massage');
		$this->load->view('common/footer1');
	}
	
	public function Foot_massage(){
		$this->load->view('common/header1');
		$this->load->view('services/Foot_massage');
		$this->load->view('common/footer1');
	}
	
	public function makeup(){
		$this->load->view('common/header1');
		$this->load->view('services/makeup');
		$this->load->view('common/footer1');
	}
	
	public function skincare_treatment(){
		$this->load->view('common/header1');
		$this->load->view('services/skincare_treatment');
		$this->load->view('common/footer1');
	}
	
	
	
	
}
