<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pages extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('Model_Vehicle');
        $this->load->model('Model_Manufacturer');
        $this->load->model('Model_Car_Model');
	}

	public function index()
	{	
		// $data['vehicles'] = $this->Model_Vehicle->getAll();
		$data['vehicles'] = $this->Model_Vehicle->getLatest();
		$data['featured'] = $this->Model_Vehicle->getFeatured();
		$data['manufacturers'] = $this->Model_Manufacturer->getAllManufacturers();
		$data['models'] = $this->Model_Car_Model->getAllModels();
		
		$this->load->view('public/view_index', $data);   

        // $this->load->view('public/view_index');
	}

	public function show($vehicle_id)
	{
		$data['vehicle'] = $this->Model_Vehicle->getById($vehicle_id);
		
		$this->load->view('public/view_single.php', $data);
	}



}