<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_Page');
		$this->load->model('Common_model');
	}
   
	public function index(){
		//$this->load->view('common/header1');
		$userRow = $this->Common_model->getAllBlog();
		$data['blogData'] = $userRow;
		$this->load->view('blog/blog', $data);
		//$this->load->view('common/footer1');
	}
	
	public function loadBlog(){
		$perPage = 5;
		$getP = $this->input->post("page");
		$start = ceil($getP * $perPage);
		$userRow = $this->Common_model->getAllOnLoadBlog($start, $perPage);
		$data['blogData'] = $userRow;
		if(isset($data['blogData'])){
			foreach($data['blogData'] as $val){
				?>
				  <div class="row dummy">
				   <div class="col-lg-2  mb-3 mt-3"><img src="<?php echo base_url(); ?>assets/newimg/blog/<?php echo $val['image']; ?>" class="img-fluid z-depth-1 rounded-circle" alt="<?php if(isset($val['alt_tag'])){ echo $val['alt_tag']; } else { echo 'image'; } ?>"></div>    
				   <div class="col-lg-10  mb-3 mt-3">
				   <p><span class="float-right color-danger"><?php echo date("jS \of F Y h:i:s A", strtotime($val['created'])); ?></span></p>
				   <p><b><?php echo $val['title']; ?></b></p>
				   <p><?php echo $val['description']; ?>.</p>
				   </div> 
				  </div>
				
				  <hr />
				  
						<?php 
			}
		}
		?>
		<script>
		$readMoreJS.init({
		target: '.dummy p',
		numOfWords: 50,
		toggle: true,
		moreLink: 'read more ...',
		lessLink: 'read less'
		});
		</script>
		<?php
		//print_r($userRow);
		die;
			
	}
	
	/* public function index()
    {
		$this->load->view('common/header1');
     
     $perPage = 5;
	$getP = $this->input->get('page');
     if(!empty($getP)){

      $start = ceil($getP * $perPage);
	  $userRow = $this->Common_model->getAllBlog($start, $perPage);
	  $data['blogData'] = $userRow;
      //$query = $this->db->limit($start, $this->perPage)->get("add_post");
      //$data['blogData'] = $query->result();
		$this->load->view('blog/blog', $data);
      //$result = $this->load->view('data', $data);
      //echo json_encode($result);

     }else{
      //$query = $this->db->limit(5, $this->perPage)->get("add_post");
	  $userRow = $this->Common_model->getAllBlog(0, $perPage);
      $data['blogData'] = $userRow;

	  $this->load->view('blog/blog', $data);
     }
	 $this->load->view('common/footer1');
    } */

	
	
	
}
