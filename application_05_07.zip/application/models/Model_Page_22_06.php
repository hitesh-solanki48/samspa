<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_Page extends CI_Model {

	/* ------ About Us start ------ */

	public function insert_about($data){
		$this->db->insert('about_us', $data); 
	}
	
	public function getAbout($id){
		$this->db->select('*');
        $this->db->from('about_us');
		$this->db->where('about_us_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllAbout(){
		$this->db->select('*');
        $this->db->from('about_us');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editAbout($id, $data){
		$this->db->where('about_us_id', $id);
		$this->db->update('about_us', $data); 
	}
	
	public function deleteAbout($id){
		$this->db->where('about_us_id', $id);
		$this->db->delete('about_us');
	}
	
	/* ------ About Us end ------ */
	
	/* ------ Member Ship start ------ */

	public function insert_memb_ship($data){
		$this->db->insert('mem_ship', $data); 
	}
	
	public function getMemShip($id){
		$this->db->select('*');
        $this->db->from('mem_ship');
		$this->db->where('mem_ship_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllMemShip(){
		$this->db->select('*');
        $this->db->from('mem_ship');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editMemShip($id, $data){
		$this->db->where('mem_ship_id', $id);
		$this->db->update('mem_ship', $data); 
	}
	
	public function deleteMemShip($id){
		$this->db->where('mem_ship_id', $id);
		$this->db->delete('mem_ship');
	}
	
	/* ------ Member Ship end ------ */

	/* ------ Country/City start ------ */

	public function insert_count_city($data){
		
			$dataArr = array(
				'image' => $data['image'],
				'title' => $data['title'],
				'city_id' => $data['city_id'],
				'state_id' => $data['state_id'],
				'country_id' => $data['country_id'],
				'page_title' => $data['page_title'],
				'meta_title' => $data['meta_title'],
				'type' => $data['type'],
				'status' => $data['status'],
				'alt_tag' => $data['alt_tag'],
				'created' => date('Y-m-d')
			);
			
			$this->db->insert('city_country', $dataArr); 
			$insert_id = $this->db->insert_id();
			$getCount = count($data['meta_tbl']['meta_name']);
			for($i = 0; $i < $getCount;  $i++){ 
				$dataArr1 = array(
					'city_country_id' => $insert_id,
					'meta_name' => $data['meta_tbl']['meta_name'][$i],  
					'meta_description' => $data['meta_tbl']['meta_description'][$i],
					'page_type' => $data['meta_tbl']['page_type']
				);
				$this->db->insert('meta_keywords', $dataArr1); 
				
			}
		
		
	}
	
	public function getCountCity($id){
		$this->db->select('*');
        $this->db->from('city_country');
		$this->db->where('city_country_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getMetaDesc($id){
		$this->db->select('*');
        $this->db->from('meta_keywords');
		$this->db->where('city_country_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllCountCity(){
		$this->db->select('*', 'states.state_name', 'countries.country_name', 'cities.city_name');
        $this->db->from('city_country');
		
		$this->db->join('cities', 'cities.city_id = city_country.city_id','LEFT');
		$this->db->join('states', 'states.state_id = city_country.state_id','LEFT');
		$this->db->join('countries', 'countries.country_id = city_country.country_id','LEFT');
		
		$result = $this->db->get();
		return $result->result_array();
	}
	
	public function editCountCity($id, $data){
		//echo '<pre>'; print_r($data); die;
		$dataArr = array(
				'image' => $data['image'],
				'title' => $data['title'],
				'city_id' => $data['city_id'],
				'state_id' => $data['state_id'],
				'country_id' => $data['country_id'],
				'page_title' => $data['page_title'],
				'meta_title' => $data['meta_title'],
				'type' => $data['type'],
				'alt_tag' => $data['alt_tag'],
				'status' => $data['status'],
				'modify' => date('Y-m-d')
			);
			$this->db->where('city_country_id', $id);
			$this->db->update('city_country', $dataArr); 
			 
			$insert_id = $id;
			$getCount = count($data['meta_tbl']['meta_name']);
			for($i = 0; $i < $getCount;  $i++){ 
				$dataArr1 = array(
					'city_country_id' => $insert_id,
					'meta_name' => $data['meta_tbl']['meta_name'][$i],  
					'meta_description' => $data['meta_tbl']['meta_description'][$i],
					'page_type' => $data['meta_tbl']['page_type'], 
				);
				if($data['meta_tbl']['meta_id'][$i] != ''){
					$this->db->where('meta_id', $data['meta_tbl']['meta_id'][$i]);
					$this->db->update('meta_keywords', $dataArr1);
				} else {
					$this->db->insert('meta_keywords', $dataArr1); 
				}
				//
				
			}
			
		
	}
	
	public function deleteCountCity($id){
		$this->db->where('city_country_id', $id);
		$this->db->delete('city_country');
	}
	
	/* ------ Country/City end ------ */
	
	/* ------ Country/City start ------ */

	public function insert_add_data($data){
		
			$dataArr = array(
				'image' => $data['image'],
				'title' => $data['title'],
				'contact_person' => $data['contact_person'],
				'cont_number' => $data['cont_number'],
				'email' => $data['email'],
				'map_link' => $data['map_link'],
				//'city_country_id' => $data['city_country_id'],
				'city_id' => $data['city_id'],
				'state_id' => $data['state_id'],
				'country_id' => $data['country_id'],
				'description' => $data['description'],
				'location' => $data['location'],
				'address' => $data['address'],
				'page_title' => $data['page_title'],
				'meta_title' => $data['meta_title'],
				'type' => $data['type'],
				'category_id' => $data['category_id'],
				'sub_category_id' => $data['sub_category_id'],
				'user_id' => $data['user_id'],
				'status' => $data['status'],
				'alt_tag' => $data['alt_tag'],
				'created' => date('Y-m-d')
			);
			
			$this->db->insert('add_post', $dataArr); 
			$insert_id = $this->db->insert_id();
			$getCount = count($data['meta_tbl']['meta_name']);
			for($i = 0; $i < $getCount;  $i++){ 
				$dataArr1 = array(
					'post_id' => $insert_id,
					'meta_name' => $data['meta_tbl']['meta_name'][$i],  
					'meta_description' => $data['meta_tbl']['meta_description'][$i],
					'page_type' => $data['meta_tbl']['page_type']
				);
				$this->db->insert('meta_keywords', $dataArr1); 
				
			}
		
		
	}
	
	public function getAllCountCityForPost(){
		$this->db->select('*');
        $this->db->from('city_country');
		$result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAddData($id){
		$this->db->select('*');
        $this->db->from('add_post');
		$this->db->where('post_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getMetaDescPost($id){
		$this->db->select('*');
        $this->db->from('meta_keywords');
		$this->db->where('post_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllAddData($user_id){
		
		$this->db->select('add_post.*, city_country.title');
        $this->db->from('add_post');
		
		$this->db->join('city_country', 'city_country.city_country_id = add_post.city_country_id','LEFT');
		//$this->db->join('states', 'states.state_id = city_country.state_id','LEFT');
		//$this->db->join('countries', 'countries.country_id = city_country.country_id','LEFT');
		$this->db->where('user_id', $user_id);
		$result = $this->db->get();
		return $result->result_array();
	}
	
	public function editAddData($id, $data){
		//echo '<pre>'; print_r($data); die;
		$dataArr = array(
				'image' => $data['image'],
				'title' => $data['title'],
				'contact_person' => $data['contact_person'],
				'cont_number' => $data['cont_number'],
				'email' => $data['email'],
				'map_link' => $data['map_link'],
				//'city_country_id' => $data['city_country_id'],
				'city_id' => $data['city_id'],
				'state_id' => $data['state_id'],
				'country_id' => $data['country_id'],
				'description' => $data['description'],
				'location' => $data['location'],
				'address' => $data['address'],
				'page_title' => $data['page_title'],
				'meta_title' => $data['meta_title'],
				'type' => $data['type'],
				'category_id' => $data['category_id'],
				'sub_category_id' => $data['sub_category_id'],
				'user_id' => $data['user_id'],
				'status' => $data['status'],
				'alt_tag' => $data['alt_tag'],
				'modify' => date('Y-m-d')
			);
			$this->db->where('post_id', $id);
			$this->db->update('add_post', $dataArr); 
			 
			$insert_id = $id;
			$getCount = count($data['meta_tbl']['meta_name']);
			for($i = 0; $i < $getCount;  $i++){ 
				$dataArr1 = array(
					'post_id' => $insert_id,
					'meta_name' => $data['meta_tbl']['meta_name'][$i],  
					'meta_description' => $data['meta_tbl']['meta_description'][$i],
					'page_type' => $data['meta_tbl']['page_type'], 
				);
				if($data['meta_tbl']['meta_id'][$i] != ''){
					$this->db->where('meta_id', $data['meta_tbl']['meta_id'][$i]);
					$this->db->update('meta_keywords', $dataArr1);
				} else {
					$this->db->insert('meta_keywords', $dataArr1); 
				}
				//
				
			}
			
		
	}
	
	public function deleteAddData($id){
		$this->db->where('post_id', $id);
		$this->db->delete('add_post');
	}
	
	/* ------ Country/City end ------ */
	
	/* ------ Contact Us Start ------ */
	
	public function getAllContactUs(){
		$this->db->select('*');
        $this->db->from('contact_us');
		$result = $this->db->get();
		return $result->result_array();
	}
	
	/* ------ Contact Us End ------ */

	/* ------ FAQ start ------ */

	public function insert_faq($data){
		$this->db->insert('faq', $data); 
	}
	
	public function getFaq($id){
		$this->db->select('*');
        $this->db->from('faq');
		$this->db->where('id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllFaq(){
		$this->db->select('*');
        $this->db->from('faq');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editFaq($id, $data){
		$this->db->where('id', $id);
		$this->db->update('faq', $data); 
	}
	
	public function deleteFaq($id){
		$this->db->where('id', $id);
		$this->db->delete('faq');
	}
	
	/* ------ FAQ end ------ */	
		
		
	/* ------ Boq start ------ */

	public function insert_blog($data){
		
			$dataArr = array(
				'image' => $data['image'],
				'title' => $data['title'],
				'description' => $data['description'],
				'page_title' => $data['page_title'],
				'meta_title' => $data['meta_title'],
				'type' => $data['type'],
				'status' => $data['status'],
				'alt_tag' => $data['alt_tag'],
				'created' => date('Y-m-d h:i:s')
			);
			
			$this->db->insert('blog', $dataArr); 
			$insert_id = $this->db->insert_id();
			$getCount = count($data['meta_tbl']['meta_name']);
			for($i = 0; $i < $getCount;  $i++){ 
				$dataArr1 = array(
					'blog_id' => $insert_id,
					'meta_name' => $data['meta_tbl']['meta_name'][$i],  
					'meta_description' => $data['meta_tbl']['meta_description'][$i],
					'page_type' => $data['meta_tbl']['page_type']
				);
				$this->db->insert('meta_keywords', $dataArr1); 
				
			}
	}
	
	public function getAllBlog(){
		$this->db->select('*');
        $this->db->from('blog');
		$result = $this->db->get();
		return $result->result_array();
	}
	
	public function getBlog($id){
		$this->db->select('*');
        $this->db->from('blog');
		$this->db->where('id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getMetaDescBlog($id){
		$this->db->select('*');
        $this->db->from('meta_keywords');
		$this->db->where('blog_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	/* public function getAllAddData($user_id){
		
		$this->db->select('add_post.*, city_country.title');
        $this->db->from('add_post');
		
		$this->db->join('city_country', 'city_country.city_country_id = add_post.city_country_id','LEFT');
		$this->db->where('user_id', $user_id);
		$result = $this->db->get();
		return $result->result_array();
	} */
	
	public function editBlog($id, $data){
		//echo '<pre>'; print_r($data); die;
		$dataArr = array(
				'image' => $data['image'],
				'title' => $data['title'],
				'description' => $data['description'],
				'page_title' => $data['page_title'],
				'meta_title' => $data['meta_title'],
				'type' => $data['type'],
				'status' => $data['status'],
				'alt_tag' => $data['alt_tag'],
				'modify' => date('Y-m-d h:i:s')
			);
			$this->db->where('id', $id);
			$this->db->update('blog', $dataArr); 
			 
			$insert_id = $id;
			$getCount = count($data['meta_tbl']['meta_name']);
			for($i = 0; $i < $getCount;  $i++){ 
				$dataArr1 = array(
					'blog_id' => $insert_id,
					'meta_name' => $data['meta_tbl']['meta_name'][$i],  
					'meta_description' => $data['meta_tbl']['meta_description'][$i],
					'page_type' => $data['meta_tbl']['page_type'], 
				);
				if($data['meta_tbl']['meta_id'][$i] != ''){
					$this->db->where('meta_id', $data['meta_tbl']['meta_id'][$i]);
					$this->db->update('meta_keywords', $dataArr1);
				} else {
					$this->db->insert('meta_keywords', $dataArr1); 
				}
				//
				
			}
			
		
	}
	
	public function deleteBlog($id){
		$this->db->where('id', $id);
		$this->db->delete('blog');
	}
	
	/* ------ Country/City end ------ */
	
	
	/* ------ FAQ start ------ */

	public function insert_policy($data){
		$this->db->insert('policy', $data); 
	}
	
	public function getPolicy($id){
		$this->db->select('*');
        $this->db->from('policy');
		$this->db->where('id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllPolicy(){
		$this->db->select('*');
        $this->db->from('policy');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editPolicy($id, $data){
		$this->db->where('id', $id);
		$this->db->update('policy', $data); 
	}
	
	public function deletePolicy($id){
		$this->db->where('id', $id);
		$this->db->delete('policy');
	}
	
	/* ------ FAQ end ------ */	
	
}