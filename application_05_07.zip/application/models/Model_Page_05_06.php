<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_Page extends CI_Model {

	/* ------ About Us start ------ */

	public function insert_about($data){
		$this->db->insert('about_us', $data); 
	}
	
	public function getAbout($id){
		$this->db->select('*');
        $this->db->from('about_us');
		$this->db->where('about_us_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllAbout(){
		$this->db->select('*');
        $this->db->from('about_us');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editAbout($id, $data){
		$this->db->where('about_us_id', $id);
		$this->db->update('about_us', $data); 
	}
	
	public function deleteAbout($id){
		$this->db->where('about_us_id', $id);
		$this->db->delete('about_us');
	}
	
	/* ------ About Us end ------ */
	
	/* ------ Member Ship start ------ */

	public function insert_memb_ship($data){
		$this->db->insert('mem_ship', $data); 
	}
	
	public function getMemShip($id){
		$this->db->select('*');
        $this->db->from('mem_ship');
		$this->db->where('mem_ship_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllMemShip(){
		$this->db->select('*');
        $this->db->from('mem_ship');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editMemShip($id, $data){
		$this->db->where('mem_ship_id', $id);
		$this->db->update('mem_ship', $data); 
	}
	
	public function deleteMemShip($id){
		$this->db->where('mem_ship_id', $id);
		$this->db->delete('mem_ship');
	}
	
	/* ------ Member Ship end ------ */
	
}