<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_Contact extends CI_Model {

	public function add($data){
		$this->db->insert('contact_us', $data); 

	}
}