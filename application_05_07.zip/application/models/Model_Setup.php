<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_Setup extends CI_Model {

	/* ------ Country start ------ */

	public function insert_country($data){
		$this->db->insert('countries', $data); 
	}
	
	public function getCountry($id){
		$this->db->select('*');
        $this->db->from('countries');
		$this->db->where('country_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllCountry(){
		$this->db->select('*');
        $this->db->from('countries');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editCountry($id, $data){
		$this->db->where('country_id', $id);
		$this->db->update('countries', $data); 
	}
	
	public function deleteCountry($id){
		$this->db->where('country_id', $id);
		$this->db->delete('countries');
	}
	
	/* ------ Country end ------ */
	
	/* ------ State start ------ */

	public function insert_state($data){
		$this->db->insert('states', $data); 
	}
	
	public function getState($id){
		$this->db->select('*');
        $this->db->from('states');
		$this->db->where('state_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllState(){
		$this->db->select('*');
        $this->db->from('states');
        $this->db->join('countries', 'countries.country_id = states.country_id','left');
		$result = $this->db->get();
		return $result->result_array();
	}
	
	public function editState($id, $data){
		$this->db->where('state_id', $id);
		$this->db->update('states', $data); 
	}
	
	public function deleteState($id){
		$this->db->where('state_id', $id);
		$this->db->delete('states');
	}
	
	/* ------ State end ------ */
	
	/* ------ City start ------ */

	public function insert_city($data){
		$this->db->insert('cities', $data); 
	}
	
	public function getCity($id){
		$this->db->select('*');
        $this->db->from('cities');
		$this->db->where('city_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllCity(){
		$this->db->select('*');
        $this->db->from('cities');
        $this->db->join('states', 'states.state_id = cities.state_id','left');
		$this->db->join('countries', 'countries.country_id = cities.country_id','left');
		$result = $this->db->get();
		return $result->result_array();
	}
	
	public function editCity($id, $data){
		$this->db->where('city_id', $id);
		$this->db->update('cities', $data); 
	}
	
	public function deleteCity($id){
		$this->db->where('city_id', $id);
		$this->db->delete('cities');
	}
	
	/* ------ City end ------ */
	
	/* ------ Contact Details start ------ */

	public function insert_cont_det($data){
		$this->db->insert('contact_det', $data); 
	}
	
	public function getContDet($id){
		$this->db->select('*');
        $this->db->from('contact_det');
		$this->db->where('contact_det_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllContDet(){
		$this->db->select('*');
        $this->db->from('contact_det');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editContDet($id, $data){
		$this->db->where('contact_det_id', $id);
		$this->db->update('contact_det', $data); 
	}
	
	public function deleteContDet($id){
		$this->db->where('contact_det_id', $id);
		$this->db->delete('contact_det');
	}
	
	/* ------ Contact Details end ------ */
	
	/* ------ Category start ------ */

	public function insert_category($data){
		$dataArr = array(
				'image' => $data['image'],
				'category' => $data['category'],
				'status' => $data['status']
			);	
		$this->db->insert('category', $dataArr); 
		$insert_id = $this->db->insert_id();
		$getCount = count($data['meta_tbl']['meta_name']);
		for($i = 0; $i < $getCount;  $i++){ 
			$dataArr1 = array(
				'category_id' => $insert_id,
				'meta_name' => $data['meta_tbl']['meta_name'][$i],  
				'meta_description' => $data['meta_tbl']['meta_description'][$i],
				'page_type' => $data['meta_tbl']['page_type']
			);
			$this->db->insert('meta_keywords', $dataArr1); 
			
		}
	}
	
	public function getCategory($id){
		$this->db->select('*');
        $this->db->from('category');
		$this->db->where('category_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllCategory(){
		$this->db->select('*');
        $this->db->from('category');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getMetaDescCategory($id){
		$this->db->select('*');
        $this->db->from('meta_keywords');
		$this->db->where('category_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editCategory($id, $data){
		
		$dataArr = array(
				'image' => $data['image'],
				'category' => $data['category'],
				'status' => $data['status']
			);	
		
		$this->db->where('category_id', $id);
		$this->db->update('category', $dataArr); 
		
		$insert_id = $id;
			$getCount = count($data['meta_tbl']['meta_name']);
			for($i = 0; $i < $getCount;  $i++){ 
				$dataArr1 = array(
					'category_id' => $insert_id,
					'meta_name' => $data['meta_tbl']['meta_name'][$i],  
					'meta_description' => $data['meta_tbl']['meta_description'][$i],
					'page_type' => $data['meta_tbl']['page_type'], 
				);
				if($data['meta_tbl']['meta_id'][$i] != ''){
					$this->db->where('meta_id', $data['meta_tbl']['meta_id'][$i]);
					$this->db->update('meta_keywords', $dataArr1);
				} else {
					$this->db->insert('meta_keywords', $dataArr1); 
				}
				//
				
			}
		
	}
	
	public function deleteCategory($id){
		$this->db->where('category_id', $id);
		$this->db->delete('category');
	}
	
	/* ------ Category end ------ */
	
	/* ------ Sub  Category start ------ */

	public function insert_sub_category($data){
		
			$dataArr = array(
					'category_id' => $data['category_id'],
					'sub_category' => $data['sub_category'],
				);	
		
		$this->db->insert('sub_category', $dataArr); 
		$insert_id = $this->db->insert_id();
		$getCount = count($data['meta_tbl']['meta_name']);
		for($i = 0; $i < $getCount;  $i++){ 
			$dataArr1 = array(
				'sub_category_id' => $insert_id,
				'meta_name' => $data['meta_tbl']['meta_name'][$i],  
				'meta_description' => $data['meta_tbl']['meta_description'][$i],
				'page_type' => $data['meta_tbl']['page_type']
			);
			$this->db->insert('meta_keywords', $dataArr1); 
			
		}
	}
	
	public function getSubCategory($id){
		$this->db->select('*');
        $this->db->from('sub_category');
		$this->db->where('sub_category_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllSubCategory(){
		$this->db->select('sub_category.*, category.category');
        $this->db->from('sub_category');
		$this->db->join('category', 'category.category_id = sub_category.category_id','left');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	
	public function getMetaDescSubCategory($id){
		$this->db->select('*');
        $this->db->from('meta_keywords');
		$this->db->where('sub_category_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editSubCategory($id, $data){
		
		$dataArr = array(
					'category_id' => $data['category_id'],
					'sub_category' => $data['sub_category'],
				);	
		
		$this->db->where('sub_category_id', $id);
		$this->db->update('sub_category', $dataArr);

		
		$insert_id = $id;
			$getCount = count($data['meta_tbl']['meta_name']);
			for($i = 0; $i < $getCount;  $i++){ 
				$dataArr1 = array(
					'sub_category_id' => $insert_id,
					'meta_name' => $data['meta_tbl']['meta_name'][$i],  
					'meta_description' => $data['meta_tbl']['meta_description'][$i],
					'page_type' => $data['meta_tbl']['page_type'], 
				);
				if($data['meta_tbl']['meta_id'][$i] != ''){
					$this->db->where('meta_id', $data['meta_tbl']['meta_id'][$i]);
					$this->db->update('meta_keywords', $dataArr1);
				} else {
					$this->db->insert('meta_keywords', $dataArr1); 
				}
				//
				
			}	
	}
	
	public function deleteSubCategory($id){
		$this->db->where('sub_category_id', $id);
		$this->db->delete('sub_category');
	}
	
	/* ------ Sub Country end ------ */
}