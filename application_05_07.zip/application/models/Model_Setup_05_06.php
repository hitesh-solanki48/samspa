<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_Setup extends CI_Model {

	/* ------ Country start ------ */

	public function insert_country($data){
		$this->db->insert('countries', $data); 
	}
	
	public function getCountry($id){
		$this->db->select('*');
        $this->db->from('countries');
		$this->db->where('country_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllCountry(){
		$this->db->select('*');
        $this->db->from('countries');
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function editCountry($id, $data){
		$this->db->where('country_id', $id);
		$this->db->update('countries', $data); 
	}
	
	public function deleteCountry($id){
		$this->db->where('country_id', $id);
		$this->db->delete('countries');
	}
	
	/* ------ Country end ------ */
	
	/* ------ State start ------ */

	public function insert_state($data){
		$this->db->insert('states', $data); 
	}
	
	public function getState($id){
		$this->db->select('*');
        $this->db->from('states');
		$this->db->where('state_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllState(){
		$this->db->select('*');
        $this->db->from('states');
        $this->db->join('countries', 'countries.country_id = states.country_id','left');
		$result = $this->db->get();
		return $result->result_array();
	}
	
	public function editState($id, $data){
		$this->db->where('state_id', $id);
		$this->db->update('states', $data); 
	}
	
	public function deleteState($id){
		$this->db->where('state_id', $id);
		$this->db->delete('states');
	}
	
	/* ------ State end ------ */
	
	/* ------ City start ------ */

	public function insert_city($data){
		$this->db->insert('cities', $data); 
	}
	
	public function getCity($id){
		$this->db->select('*');
        $this->db->from('cities');
		$this->db->where('city_id', $id);
        $result = $this->db->get();
		return $result->result_array();
	}
	
	public function getAllCity(){
		$this->db->select('*');
        $this->db->from('cities');
        $this->db->join('states', 'states.state_id = cities.state_id','left');
		$this->db->join('countries', 'countries.country_id = cities.country_id','left');
		$result = $this->db->get();
		return $result->result_array();
	}
	
	public function editCity($id, $data){
		$this->db->where('city_id', $id);
		$this->db->update('cities', $data); 
	}
	
	public function deleteCity($id){
		$this->db->where('city_id', $id);
		$this->db->delete('cities');
	}
	
	/* ------ City end ------ */
	
}