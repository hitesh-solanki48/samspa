<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_model extends CI_Model {

       public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

 		 public function all_refferby()
		  {
		  		$result=array();
				$query = $this->db->get('reffer_by');
				foreach ($query->result_array() as $row)
				 {
       			 $result[]=$row;
				 }
				return $result;
		  }
		 public function all_castes()
		  {
		  		$result=array();
				$query = $this->db->get('caste');
				foreach ($query->result_array() as $row)
				 {
       			 $result[]=$row;
				 }
				return $result;
		  }
		
		public function getCityView(){
			$this->db->select('*');
			$this->db->from('city_country');
			$this->db->where('country_id', 101);
			$this->db->where('city_id != ',0,FALSE);
			$result = $this->db->get();
			return $result->result_array();
		}
		
		public function getMetaDesc(){
			$this->db->select('*');
			$this->db->from('meta_keywords');
			//$this->db->where('city_country_id', $id);
			$result = $this->db->get();
			return $result->result_array();
		}
		public function getAddDataCityWise($id){
			//echo '<pre>'; die;
			$this->db->select('add_post.*, cities.city_name');
			$this->db->from('add_post');
			$this->db->where('add_post.city_country_id', $id);
			$this->db->join('city_country', 'city_country.city_country_id = add_post.city_country_id','LEFT');
			$this->db->join('cities', 'cities.city_id = city_country.city_id','LEFT');
			//$this->db->where('city_country_id', $id);
			$result = $this->db->get();
			return $result->result_array();
		}
		public function getAddDataMainCity($id){
			$this->db->select('city_country.*, cities.city_name');
			$this->db->from('city_country');
			$this->db->where('city_country.city_country_id', $id);
			$this->db->join('cities', 'cities.city_id = city_country.city_id','LEFT');
			$result = $this->db->get();
			return $result->result_array();
		}
		
		
		public function getAddDataPost($id){
			//echo '<pre>'; die;
			$this->db->select('add_post.*, cities.city_name,countries.country_name');
			$this->db->from('add_post');
			$this->db->where('add_post.post_id', $id);
			$this->db->join('city_country', 'city_country.city_country_id = add_post.city_country_id','LEFT');
			$this->db->join('cities', 'cities.city_id = city_country.city_id','LEFT');
			//$this->db->join('cities', 'cities.city_id = city_country.city_id','LEFT');
			$this->db->join('countries', 'countries.country_id = cities.country_id','LEFT');
			//$this->db->where('city_country_id', $id);
			$result = $this->db->get();
			return $result->result_array();
		}
		
		function getCat(){
			$this->db->select('*');
			$this->db->from('category');
			$result = $this->db->get();
			$this->db->limit(10); 
			return $result->result_array();
		}
		
		public function getSubCat(){
			$this->db->select('*');
			$this->db->from('sub_category');
			$this->db->limit(10); 
			$result = $this->db->get();
			return $result->result_array();
		}
		
		public function getCityList(){
			$this->db->select('*');
			$this->db->from('cities');
			$this->db->limit(10); 
			$result = $this->db->get();
			return $result->result_array();
		}
		
		public function getDataCategoryWise($id){
			$this->db->select('*');
			$this->db->from('add_post');
			$this->db->where('category_id', $id);
			$this->db->limit(10); 
			$result = $this->db->get();
			return $result->result_array();
		}
		
		public function getDataCityWise($id){
			$this->db->select('*');
			$this->db->from('add_post');
			$this->db->where('city_id', $id);
			$this->db->limit(10); 
			$result = $this->db->get();
			return $result->result_array();
		}
		
		
}