<section class="testimonial-bg">
                <div class="container">
                    <!--Heading 1 Start-->
                    <div class="kf-heading-1">
                        <span class="icon-icon-36491"><i class="hd-bdr"></i><i class="hd-bdl"></i></span>
                        <h2>Our Testimonial</h2>
                    </div>
                    <!--Heading 1 End-->
                    <!--Testimonial Slider Start-->
                    <ul class="slider1">
                        <li>
                            <!--Blockquote-1 Start-->
                            <div class="blockquote-1">
                                <h4>Mr.Sanjay ,<span>Customer</span></h4>
                                <p>“Very relaxing and rejuvenating experience. Eased out the stiffness and body pains. Courteous staff. Good ambience. Complimentary show and drinks.”
</p>
                            </div>
                            <!--Blockquote-1 End-->
                        </li>
                         <li>
                            <!--Blockquote-1 Start-->
                            <div class="blockquote-1">
                                <h4>Soniya Shah,<span>Customer</span></h4>
                                <p>“I enjoyed the warm oil and although I thought the stones were a little hot, at first, the nice lady warned me before and it really did wonders to my back.”</p>
                            </div>
                            <!--Blockquote-1 End-->
                        </li>
                         <li>
                            <!--Blockquote-1 Start-->
                            <div class="blockquote-1">
                                <h4>Nikita ,<span>Customer</span></h4>
                                <p>“Awesome Experience of Foot Reflexology with full pressure and concentration, felt really relaxed and rejuvenated. The therapist Anumi who had done Massage for me was Excellent.........Keep up the good work.....Will surely visit again....”</p>
                            </div>
                            <!--Blockquote-1 End-->
                        </li>
                        <li>
                            <!--Blockquote-1 Start-->
                            <div class="blockquote-1">
                                <h4>Anushree ,<span>Customer</span></h4>
                                <p>“Awesome Experience, You enter a different world. Its not just a Spa, its an unforgettable experience.”
</p>
                            </div>
                            <!--Blockquote-1 End-->
                        </li>
                    </ul>
                    <!--Testimonial Slider End-->
                </div>
            </section>