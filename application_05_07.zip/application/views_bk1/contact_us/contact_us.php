		<!--Home Page Banner Start-->
		<div class="kode-home-banner inner-banner">
			<h6>Contact Us</h6>
            <i class="border-style-1"></i>
		</div>
        <div class="kf-banner-bar">
            <div class="container">
                <div class="pull-left">
                    <h6>Contact Us</h6>
                </div>
                <div class="pull-right">
                    <ul class="breadcrumb">
                      <li><a href="<?php echo base_url(); ?>">Home</a></li>
                      <li><a href="<?php echo base_url(); ?>contact_us">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
		<!--Home Page Banner End-->


		<div class="kf_content_wrap">
            <section class="kf-contact-wrap">
                <div class="container">
                    <!--Contact US Wrap Start-->
                    <div class="row">
                        <div class="col-md-12 ">
                            <!--Heading 2 Start-->
                            <div class="heading-2">
                                <h1>Contact Sam Spa Center</h1>
                                <i class="border-style-1"></i>
                            </div>
                            <!--Heading 2 End-->
                        </div>
                        <!--Contact US Des-->
                        <div class="col-md-4 col-sm-6">
                            <div class="contact-dec">
                                <span class="icon-direction"></span>
                                <h5>Address</h5>
                                <address>Malad West, <br>Mumbai - 400 064</address>
                            </div>
                        </div>
                        <!--Contact US Des-->
                        <!--Contact US Des-->
                        <div class="col-md-4 col-sm-6">
                            <div class="contact-dec">
                                <span class="icon-telephone"></span>
                                <h5>Phone</h5>
                                <em>+91 9967228816</em>
                                
                            </div>
                        </div>
                        <!--Contact US Des-->
                        <!--Contact US Des-->
                         
                        <!--Contact US Des-->
                        <!--Contact US Des-->
                        <div class="col-md-4 col-sm-6">
                            <div class="contact-dec">
                                <span class="icon-web"></span>
                                <h5>Email</h5>
                                <a href="#">info@samspacenter.com</a>
                                <a href="#">support@samspacenter.com</a>
                            </div>
                        </div>
                        <!--Contact US Des-->
                    </div>
                    <!--Contact US Wrap End-->
                </div>
            </section>
            <div class="kode-map">
                 
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3768.3710959125115!2d72.83389871400703!3d19.17898735371312!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b6f132a2fadb%3A0x19d936ca5816b18c!2sEvershine+Mall!5e0!3m2!1sen!2sin!4v1475935027636" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
                   
            <section>
                <div class="container">
                    <div class="contact-form">
                        <div class="row">
                            <!--Heading 2 Start-->
                            <div class="heading-2">
                                <h2><br>Contact Us</h2>
                                <i class="border-style-1"></i>
                            </div>
                            <!--Heading 2 End-->
                            <form action="contact-us.php" method="post">
                                <div class="col-md-4 col-sm-4">
                                    <div class="contact-input">
                                        <input type="text" name="name" placeholder="Name">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="contact-input">
                                        <input type="text" name="mobile" placeholder="Mobile No.">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="contact-input">
                                        <input type="text" name="email" placeholder="Email">
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <div class="contact-input">
                                        <textarea placeholder="Message" name="massage"></textarea>
                                    </div>
                                    <input type="submit" name="submit" value="send massage">
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </section>
		</div>
        
   