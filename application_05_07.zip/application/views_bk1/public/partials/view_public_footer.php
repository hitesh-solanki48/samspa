<div class="footer w3layouts">
	<div class="container">
		<div class="footer-top-at w3">
			
			<div class="col-md-3 amet-sed w3l">
				<h4>MORE INFO</h4>
				<ul class="nav-bottom">
					<li><a href="#">How to order</a></li>
					<li><a href="#">FAQ</a></li>
					<li><a href="contact.html">Location</a></li>
					<li><a href="#">Shipping</a></li>
					<li><a href="#">Membership</a></li>
				</ul>
			</div>
			<div class="col-md-3 amet-sed w3ls">
				<h4>CATEGORIES</h4>
				<ul class="nav-bottom">
					<li><a href="#">Bed linen</a></li>
					<li><a href="#">Cushions</a></li>
					<li><a href="#">Duvets</a></li>
					<li><a href="#">Pillows</a></li>
					<li><a href="#">Protectors</a></li>
				</ul>
				
			</div>

			<div class="col-md-3 amet-sed agileits-w3layouts">
				<h4>US Office</h4>
				<p>Contrary to popular belief</p>
				<p>The standard chunk</p>
				<p>Office :  +12 34 995 0792</p>
			</div>

			<div class="col-md-3 amet-sed agileits-w3layouts">
				<h4>BD Office</h4>
				<p>Kamal Ataturk Avenue</p>
				<p>Banani Bazaar</p>
				<p>Office :  +880 134 995 0792</p>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="footer-class w3-agile">
		<p>© 2015. All Rights Reserved</p>
	</div>
</div>
</body>
</html>