<!--Home Page Banner Start-->
		<div class="kode-home-banner inner-banner">
			<h6>Membership</h6>
            <i class="border-style-1"></i>
		</div>
        <div class="kf-banner-bar">
            <div class="container">
                <div class="pull-left">
                    <h6>membership</h6>
                </div>
                <div class="pull-right">
                    <ul class="breadcrumb">
                        <li><a href="<?php echo base_url(); ?>">Home</a></li>
                        <li><a href="<?php echo base_url(); ?>membership">Membership</a></li>
                    </ul>
                </div>
            </div>
        </div>
		<!--Home Page Banner End-->


		<div class="kf_content_wrap">
            <!--About Spa Wrap Strat-->
             <section>
                <div class="container">
                    <!--Heading 1 Start-->
                    <div class="kf-heading-1">
                        <span class="icon-icon-36491"><i class="hd-bdr"></i><i class="hd-bdl"></i></span>
                        <h1>Best Spa Packages</h1>
                    </div>
                    <!--Heading 1 End-->
                    <div class="row">
                        <!--Price Table Start-->
                        <div class="col-md-4 col-sm-6">
                            <div class="kf-price-table">
                                <span class="icon-icon-83138"></span>
                                <h3>BASIC</h3>
                                <!--Price Table Meta Start-->
                                <ul class="price-table-meta">
                                    <li>Nail Cutting &amp; Styling</li>
                                    <li>Free Wi-Fi</li>
                                    <li>Body Massage Service</li>
                                    <li>Water Heated Pool</li>
                                    <li>Manicure</li>
                                </ul>
                                <!--Price Table Meta End-->
                                <!--Price Start-->
                                <div class="price">
                                    <span><sup>$</sup>29.99</span>
                                </div>
                                <!--Price End-->
                                <!--<input type=button class="btn-1">BUY NOW</button>--> 
                                <a href="https://www.instamojo.com/@Webinfotechindia/ldec19244e7404f8ca5b972a2894f709a/" class="btn-1">BUY NOW</a>
<script src="https://js.instamojo.com/v1/button.js"></script>
                        </div>
                        </div>
                        <!--Price Table End-->
                        <!--Price Table Start-->
                        <div class="col-md-4 col-sm-6">
                            <div class="kf-price-table">
                                <span class="icon-icon-95804"></span>
                                <h3>STANDARD</h3>
                                <!--Price Table Meta Start-->
                                <ul class="price-table-meta">
                                    <li>Cutting &amp; Styling</li>
                                    <li>Free Manicure</li>
                                    <li>Massage Service</li>
                                    <li>Heated Pool</li>
                                    <li>Manicure</li>
                                </ul>
                                <!--Price Table Meta End-->
                                <!--Price Start-->
                                <div class="price">
                                    <span><sup>$</sup>39.99</span>
                                </div>
                                <!--Price End-->
                                <a href="https://imjo.in/wzuPTe" class="btn-1">BUY NOW</a>
                            </div>
                        </div>
                        <!--Price Table End-->
                        <!--Price Table Start-->
                        <div class="col-md-4 hidden-sm">
                            <div class="kf-price-table">
                                <span class="icon-icon-95826"></span>
                                <h3>Premium</h3>
                                <!--Price Table Meta Start-->
                                <ul class="price-table-meta">
                                    <li>Cutting</li>
                                    <li>Manicure</li>
                                    <li>Free Massage Service</li>
                                    <li>Heated Pool</li>
                                    <li>Manicure</li>
                                </ul>
                                <!--Price Table Meta End-->
                                <!--Price Start-->
                                <div class="price">
                                    <span><sup>$</sup>49.99</span>
                                </div>
                                <!--Price End-->
                                <a href="https://imjo.in/RZVQAw" class="btn-1">BUY NOW</a>
                            </div>
                        </div>
                        <!--Price Table End-->
                    </div>
                </div>
            </section>
            <!--About Spa Wrap End-->
    
             <!--Testimonail Wrap Start-->
            <?php include_once './testimonial.php';?>
            <!--Testimonail Wrap End-->
            <!--Counter Wrap Start-->
            <div class="kf-counterup counter-2">
                <div class="container">
                    <!--Counter Wrap Start-->
                    <ul class="kf-counter">
                        <!--Counter Des Start-->
                        <li>
                            <span class="counter">6885</span>
                            <i class="icon-icon-34894"></i>
                            <h6>Satisfied Clients</h6>
                        </li>
                        <!--Counter Des End-->
                        <!--Counter Des Start-->
                        <li>
                            <span class="counter">512</span>
                            <i class="icon-icon-36285"></i>
                            <h6>Completed projects</h6>
                        </li>
                        <!--Counter Des End-->
                        <!--Counter Des Start-->
                        <li>
                            <span class="counter">1769</span>
                            <i class="icon-icon-88529"></i>
                            <h6>Likes on Average</h6>
                        </li>
                        <!--Counter Des End-->
                        <!--Counter Des Start-->
                        <li>
                            <span class="counter">154</span>
                            <i class="icon-people"></i>
                            <h6>We Launched</h6>
                        </li>
                        <!--Counter Des End-->
                    </ul>
                    <!--Counter Wrap End-->
                </div>
            </div>
            <!--Counter Wrap End-->
           
           
            

		</div>
        <!--FOOTER START-->
         <?php include_once './footer.php';?>
        <!--FOOTER END-->
		<!-- START GO UP -->
        <div class="go-up">
            <a href="#" ><i class="icon-spa"></i></a>    
        </div>
        <!--END GO UP-->
		
    </div>
     <?php include_once 'after_footer.php'; ?>   
    <!--KF KODE WRAPPER WRAP END-->
	<!--Bootstrap core JavaScript-->
        
<!--	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
    Dl Menu Script
    <script src="js/dl-menu/modernizr.custom.js"></script>
    <script src="js/dl-menu/jquery.dlmenu.js"></script>
	Bx-Slider JavaScript
	<script src="js/jquery.bxslider.min.js"></script>
	Map
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
	Pretty Photo JavaScript
	<script src="js/jquery.prettyPhoto.js"></script>
	Full Count Down JavaScript
	<script src="js/jquery.downCount.js"></script>
	Number Count (Waypoints) JavaScript
	<script src="js/waypoints-min.js"></script>
	 include Masonry 
	<script src="js/isotope.pkgd.min.js"></script> 
	Custom JavaScript
	<script src="js/custom.js"></script>-->

    
</body>


</html>
