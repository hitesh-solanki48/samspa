<!DOCTYPE html>
<html lang="en">


<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Spa in India, Spa Treatments in India</title>
<meta name="keywords" content="Spa in India, Spa Treatments in India, Bangalore spa, spa deals in Delhi, thai spa in Pune, spa at hyderabad, Chennai spa centers, spa Kolkata, spa in Goa, spa deals in Chandigarh, best spa in Jaipur, spa Gurgaon, body spa in Bhopal, body spa in Ranchi, spa Surat, spa in Nashik, spa in Vizag, spa center in Ahmedabad, body spa in Agra, spa center in Lucknow" />
<meta name="description" itemprop="description" content="Sam Spa center provides best spa treatments in India. We believe in quality services and we are one of the most trusted center for spa treatments." />
<meta name="Author" content="Hot Stone Massage in Mumbai, http://www.samspacenter.com" />
<meta property="og:title" content="Spa in Mumbai, Spa Center in Pune, Delhi, Bangalore, Chennai, Hyderabad, India, UAE, Thailand|samspacenter.com">
<meta property="og:type" content="article" />
<meta property="og:url" content="http://www.samspacenter.com/city.php" />
<meta property="og:image" content="http://www.example.com/image.png" />
<meta name="twitter:card" content="summary"/>
<meta name="twitter:site" content="samspacenter"/>
<meta name="twitter:title" content="Spa in Mumbai, Spa Center in Pune, Delhi, Bangalore, Chennai, Hyderabad, India, UAE, Thailand |samspacenter.com" />
<meta name="twitter:description" content="Spa in mumbai, to transcend yourself from the stressful daily life to luxurious pampering atmosphere in our Sam spa center." />
<link rel="icon" href="<?=base_url()?>/favicon.ico" type="image/gif">

<link rel=â€?publisherâ€? href=â€?https://plus.google.com/u/0/114656577560230400401â€? />
<link rel="icon" href="<?php echo base_url();?>assets/images/icon.png" type="image/x-icon"/>
<link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/typography.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/shortcodes.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/widget.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/js/dl-menu/component.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/svg/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/jquery.bxslider.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/prettyPhoto.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/color.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet">

    

<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106572972-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments)};
  gtag('js', new Date());

  gtag('config', 'UA-106572972-1');
</script>


</head>

<body onkeypress="return disableCtrlKeyCombination(event);" onkeydown = "return disableCtrlKeyCombination(event);" > 
<!--KF KODE WRAPPER WRAP START-->
<div class="kf_wrapper">

<!--HEADER START-->
<header class="absolute">
<div class="container">
<?php //include('common/logo.php'); ?>

<div class="kf-logo-bar">
<!--LOGO START-->
<div class="kf-logo">
<a href="<?php  echo base_url(); ?>"><img src="<?php echo base_url();?>assets/images/SamSpa.png" alt=""/></a>

</div>
<!--LOGO END-->
<!--SEARCH DES START-->
<div class="kf-search-2 ">
<span class="font_c">Advertisement No : +91 9967228816</span>
</div>
<div class="kf-search-1">
<form action="area_data.php" method="post">
<select name="country_id" onchange="showcity(this.value)" class="form-control mb-10" required>
<option value="">Select a country:</option>
<?php
//include_once 'connection.php';
//$sql_maincat = "SELECT  *  FROM countries";
//$sql_maincat = "SELECT * FROM countries where country_name='india'";
//$result_maincat = $connection->query($sql_maincat);

//while ( $row_maincat = $result_maincat->fetch_assoc() ) { $id=$row_maincat['country_id'] ;
//$country_name=$row_maincat['country_name'] ;
//$country_id=$row_maincat['country_id'] ;

?>



<option value="<?php //echo $country_id;?>"><?php //echo $country_name;?></option>
<?php// }?>
</select>


<div id="txtcity">

</div>



</div>                         



</form></div>

<!--SEARCH DES END-->
</div>

<?php //include('common/menu.php');?>
<!--Navigation Wrap Start-->
<div class="kf-nav-outr-wrap">
<!--Navigation Des Start-->
<div class="kf_menu">
<ul>
<li class="active"><a href="<?php echo base_url();?>">Home</a>
</li>
<li><a href="<?php echo base_url();?>About_Us">About Us</a></li>
<li><a href="<?php echo base_url();?>Services">Services</a>
<ul>
<li><a href="<?php echo base_url();?>Services/spa_package">Spa Package</a></li>
<li><a href="<?php echo base_url();?>Services/body_wrap_and_body_scrub">Body Scrub & Wraps</a></li>
<li><a href="<?php echo base_url();?>Services/hair_services">Hair Services</a></li>
<li><a href="<?php echo base_url();?>Services/pedicures_manicures">Pedicure & Menicure</a></li>
<li><a href="<?php echo base_url();?>Services/thai_oil_massage">Thai Oil Massage</a></li>
<li><a href="<?php echo base_url();?>Services/massage">Massage</a></li>

<li><a href="<?php echo base_url();?>Services/Foot_massage">Foot Massage</a></li>
<li><a href="<?php echo base_url();?>Services/makeup">Makeup</a></li>
<li><a href="<?php echo base_url();?>Services/skincare_treatment">Skin Care</a></li>
</ul>
</li>
<li class="active"><a href="<?php echo base_url();?>city">City</a>

</li>
<li class="active"><a href="<?php echo base_url();?>membership">Membership</a>
</li>
<!--                            <li><a href="#">gallery</a>
<ul>
<li><a href="gallery.php">gallery</a></li>
<li><a href="masonary.php">masonary</a></li>
<li><a href="gallery-col3.php">gallery col3</a></li>
</ul>
</li>-->
<li><a href="<?php echo base_url();?>Blog">Blog</a></li>

<li><a href="<?php echo base_url();?>Contact_Us">Contacts</a></li>
<li><a href="<?php echo base_url();?>Country">Country</a></li>
<!--<li><a href="register-login.php" style="color: yellow;font-weight: 800;font-size: 24px;">Post Your Ad</a></li>-->
<li><a href="<?php echo base_url();?>register_login" style="color: yellow;font-weight: 800;font-size: 24px;">Register Here</a></li>
<?php error_reporting(0);session_start(); ?>
 <?php
if ( $this->session->userdata('id') != '' ) { 

?> 
<li><a href="<?php echo base_url();?>register_login/edit_add">Edit Add</a></li>
<li><a href="<?php echo base_url();?>admin/dashboard/logout">Logout</a></li>
<?php } ?>
</ul>
</div>
<!--Navigation Des End-->
<!--DL Menu Start-->
<div id="kode-responsive-navigation" class="dl-menuwrapper">
<button class="dl-trigger">Open Menu</button>
<ul class="dl-menu">
<li class="active"><a href="<?php echo base_url();?>">Home</a>
</li>
<li><a href="<?php echo base_url();?>About_Us">About</a></li>
<li class="active"><a href="<?php echo base_url();?>Membership">Membership</a>
</li>
<li class="active"><a href="<?php echo base_url();?>City">City</a>
</li>
<li class="menu-item kode-parent-menu"><a href="<?php echo base_url();?>Blog">blog</a>

</li>
<li><a href="<?php echo base_url();?>contact_us">Contact Us</a></li>
<li><a href="<?php echo base_url();?>country">Country</a></li>
<li><a href="<?php echo base_url();?>register_login" style="color: yellow;font-weight: 800;font-size: 24px;">Post Your Ad</a></li>
<?php error_reporting(0);session_start(); ?>
 <?php
$session = $_SESSION['reg_id'];
if ( $this->session->userdata('id') != '' ) { 

?>
<li><a href="<?php echo base_url();?>edit_add">Edit Add</a></li>
<li><a href="<?php echo base_url();?>admin/dashboard/logout">Logout</a></li>
<?php } ?>
</ul>
</div>
<!--DL Menu END-->
<!--Kf social Des Strat-->
<div class="kf-social-1">
<ul>
<li><a data-toggle="tooltip" data-placement="bottom" title="facebook" href="https://www.facebook.com/Sam-Spa-Center-1167941773255200" target="_blank"><i class="fa fa-facebook"></i></a></li>
<li><a data-toggle="tooltip" data-placement="bottom" title="twitter" href="https://twitter.com/samspacenter" target="_blank"><i class="fa fa-twitter"></i></a></li>
<li><a data-toggle="tooltip" data-placement="bottom" title="Youtube" href="https://www.youtube.com/channel/UCNEL2eFXrNRh1cKlTw2SIkA" target="_blank"><i class="fa fa-youtube"></i></a></li>
<li><a data-toggle="tooltip" data-placement="bottom" title="pinterest" href="https://in.pinterest.com/samspacenter/" target="_blank"><i class="fa fa-pinterest-p"></i></a></li>
</ul>
</div>
<!--Kf social Des End-->
</div>
<!--Navigation Wrap End-->


</div>
</header>
<!--HEADER END-->


