<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="saturn" >

    <title>Spa in India, Spa Treatments in India</title>
<link rel="icon" href="<?php echo base_url();?>assets/images/icon.png" type="image/x-icon"/>
	<link href="<?php echo base_url();?>assets/css1/bootstrap.min.css" rel="stylesheet">
    <!-- Template specific stylesheets-->
    <link href="<?php echo base_url();?>assets/css1/loaders.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/iconsmind.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/ionicons.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/hamburgers.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/owl.carousel.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/css1/owl.carousel.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/owl.theme.default.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/remodal.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/remodal-default-theme.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/flexslider.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/lightbox.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/StyleSheet.css" rel="stylesheet" type="text/css" />
    <!-- Main stylesheet and color file-->
    <link href="<?php echo base_url();?>assets/css1/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css1/custom.css" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <link href="<?php echo base_url();?>assets/css/jquery-ui.css" rel="stylesheet">

 <style type="text/css">
        iframe#_hjRemoteVarsFrame
        {
            display: none !important;
            width: 1px !important;
            height: 1px !important;
            opacity: 0 !important;
            pointer-events: none !important;
        }
    </style>
</head>
<body data-spy="scroll" data-target=".inner-link" data-offset="60">
    <main>
      <section class="background-primary py-3 d-none d-sm-block">
    <div class="container">
          <div class="row align-items-center">
          <!--<div class="col-lg-2 "></div>-->
          <div class=" col-lg-5"><span class="fa fa-phone color-warning fw-800 icon-position-fix"> <a class="ml-2 mb-0 fs--1 d-inline color-white fw-700" href="#">
Toll-Free  022 4010 0100</a></span> </div>
           
           
            <div class="col-lg-3 "><select class="form-control">
                  <option>Select Country</option>
                </select> </div>
              <div class="col-lg-4 al">
              <div class="col-auto ml-md-auto order-md-2 d-none d-sm-block">
              <p class="ml-2 mb-0 fs--1 d-inline color-white fw-700  float-right"> <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a> </p>
            </div></div>


        <div class="col-auto d-none d-lg-block"></div>
        
        <div class="col-auto">
              
            
         
            </div>
      </div>
          <!--/.row--></div>
    <!--/.container--></section>
      <div class="znav-white znav-container sticky-top navbar-elixir" id="znav-container">
    <div class="container">
          <nav class="navbar navbar-expand-lg"><a class="navbar-brand overflow-hidden pr-3" href="#"><img src="assets/images/SamSpa.png" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger hamburger--emphatic">
          <div class="hamburger-box">
                <div class="hamburger-inner"></div>
              </div>
        </div>
            </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <ul class="navbar-nav fs-0 fw-700">
            <li ><a href="<?php echo base_url(); ?>"><i class="fa fa-home" aria-hidden="true"></i></a> </li>
            <li class="has-dropdown"><a href="<?php echo base_url(); ?>Services">Service</a>
                  <ul class="dropdown fs--1">
                <li><a href="<?php echo base_url(); ?>Services/spa_package">Spa Package</a></li>
                <li><a href="<?php echo base_url(); ?>Services/body_wrap_and_body_scrub">Body wrap and Body Scrub</a></li>
                <li><a href="<?php echo base_url(); ?>Services/hair_services">Hair Services</a></li>
                <li><a href="<?php echo base_url(); ?>Services/pedicures_manicures">Pedicures and Manicures</a></li>
                <li><a href="<?php echo base_url(); ?>Services/thai_oil_massage">Thai Oil Massage</a></li>
                <li><a href="<?php echo base_url(); ?>Services/massage">Massage</a></li>
                <li><a href="<?php echo base_url(); ?>Services/Foot_massage">Foot Massage</a></li>
                <li><a href="<?php echo base_url(); ?>Services/makeup">Makeup</a></li>
                <li><a href="<?php echo base_url(); ?>Services/skincare_treatment">Skin Care</a></li>
              </ul>
                </li>
            <!--li><a href="<?php echo base_url(); ?>Welcome/city">City</a> </li-->
			<li class="active"><a href="<?php echo base_url();?>city">City</a>
            <li ><a href="<?php echo base_url(); ?>membership">Membership</a></li>
            <li><a href="<?php echo base_url(); ?>blog">Blog</a> </li>
            <li><a href="<?php echo base_url(); ?>country">Country</a> </li>
            <li><a class="d-block mr-md-9" href="<?php echo base_url(); ?>advties">Advties</a></li>
          </ul>
              <ul class="navbar-nav ml-lg-auto">
              <li><a class="btn btn-outline-primary btn-capsule btn-sm border-2x fw-700" href="#">Free Listing</a></li>
				<?php
					if ( $this->session->userdata('id') != '' ) { 
				?>
					<li><a class="btn btn-outline-primary btn-capsule btn-sm border-2x fw-700" href="<?php echo base_url();?>admin/dashboard/logout">Logout</a></li>
				<?php } else { ?>
					<li><a class="btn btn-outline-primary btn-capsule btn-sm border-2x fw-700" href="<?php echo base_url(); ?>Login">Login</a></li>
				<?php }?>
			
          </ul>
            </div>
      </nav>
        </div>
  </div>
      <div class="flexslider flexslider-simple" style="min-height: 517px;">
    <ul class="slides">
          <li data-zanim-timeline="{}" class="" data-thumb-alt="" style="width: 100%; float: left; margin-right: -100%; position: relative; opacity: 0; display: block; z-index: 1;">
        <section class="py-0">
              <div class="background-holder" style="background-image:url(assets/images/slider-1.jpg);"></div>
              <!--/.background-holder-->
              <div class="container">
            <div class="row align-items-center py-8" data-inertia="{&quot;weight&quot;:1.5}">
                  <div class="col-sm-8 col-lg-7 px-5 px-sm-3">
                <div class="overflow-hidden">
                      <h1 class="fs-4 fs-md-5 zopacity" data-zanim="{&quot;delay&quot;:0}" style="opacity: 0; transform: matrix(1, 0, 0, 1, 0, 65);">Swedish Massage Therapy</h1>
                    </div>
                <div class="overflow-hidden">
                      <p class="color-primary mt-4 mb-5 lh-2 fs-1 fs-md-2 zopacity" data-zanim="{&quot;delay&quot;:0.1}" style="opacity: 0; transform: matrix(1, 0, 0, 1, 0, 65);">We look forward to help you in taking your company to new height.</p>
                    </div>
                <div class="overflow-hidden">
                      <div class="zopacity" data-zanim="{&quot;delay&quot;:0.2}" style="opacity: 0; transform: matrix(1, 0, 0, 1, 0, 65);"><a class="btn btn-primary mr-3 mt-3" href="#">Read more<span class="fa fa-chevron-right ml-2"></span></a><a class="btn btn-warning mt-3" href="#">Contact us<span class="fa fa-chevron-right ml-2"></span></a></div>
                    </div>
              </div>
                </div>
            <!--/.row--></div>
              <!--/.container--></section>
      </li>
          <li data-zanim-timeline="{}" data-thumb-alt="" style="width: 100%; float: left; margin-right: -100%; position: relative; opacity: 1; display: block; z-index: 2;" class="flex-active-slide">
        <section class="py-0">
              <div class="background-holder" style="background-image:url(assets/images/slider-2.jpg);"></div>
              <!--/.background-holder-->
              <div class="container">
            <div class="row align-items-center py-8" data-inertia="{&quot;weight&quot;:1.5}">
                  <div class="col-sm-8 col-lg-7 px-5 px-sm-3">
                <div class="overflow-hidden">
                      <h1 class="fs-4 fs-md-5 zopacity" data-zanim="{&quot;delay&quot;:0}" style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">Aromatherapy Massage.</h1>
                    </div>
                <div class="overflow-hidden">
                      <p class="color-primary mt-4 mb-5 lh-2 fs-1 fs-md-2 zopacity" data-zanim="{&quot;delay&quot;:0.1}" style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">Over 10 years of experience in helping clients finding comprehensive solutions.</p>
                    </div>
                <div class="overflow-hidden">
                      <div class="zopacity" data-zanim="{&quot;delay&quot;:0.2}" style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"><a class="btn btn-primary mr-3 mt-3" href="#">Read more<span class="fa fa-chevron-right ml-2"></span></a><a class="btn btn-warning mt-3" href="#">Contact us<span class="fa fa-chevron-right ml-2"></span></a></div>
                    </div>
              </div>
                </div>
            <!--/.row--></div>
              <!--/.container--></section>
      </li>
          <li data-zanim-timeline="{}" data-thumb-alt="" style="width: 100%; float: left; margin-right: -100%; position: relative; opacity: 0; display: block; z-index: 1;">
        <section class="py-0">
              <div class="background-holder" style="background-image:url(assets/images/slider-3.jpg);"></div>
              <!--/.background-holder-->
              <div class="container">
            <div class="row align-items-center py-8" data-inertia="{&quot;weight&quot;:1.5}">
                  <div class="col-sm-8 col-lg-7 px-5 px-sm-3">
                <div class="overflow-hidden">
                      <h1 class="fs-4 fs-md-5 zopacity" data-zanim="{&quot;delay&quot;:0}" style="opacity: 0; transform: matrix(1, 0, 0, 1, 0, 65);">Deep Tissue Massage</h1>
                    </div>
                <div class="overflow-hidden">
                      <p class="color-primary mt-4 mb-5 lh-2 fs-1 fs-md-2 zopacity" data-zanim="{&quot;delay&quot;:0.1}" style="opacity: 0; transform: matrix(1, 0, 0, 1, 0, 65);">Connect with top consultants hand-picked by Elixir consulting and finance. </p>
                    </div>
                <div class="overflow-hidden">
                      <div class="zopacity" data-zanim="{&quot;delay&quot;:0.2}" style="opacity: 0; transform: matrix(1, 0, 0, 1, 0, 65);"><a class="btn btn-primary mr-3 mt-3" href="#">Read more<span class="fa fa-chevron-right ml-2"></span></a><a class="btn btn-warning mt-3" href="#">Contact us<span class="fa fa-chevron-right ml-2"></span></a></div>
                    </div>
              </div>
                </div>
            <!--/.row--></div>
              <!--/.container--></section>
      </li>
        </ul>
    <ol class="flex-control-nav flex-control-paging">
          <li><a href="#" class="">1</a></li>
          <li><a href="#" class="flex-active">2</a></li>
          <li><a href="#">3</a></li>
        </ol>
    <ul class="flex-direction-nav">
          <li class="flex-nav-prev"><a class="flex-prev" href="#">Previous</a></li>
          <li class="flex-nav-next"><a class="flex-next" href="#">Next</a></li>
        </ul>
  </div>