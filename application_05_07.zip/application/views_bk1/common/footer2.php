<!--FOOTER START-->
<!--FOOTER START-->

<div class="col-xs-12">
 <?php 
/* include 'connection.php';  
$newpath=$_SERVER['PHP_SELF'];
$path = $newpath;
$breadog = basename($path); 

$ban_query="SELECT * FROM keyword where city_id='$city' order by rand() limit 60";
$ban_result=$connection->query($ban_query);

while($myad_row=$ban_result->fetch_array()){  */
    //echo $myad_row['areaname'];
?>   

    <a href="area_data.php?city_id=<?php //echo $city; ?>" class="keyword" title="<?php //echo $myad_row['keywordn'];?> <?php //echo $myad_row['areaname']; ?>">
        <?php //echo $myad_row['keywordn'];?>  <?php //echo $myad_row['areaname'];?><?php //echo ' | ' ;?>
    </a>

        
        <?php // }?>  
</div>
<footer class="kf_footer_bg">
<div class="container">
<div class="row">
<!--Footer Text Widget Start-->
<div class="col-md-4">
<div class="widget">
<h4>About Spa</h4>
<div class="text">
<p class="middle">Spa Company is one of the best and leading companies in India known for delivering the quality services. It gives the unique experience to the clients by our special treatment and massage therapies. Spa experts of our company have designed natural treatments where you will come across with different herbal and ancient techniques, </p><a href="./about-us.php" style="color:rosybrown;font-size: 18px;">Read More</a>

</div>
</div>
</div>
<!--Footer Text Widget End-->

<!--Footer Twitter Widget Start-->
<div class="col-md-4">
<div class="widget widget-twitter">
    <a href="http://organichealthplanet.com/" target="_blank"><img src="assets/images/organic-health-planet.jpg" ">
    </a>
</div>
</div>
<!--Footer Twitter Widget Start-->

<!--Footer Instagram Widget Start-->
<div class="col-md-4">
<div class="widget widget-instagram">
<h4>Instagram</h4>
<ul>
<li>
<a>
<img src="<?php echo base_url();?>assets/extra-images/ft-thumb1.jpg" 
</a>
</li>
<li>
<a>
<img src="<?php echo base_url();?>assets/extra-images/ft-thumb2.jpg"/>

</a>
</li>
<li>
<a>
<img src="<?php echo base_url();?>assets/extra-images/ft-thumb3.jpg" />

</a>
</li>
<li>
<a>
<img src="<?php echo base_url();?>assets/extra-images/ft-thumb4.jpg" />

</a>
</li>
<li>
<a>
<img src="<?php echo base_url();?>assets/extra-images/ft-thumb5.jpg">

</a>
</li>
<li>
<a>
<img src="<?php echo base_url();?>assets/extra-images/ft-thumb6.jpg">

</a>
</li>
<li>
<a>
<img src="<?php echo base_url();?>assets/extra-images/ft-thumb7.jpg" />
 
</a>
</li>
<li> 
<a>
<img src="<?php echo base_url();?>assets/extra-images/ft-thumb8.jpg" />

</a>
</li>
</ul>
</div>
</div>
<!--Footer Instagram Widget End-->
</div>
<!--COPYRIGHTS START-->
<div class="kf_copyright_wrap">
<!--Copy Right Nav Start-->
<ul class="kf-footer-nav">

<li><a href="Body-Spa-in-Mumbai.php">Mumbai</a></li>
<li><a href="Body-Spa-in-Bangalore.php">Bangalore</a></li>
<li><a href="Body-Spa-in-Delhi.php">Delhi</a></li>
<li><a href="Spa-Center-in-Pune.php">Pune</a></li>
<li><a href="Spa-Center-in-Hyderabad.php">Hyderabad</a></li>
<li><a href="Spa-Center-in-Chennai.php">Chennai</a></li>
<li><a href="Spa-Center-in-Kolkata.php">Kolkata</a></li>
<li><a href="Spa-Center-in-Goa.php">Goa</a></li>
<li><a href="Spa-Center-in-Chandigarh.php">Chandigarh</a></li>
<li><a href="Spa-Center-in-Jaipur.php">Jaipur</a></li>





</ul>

<ul class="kf-footer-nav">
   <li><a href="Spa-in-Bhopal.php">Bhopal</a></li>
<li><a href="Spa-in-Ranchi.php">Ranchi</a></li>
<li><a href="Spa-in-Surat.php">Surat</a></li>
<li><a href="Spa-in-Nashik.php">Nashik</a></li>
<li><a href="Spa-in-Vizag.php">Vizag</a></li>
<li><a href="Spa-in-Ahmedabad.php">Ahmedabad</a></li>
<li><a href="Spa-in-Agra.php">Agra</a></li>
<li><a href="Spa-in-Lucknow.php">Lucknow</a></li>
<li><a href="Body-Spa-in-Nagpur.php">Nagpur</a></li> 
<li><a href="Spa-in-Gurgaon.php">Gurgaon</a></li> 
</ul>



<ul class="kf-footer-nav">

<li><a href="index.php">Sam Spa Center </a></li>
<li><a href="index.php">spa holidays in india</a></li>
<li><a href="index.php">luxury spas in india</a></li>
<li><a href="index.php">Massage parlours in india</a></li>
<li><a href="index.php">body massage at home by female </a></li>

</ul>


<ul class="kf-footer-nav">

<li><a href="index.php">Home</a></li>
<li><a href="about-us.php">About Us</a></li>
<li><a href="Services.php">Services</a></li>
<li><a href="membership.php">Membership</a></li>
<li><a href="blog.php">Blog</a></li>
<li><a href="contact-us.php">Contact Us</a></li>
<li><a href="country.php">Country</a></li>
</ul>
<!--Copy Right Nav End-->

<!--Copy Right Social Start-->
<ul class="kf-footer-social">
<li><a data-toggle="tooltip" data-placement="bottom" title="facebook" href="https://www.facebook.com/Sam-Spa-Center-1167941773255200" target="_blank"><i class="fa fa-facebook"></i></a></li>
<li><a data-toggle="tooltip" data-placement="bottom" title="twitter" href="https://twitter.com/samspacenter" target="_blank"><i class="fa fa-twitter"></i></a></li>
<li><a data-toggle="tooltip" data-placement="bottom" title="linkedin" href="https://www.youtube.com/channel/UCHbo47oUoYV-93M93DREMTA" target="_blank"><i class="fa fa-youtube"></i></a></li>
<li><a data-toggle="tooltip" data-placement="bottom" title="pinterest" href="https://in.pinterest.com/samspacenter/" target="_blank"><i class="fa fa-pinterest-p"></i></a></li>
</ul>
<!--Copy Right Social End-->
</div>
<!--COPYRIGHTS START-->
</div>
</footer>

<div class="go-up">
<i class="icon-spa"></i>
</div>

<!--FOOTER END-->


</div>
<!--KF KODE WRAPPER WRAP END-->
<script src="<?php echo base_url();?>assets/js/jquery.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<!--Dl Menu Script-->
<script src="<?php echo base_url();?>assets/js/dl-menu/modernizr.custom.js"></script>
<script src="<?php echo base_url();?>assets/js/dl-menu/jquery.dlmenu.js"></script>
<!--Bx-Slider JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.bxslider.min.js"></script>
<!--Map-->

<!--Pretty Photo JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.prettyPhoto.js"></script>
<!--Full Count Down JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.downCount.js"></script>
<!--Number Count (Waypoints) JavaScript-->
<script src="<?php echo base_url();?>assets/js/waypoints-min.js"></script>
<!-- include Masonry -->
<script src="<?php echo base_url();?>assets/js/isotope.pkgd.min.js"></script> 
<!--Custom JavaScript-->
<script src="<?php echo base_url();?>assets/js/custom.js"></script>

<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>

</body>


</html>
