  </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?php echo base_url();?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/sb-admin-2.js"></script>
	 <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
     <footer style="background-color: #f6c42d;">
    <div class="container">
          <div class="row align-items-center">



          <div class="col-sm-6 col-lg-3 color-white ml-lg-auto">
              <ul class="list-unstyled">
                <li class="mb-3"><a class="color-white" href="#">Contact Us</a></li>
                <li class="mb-3"><a class="color-white" href="#">FAQ</a></li>
                <li class="mb-3"><a class="color-white" href="#">Privacy Policy</a></li>
                <li class="mb-3"><a class="color-white" href="#">Terms of Use</a></li>
                <li class="mb-3"><a class="color-white" href="#">Global Office</a></li>
                <li class="mb-3"><a class="color-white" href="#">Local Office</a></li>
              </ul>          
          </div>
           <div class="col-sm-6 col-lg-6">
           
             <div class="background-primary color-white p-5 p-lg-6 radius-secondary">
            <h4 class="color-white fs-1 fs-lg-2 mb-1">Sign up for email alerts</h4>
            <p class="color-white" style="font-size:1em;color: #f6c42d;">Stay current with our latest insights</p>
            <form class="mt-4">
                  <div class="row align-items-center">
                <div class="col-md-7 pr-md-0">
                      <div class="input-group">
                    <input class="form-control" type="email" placeholder="Enter Email Here">
                  </div>
                    </div>
                <div class="col-md-5 mt-3 mt-md-0">
                      <button class="btn btn-warning btn-block" type="submit"><span class="color-primary fw-600">Submit</span></button>
                    </div>
              </div>
                </form>
          </div>           
           </div>
            <div class="col-sm-6 col-lg-3 ">
            <img src="assets/images/visa.jpg" style="width:100%" />
            <div class="clearfix"></div>
            <br />

            <div class="socilbg">
              <a href="#">

                  <div class="background-primary text-center d-flex align-items-center radius-primary" style="height: 40px; width: 40px; float:right; margin-right:5px;"><span class="w-100 fa fa-linkedin color-white"></span></div>
           
              </a>
              <a href="#">
          
                  <div class="background-primary text-center d-flex align-items-center radius-primary" style="height: 40px; width: 40px; float:right; margin-right:5px;"><span class="w-100 fa fa-twitter color-white"></span></div>
              
              </a><a href="#">
              
                  <div class="background-primary text-center d-flex align-items-center radius-primary" style="height: 40px; width: 40px; float:right; margin-right:5px;"><span class="w-100 fa fa-facebook color-white"></span></div>
               
              </a><a href="#">
       
                  <div class="background-primary text-center d-flex align-items-center radius-primary" style="height: 40px; width: 40px; float:right; margin-right:5px;"><span class="w-100 fa fa-google-plus color-white"></span></div>
              
              </a>
            
            </div>
            </div>
      </div>


<p><a href="#"> Ahmedabad</a> / <a href="#">Bangalore</a> / <a href="#">Chandigarh</a> / <a href="#">Chennai</a> / <a href="#">Coimbatore</a> / <a href="#">Delhi-NCR</a> / <a href="#">Ernakulam</a> / <a href="#">Goa</a> / <a href="#">Hyderabad</a> / <a href="#">Indore</a> / <a href="#">Jaipur</a> / <a href="#">Kolkata</a> / <a href="#">Mumbai</a> / <a href="#">Mysore</a> / <a href="#">Nagpur</a> / <a href="#">Nashik</a> / <a href="#">Pune</a> / <a href="#">Surat</a> / <a href="#">Vadodara</a> / <a href="#">Vizag</a> / <a href="#">Latest Reviews</a> / <a href="#">National Search</a> </p>


</div>
</footer>

  <section class="fpm">
   <div class="container">

<p class="fp">Spa Company is one of the best and leading companies in India known for delivering the quality services. It gives the unique experience to the clients by our special treatment and massage therapies. Spa experts of our company have designed natural treatments where you will come across with different herbal and ancient techniques, which gives the best mode in the field of relaxation. Our Spa experts are trained and professionals who provide customized services according to the customers need. These experts are friendlier in nature and solve the problem of the clients in an effective way.</p>
  </div>
    </section>
  
  
      <section class="background-primary text-center py-4">
    <div class="container">
          <div class="row align-items-center" style="opacity: 0.85;">
        <div class="col-sm-3 text-sm-left"><!--<a href="#"><img src="assets/images/logo-light.png" alt=""></a>--></div>
        <div class="col-sm-6 mt-3 mt-sm-0">
              <p class="color-white lh-6 mb-0 fw-600 cp">© Copyright 2018 Sam Spa Center</p>
            </div>
        <div class="col text-sm-right mt-3 mt-sm-0"><!--<a class="color-white" href="#" target="_blank"> Designed by Themewagon</a>--></div>
      </div>
          <!--/.row--></div>
    <!--/.container--></section>
    </main>
    <!--  -->
    <!--    JavaScripts-->
    <!--    =============================================-->
    <script src="<?php echo base_url();?>assets/js1/modernizr.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/popper.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/imagesloaded.pkgd.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/TweenMax.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/ScrollToPlugin.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/CustomEase.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/config.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/zanimation.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/owl.carousel.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/remodal.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/lightbox.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/jquery.flexslider-min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/core.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/main.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js1/js.js" type="text/javascript"></script>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
</body>
</html>

    
