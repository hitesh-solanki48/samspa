
<div class="kf-logo-bar">
<!--LOGO START-->
<div class="kf-logo">
<a href="/"><img src="<?php echo base_url();?>/images/SamSpa.png" alt=""/></a>

</div>
<!--LOGO END-->
<!--SEARCH DES START-->
<div class="kf-search-2 ">
<span class="font_c">Advertisement No : +91 9967228816</span>
</div>
<div class="kf-search-1">
<form action="area_data.php" method="post">
<select name="country_id" onchange="showcity(this.value)" class="form-control mb-10" required>
<option value="">Select a country:</option>
<?php
include_once 'connection.php';
$sql_maincat = "SELECT  *  FROM countries";
//$sql_maincat = "SELECT * FROM countries where country_name='india'";
$result_maincat = $connection->query($sql_maincat);

while ( $row_maincat = $result_maincat->fetch_assoc() ) { $id=$row_maincat['country_id'] ;
$country_name=$row_maincat['country_name'] ;
$country_id=$row_maincat['country_id'] ;

?>



<option value="<?php echo $country_id;?>"><?php echo $country_name;?></option>
<?php }?>
</select>


<div id="txtcity">

</div>



</div>                         



</form></div>

<!--SEARCH DES END-->
</div>
<!--Logo Bar End-->
<script>
function showcity(str) {
if (str == "") {
document.getElementById("txtcity").innerHTML = "";
return;
} else { 
if (window.XMLHttpRequest) {
// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp = new XMLHttpRequest();
} else {
// code for IE6, IE5
xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange = function() {
if (this.readyState == 4 && this.status == 200) {
document.getElementById("txtcity").innerHTML = this.responseText;
}
};
xmlhttp.open("GET","getallcity.php?q="+str,true);
xmlhttp.send();
}
}
</script>				

