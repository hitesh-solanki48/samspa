


<!--Navigation Wrap Start-->
<div class="kf-nav-outr-wrap">
<!--Navigation Des Start-->
<div class="kf_menu">
<ul>
<li class="active"><a href="/">Home</a>
</li>
<li><a href="<?php echo base_url();?>Welcome/about-us.php">About Us</a></li>
<li><a href="<?php echo base_url();?>Welcome/Services.php">Services</a>
<ul>
<li><a href="<?php echo base_url();?>Welcome/spa-package.php">Spa Package</a></li>
<li><a href="<?php echo base_url();?>Welcome/body-wrap-and-body-scrub.php">Body Scrub & Wraps</a></li>
<li><a href="<?php echo base_url();?>Welcome/hair-services.php">Hair Services</a></li>
<li><a href="<?php echo base_url();?>Welcome/pedicures-manicures.php">Pedicure & Menicure</a></li>
<li><a href="<?php echo base_url();?>Welcome/thai-oil-massage.php">Thai Oil Massage</a></li>
<li><a href="<?php echo base_url();?>Welcome/massage.php">Massage</a></li>

<li><a href="<?php echo base_url();?>Welcome/Foot-massage.php">Foot Massage</a></li>
<li><a href="<?php echo base_url();?>Welcome/makeup.php">Makeup</a></li>
<li><a href="<?php echo base_url();?>Welcome/skincare-treatment.php">Skin Care</a></li>
</ul>
</li>
<li class="active"><a href="<?php echo base_url();?>Welcome/city.php">City</a>

</li>
<li class="active"><a href="<?php echo base_url();?>Welcome/membership.php">Membership</a>
</li>
<!--                            <li><a href="#">gallery</a>
<ul>
<li><a href="gallery.php">gallery</a></li>
<li><a href="masonary.php">masonary</a></li>
<li><a href="gallery-col3.php">gallery col3</a></li>
</ul>
</li>-->
<li><a href="<?php echo base_url();?>Welcome/blog.php">Blog</a></li>

<li><a href="<?php echo base_url();?>Welcome/contact-us.php">Contacts</a></li>
<li><a href="<?php echo base_url();?>Welcome/country.php">Country</a></li>
<!--<li><a href="register-login.php" style="color: yellow;font-weight: 800;font-size: 24px;">Post Your Ad</a></li>-->
<li><a href="<?php echo base_url();?>Welcome/register-login.php" style="color: yellow;font-weight: 800;font-size: 24px;">Register Here</a></li>
<?php error_reporting(0);session_start(); ?>
 <?php
$session = $_SESSION['reg_id'];
//if ( isset($session) ) { 

?> 
<li><a href="<?php echo base_url();?>Welcome/edit-add.php">Edit Add</a></li>
<li><a href="<?php echo base_url();?>Welcome/logout.php">Logout</a></li>
<?php// } ?>
</ul>
</div>
<!--Navigation Des End-->
<!--DL Menu Start-->
<div id="kode-responsive-navigation" class="dl-menuwrapper">
<button class="dl-trigger">Open Menu</button>
<ul class="dl-menu">
<li class="active"><a href="<?php echo base_url();?>Welcome/index.php">Home</a>
</li>
<li><a href="<?php echo base_url();?>Welcome/about-us.php">About</a></li>
<li class="active"><a href="<?php echo base_url();?>Welcome/membership.php">Membership</a>
</li>
<li class="active"><a href="<?php echo base_url();?>Welcome/city.php">City</a>
</li>
<li class="menu-item kode-parent-menu"><a href="<?php echo base_url();?>Welcome/blog.php">blog</a>

</li>
<li><a href="<?php echo base_url();?>Welcome/contact-us.php">Contact Us</a></li>
<li><a href="<?php echo base_url();?>Welcome/country.php">Country</a></li>
<li><a href="<?php echo base_url();?>Welcome/register-login.php" style="color: yellow;font-weight: 800;font-size: 24px;">Post Your Ad</a></li>
<?php error_reporting(0);session_start(); ?>
 <?php
$session = $_SESSION['reg_id'];
//if ( isset($session) ) { 

?>
<li><a href="<?php echo base_url();?>Welcome/edit-add.php">Edit Add</a></li>
<li><a href="<?php echo base_url();?>Welcome/logout.php">Logout</a></li>
<?php// } ?>
</ul>
</div>
<!--DL Menu END-->
<!--Kf social Des Strat-->
<div class="kf-social-1">
<ul>
<li><a data-toggle="tooltip" data-placement="bottom" title="facebook" href="https://www.facebook.com/Sam-Spa-Center-1167941773255200" target="_blank"><i class="fa fa-facebook"></i></a></li>
<li><a data-toggle="tooltip" data-placement="bottom" title="twitter" href="https://twitter.com/samspacenter" target="_blank"><i class="fa fa-twitter"></i></a></li>
<li><a data-toggle="tooltip" data-placement="bottom" title="Youtube" href="https://www.youtube.com/channel/UCNEL2eFXrNRh1cKlTw2SIkA" target="_blank"><i class="fa fa-youtube"></i></a></li>
<li><a data-toggle="tooltip" data-placement="bottom" title="pinterest" href="https://in.pinterest.com/samspacenter/" target="_blank"><i class="fa fa-pinterest-p"></i></a></li>
</ul>
</div>
<!--Kf social Des End-->
</div>
<!--Navigation Wrap End-->
