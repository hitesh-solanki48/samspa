<?php include('common/header2.php'); ?>
<!--Home Page Banner Start-->
<?php //echo '<pre>'; print_r($userRow); ?>
<div class="kode-home-banner inner-banner">
<h6><?php echo $title; ?></h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
    <h6><a href="<?php echo base_url(); ?>City/spa_center_detail/<?php echo $userRow[0]['post_id']; ?>" style="color: white;"><?php echo $userRow[0]['title']; ?> in <?php echo $userRow[0]['location']; ?></a></h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a></li>

<li><a href="<?php echo base_url(); ?>City/spa_center_detail/<?php echo $userRow[0]['post_id']; ?>"><?php echo $userRow[0]['location']; ?></a></li>
</ul>
</div>
</div>
</div>


<div class="kf_content_wrap">
<div class="blog-sidebar">
<div class="container">
<div class="row">
   
<div class="col-md-6">

<figure>
    <img src="<?php echo base_url(); ?>assets/images/add_data/<?php echo $userRow[0]['image']; ?>" title="<?php echo $userRow[0]['image']; ?>" alt="<?php echo $userRow[0]['image']; ?>" style="height: 454px;"/>
</figure>

</div>
    
<div class="col-md-6">

 <div class="kode-map">
                 
<?php if($userRow[0]['map_link'] != '') { echo $userRow[0]['map_link']; }?>
 </div>

</div>    
    <div class="col-md-12">
        <h3 class="border-style" title="<?php echo $userRow[0]['title']; ?>" style="text-align: center;margin-top: 18px;"><?php echo $userRow[0]['title']; ?></h3>
        
    </div>
    
    <div class="col-md-6">
        <div class="text" style="text-align: justify;margin-top: 12px;">
            <p>
              <?php echo $userRow[0]['description']; ?>  
            </p>    
        </div>    
    </div>  
       <div class="col-md-6">
           <div class="text" style="text-align: justify;margin-top: 12px;">
               <p style="font-size: 18px;text-transform: capitalize;"><br>
                   <b>Address :  </b>  <?php echo $userRow[0]['address']; ?>  <br>
                   <b>City :  </b> <?php echo $userRow[0]['city_name']; ?>  <br>
                   <b>Country :  </b> <?php echo $userRow[0]['country_name']; ?>  <br>
                   <b>Contact Person :  </b> <?php echo $userRow[0]['contact_person']; ?>  <br>
                   <b>Contact Number :  </b>  <?php echo $userRow[0]['cont_number']; ?>  <br>
                   <b>Email Id :</b> <?php echo $userRow[0]['email']; ?>  
               </p>
               
           </div>
    </div>  
    

</div>
</div>
</div>
</div>

<?php include('common/footer1.php'); ?>
