<?php include('common/header2.php'); ?>
<!--Home Page Banner Start--> <?php //echo '<pre>'; print_r($mainCity[0]['city_name']); ?>
<div class="kode-home-banner inner-banner">
<h6>Body Spa <?php echo $mainCity[0]['city_name']; ?></h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
    <h6><a href="<?php echo base_url(); ?>City/areaData/<?php echo $mainCity[0]['city_country_id']; ?>" style="color: white;">Spa in <?php echo $mainCity[0]['city_name']; ?></a></h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a></li>
<li><a href="<?php echo base_url(); ?>City/areaData/<?php echo $mainCity[0]['city_country_id']; ?>">Spa in <?php echo $mainCity[0]['city_name']; ?></a></li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->
<div class="kf_content_wrap">
    
<div class="blog-sidebar">
    
<div class="container">
<div class="row">
    
    <a id="gridlink" href="#"><i class="fa fa-table" aria-hidden="true" style="font-size: 29px;color: #DDAB14;padding: 0 5px 5px 17px;margin-right: 13px;"></i></a> 
<a id="listlink" href="#"><i class="fa fa-list" aria-hidden="true" style="font-size: 29px;color: #DDAB14;padding: 0 5px 5px 17px;margin-right: 13px;"></i></a>
<!--Side Bar Start-->
<aside class="col-md-3 col-sm-6">
<!--Search Bar Start-->

<!--Search Bar End-->
<!--Widget Categories Start-->
<div class="widget widget-categories">
<!--Heading Start-->
<div class="sidebar-heading">
<h3>Select Below Option</h3>
</div>
<!--Heading End-->
 <?php
 /* $country_id=$_REQUEST['country_id'];
  include_once 'connection.php';
$sql_maincat = "SELECT * FROM countries where country_id='$country_id'";
//$sql_maincat = "SELECT * FROM countries where country_name='india'";
$result_maincat = $connection->query($sql_maincat);
global $country_name,$country;
while ( $row_maincat = $result_maincat->fetch_assoc() ) { $id=$row_maincat['country_id'] ;
$country_name=$row_maincat['country_name'] ;
$country=$row_maincat['country_id'] ;
} */
?>

<div class="contact-input">
    <label style="font-size: 18px;">Selected Country</label>    
<select name="country" id="country" class="form-control mb-10" onchange="showadv(this.value)" required>
    
    <option value="<?php //echo $c_id;?>"><?php //echo $cname;?></option>   

  <?php
  /* include_once 'connection.php';
  $sql_maincat = "SELECT * FROM countries where status=1";
//$sql_maincat = "SELECT * FROM countries where country_name='india'";
$result_maincat = $connection->query($sql_maincat);

while ( $row_maincat = $result_maincat->fetch_assoc() ) { $id=$row_maincat['country_id'] ;
$country_name=$row_maincat['country_name'] ;
$country_id=$row_maincat['country_id'] ; */

?>

  <option value="<?php //echo $country_id;?>"><?php //echo $country_name;?></option>
<?php //}?>



</select>
</div>







<div id="txtHint">
   <div class="contact-input">
    <label style="font-size: 18px;">Selected City</label>    
<select name="country" id="country" class="form-control mb-10">
    
    <option value="<?php echo $mainCity[0]['city_country_id'];?>"><?php echo $mainCity[0]['city_name']; ?></option>   

</select>
</div>
    
    <ul>
       <label style="font-size: 18px;">Select Area</label>     
        
<?php  /* $city_id=$_REQUEST['city_id'];
  	$sql_area = "SELECT DISTINCT area,country_id,city_id FROM adpost WHERE city_id='$city_id' and payment='paid'";
  	$result_subcat = $conn->query($sql_area);
  	while ( $row_subcat = $result_subcat->fetch_assoc() ) { */ ?>
  
<li class="sidebar-border">
    <a href="area_data.php?area=<?php //echo $row_subcat['area']; ?>&country_id=<?php //echo $row_subcat['country_id']; ?>&city_id=<?php //echo $row_subcat['city_id']; ?>" style="color: darkred;font-weight: 800;"><?php //echo $row_subcat['area']; ?></a>
</li>

  <?php	//} ?>
</ul>
    
    
</div>




</div>
<!--Widget Categories End-->
<!--Widget Post Start-->
<div class="widget widget-post">
<!--Heading Start-->
<div class="sidebar-heading">
<h3>Latest Add</h3>
</div>
<!--Heading End-->
<ul>
<?php  
/* include_once 'connection.php';
$ban_query="SELECT * FROM adpost where payment='paid' order by rand() limit 3";
$ban_result=$connection->query($ban_query);

while($myad_row=$ban_result->fetch_array()){     */
    ?>
<li>
<div class="kf-post">
<figure>
<a href="spa-center-detail.php?id=<?php //echo $myad_row['id']; ?>"><img src="adpostimage/<?php //echo $myad_row['fileToUpload']; ?>" alt="" height="80"/></a>

</figure>
<div class="text">
  <a href="spa-center-detail.php?id=<?php //echo $myad_row['id']; ?>" style="color: #3D2415;">  <?php //echo $myad_row['title']; ?></a>

</div>
</div>
</li>
<?php //} ?>

<!--
<li>
<div class="kf-post">
<figure>
<a href="#"><img src="extra-images/post-3.jpg" alt=""/></a>
<figcaption><a href="#"><i class="fa fa-search-plus"></i></a></figcaption>
</figure>
<div class="text">
<p>Duis sed odio sit amet nibh vulputate cursus a sit amet mauris.</p>
<a href="#">09 March, 2016</a>
</div>
</div>
</li>-->
</ul>
</div>
<!--Widget Post End-->
<!--Widget Categories Start-->

<!--Widget Categories End-->
<!--Widget Flickr Start-->
<div class="widget widget-instagram flickr">
<!--Heading Start-->
<div class="sidebar-heading">
<h3>Photos</h3>
</div>
<!--Heading End-->
<ul>
<li>
<a data-rel="prettyPhoto[]" href="extra-images/siderbar-thumb1.jpg">
<img src="extra-images/siderbar-thumb1.jpg" alt="">
<i class="fa fa-search"></i>
</a>
</li>
<li>
<a data-rel="prettyPhoto[]" href="extra-images/siderbar-thumb2.jpg">
<img src="extra-images/siderbar-thumb2.jpg" alt="">
<i class="fa fa-search"></i>
</a>
</li>
<li>
<a data-rel="prettyPhoto[]" href="extra-images/siderbar-thumb3.jpg">
<img src="extra-images/siderbar-thumb3.jpg" alt="">
<i class="fa fa-search"></i>
</a>
</li>
<li>
<a data-rel="prettyPhoto[]" href="extra-images/siderbar-thumb4.jpg">
<img src="extra-images/siderbar-thumb4.jpg" alt="">
<i class="fa fa-search"></i>
</a>
</li>
<li>
<a data-rel="prettyPhoto[]" href="extra-images/siderbar-thumb5.jpg">
<img src="extra-images/siderbar-thumb5.jpg" alt="">
<i class="fa fa-search"></i>
</a>
</li>
<li>
<a data-rel="prettyPhoto[]" href="extra-images/siderbar-thumb6.jpg">
<img src="extra-images/siderbar-thumb6.jpg" alt="">
<i class="fa fa-search"></i>
</a>
</li>
</ul>
</div>
<!--Widget Flickr End-->

</aside>
<!--Side Bar End-->


<div id="divgrid">
<div class="col-md-9 col-sm-6">
<div class="blog-3-page">
<!--Blog 3 Page Content Start-->
<div class="row">
<!--Blog 3 Thumb Start-->

<?php  

foreach( $userRow as $val) { ?>

<div class="col-md-4">
<div class="blog-thumb">
<figure>
    <a href="<?php echo base_url(); ?>City/spa_center_detail/<?php echo $val['post_id']; ?>"> <img src="<?php echo base_url(); ?>assets/images/add_data/<?php echo $val['image']; ?>" alt="<?php echo $val['title']; ?>" height="200"/></a>
</figure>
<div class="text">

    <h5 title="<?php echo $val['title']; ?>"><a href="<?php echo base_url(); ?>City/spa_center_detail/<?php echo $val['post_id']; ?>"><?php echo $val['title']; ?></a></h5>
<?php 
 
       $str = $val['description'];
        $string = strip_tags($str);
        if (strlen($string) > 94) { $stringCut = substr($string, 0, 94);$string = substr($stringCut, 0, strrpos($stringCut, ' '));}
        

?>
<p style="text-align: justify;"><?php echo $string; ?> <a href="<?php echo base_url(); ?>City/spa_center_detail/<?php echo $val['post_id']; ?>">..Read More</a></p>

<em>Location :-<span><?php echo  $val['city_name']; ?></span> | <?php echo $val['location']; ?></em>

</div>
</div>
</div>

<?php  } ?>


<!--Blog 3 Thumb End-->
<!--Blog 3 Thumb Start-->
<!--<div class="col-md-4 hidden-sm">
<div class="blog-thumb">
<figure>
<img src="extra-images/blog3-6.jpg" alt=""/>
</figure>
<div class="text">
<a href="#"><i class="fa fa-image"></i></a>
<h5><a href="#">Nemo enim ipsam voluptatem voluptas sit aspernatur</a></h5>
<p>Sed non  mauris vitae erat consequat auctor eu in elit. Class apten taciti soco litora torquent per   conubia nostra per inceptos himenaeos. </p>
<em>Posted on <span>25 Feb</span> ,2015</em>
</div>
</div>
</div>-->

<!--Blog 3 Thumb End-->
<!--pagination-->

</div>



<!--Blog 3 Page Content End-->
</div>
</div>
</div>



<div id="divlist" style="display:none">
<div class="col-md-9 col-sm-6">
<div class="blog-3-page">
<!--Blog 3 Page Content Start-->
<div class="row">
<!--Blog 3 Thumb Start-->

<?php  
foreach( $userRow as $val) {
?>

<div class="col-md-4">

<figure>
    <a href="spa-center-detail.php?id=<?php echo $val['post_id']; ?>"> <img src="<?php echo base_url(); ?>assets/images/add_data/<?php echo $val['image']; ?>" alt="<?php echo $val['title']; ?>" height="200"/></a>
</figure>

</div>

<div class="col-md-8">


<div class="text" style="height: 231px;margin-top: 24px;">


    <h5 title="<?php echo $val['title']; ?>"><a href="<?php echo base_url(); ?>City/spa_center_detail/<?php echo $val['post_id']; ?>"><?php echo $val['title']; ?></a></h5>
<?php 
 
       $str = $val['description'];
        $string = strip_tags($str);
        if (strlen($string) > 94) { $stringCut = substr($string, 0, 94);$string = substr($stringCut, 0, strrpos($stringCut, ' '));}
        

?>
<p style="text-align: justify;"><?php echo $string; ?> <a href="<?php echo base_url(); ?>City/spa_center_detail/<?php echo $val['post_id']; ?>">..Read More</a></p>

<em>Location :-<span><?php echo  $val['city_name']; ?></span> | <?php echo $val['location']; ?></em>


</div>

</div>

<?php  } ?>


<!--Blog 3 Thumb End-->
<!--Blog 3 Thumb Start-->
<!--<div class="col-md-4 hidden-sm">
<div class="blog-thumb">
<figure>
<img src="extra-images/blog3-6.jpg" alt=""/>
</figure>
<div class="text">
<a href="#"><i class="fa fa-image"></i></a>
<h5><a href="#">Nemo enim ipsam voluptatem voluptas sit aspernatur</a></h5>
<p>Sed non  mauris vitae erat consequat auctor eu in elit. Class apten taciti soco litora torquent per   conubia nostra per inceptos himenaeos. </p>
<em>Posted on <span>25 Feb</span> ,2015</em>
</div>
</div>
</div>-->

<!--Blog 3 Thumb End-->
<!--pagination-->
<!--<div class="col-md-12">
<div class="kf-pagination">
<ul class="pagination">
<li class="active"><a href="#">1</a></li>
<li><a href="#">2</a></li>
<li><a href="#">3</a></li>
<li><a href="#">4</a></li>
<li><a href="#">5</a></li>
</ul>
</div>
pagination end
</div>-->

</div>



<!--Blog 3 Page Content End-->
</div>
</div>
</div>





</div>
</div>



</div>


</div>

<?php include('common/header2.php'); ?>
<script>
function showadv(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","getadvcity.php?country="+str,true);
        xmlhttp.send();
    }
}
</script>
<script>
function showarea(str) {
    if (str == "") {
        document.getElementById("txtarea").innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtarea").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","getadvarea.php?city="+str,true);
        xmlhttp.send();
    }
}
</script>  