<?php error_reporting(0);session_start(); ?>
 <?php
$session = $_SESSION['reg_id'];

if ( isset($session) ) { 
   echo '<script type="text/javascript">window.location=\'post-add.php\';</script>';
//  header('Location: post-add.php');  
}

 else {
    

?>

<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Post Your Add With Sam Spa Center</title>
<meta name="keywords" content="Body Massage, Body Wrap, Body-Scrub,Body Massage in Pune, Thai Oil Massage in Pune, Hot Stone Massage in Hyderabad, Hair Spa Services in Mumbai" />
<meta name="description" itemprop="description" content="Welcome to Pedicure and Manicure Center Sam Spa Center at Mumbai, India, Dubai, thailand, Best Spa service in Mumbai, Spa Center in Mumbai." />
<meta name="Author" content="Pedicure and Manicure , http://www.samspacenter.com"
<meta property="og:title" content="Pedicure and Manicure " />
<meta property="og:type" content="article" />
<meta property="og:url" content="http://www.samspacenter.com/pedicures-manicures.php" />
<meta property="og:image" content="http://www.example.com/image.png" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:site" content="samspacenter" />
<meta name="twitter:title" content="Pedicure and Manicure " />
<meta name="twitter:description" content="Welcome to Pedicure and Manicure Center Sam Spa Center at Mumbai, India, Dubai, thailand, Best Spa service in Mumbai, Spa Center in Mumbai." />

<?php include_once 'linksheet.php'; ?>

<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-89524380-1', 'auto');
ga('send', 'pageview');

</script>

</head>

<body onkeypress="return disableCtrlKeyCombination(event);" onkeydown = "return disableCtrlKeyCombination(event);" > 
<!--KF KODE WRAPPER WRAP START-->
<div class="kf_wrapper">

<!--HEADER START-->
<!--HEADER START-->
<header class="absolute">
<div class="container">
<?php include_once './logo.php';?>
<?php include_once './menu.php';?>
</div>
</header>
<!--HEADER END-->
<!--HEADER END-->

<!--Home Page Banner Start-->
<div class="kode-home-banner inner-banner">
<h6>Register Your Self & Post Add With Us</h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>Register and Login </h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="index.php">Home</a></li>
<li><a href="./pedicures-manicures.php">Register Your Self & Post Add With Us</a></li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->
 

<div class="kf_content_wrap">
<section>
<div class="container">
<div class="contact-form">
<div class="row">
    
    
<div class="col-md-6">
   
<div class="heading-2">
<h2><br>Register</h2>
<i class="border-style-1"></i>
</div>
    
<form action="register.php" method="post">
<div class="col-sm-10">
<div class="contact-input">
    <input type="text" required="required" name="username" class="form-control" placeholder="Enter Your Name">
</div>
</div>
    
 <div class="col-sm-10">
<div class="contact-input">
    <input type="text" data-validation="number" data-validation-error-msg="Please Enter corrrect mobile Number" name="contact_no" required="required" class="form-control" placeholder="Enter Your Mobile Number">
</div>
</div>   
    
 <div class="col-sm-10">
<div class="contact-input">
    <input type="email" data-validation="email" data-validation-error-msg="Please Enter corrrect email Id" name="email" required="required" class="form-control" placeholder="Enter Email Id...">
</div>
</div>  
    
 <div class="col-sm-10">
<div class="contact-input">
    <input type="password" name="userpsd" data-validation="length" data-validation-length="min5" class="form-control" data-validation-error-msg="Password Atleast 5 Char" placeholder="Enter Your Password">
</div>
</div>     
<button>Register </button>
</form>
</div>
    
 <div class="col-md-6">
   
<div class="heading-2">
<h2><br>Login & Post Add</h2>
<i class="border-style-1"></i>
</div>
    
<form action="login.php" method="post">

   
    
 <div class="col-sm-10">
<div class="contact-input">
    <input type="email" data-validation="email" data-validation-error-msg="Please Enter corrrect email Id" name="email" required="required" class="form-control" placeholder="Enter Email Id...">
</div>
</div>  
    
 <div class="col-sm-10">
<div class="contact-input">
    <input type="password" name="userpsd" data-validation="length" data-validation-length="min5" class="form-control" data-validation-error-msg="Password Atleast 5 Char" placeholder="Enter Your Password">
</div>
</div>
 
<div class="col-sm-10">
<?php

$num1=rand(1,10);

$num2=rand(1,10);

$num3=$num1+$num2;

?>
        <label style="font-size: 20px;">What is the sum of <?php echo $num1 ?> + <?php echo $num2 ?> ?</label>
<div class="contact-input">
    <input type="number" name="..." data-validation="spamcheck" data-validation-captcha="<?php echo $num3 ?>" data-validation-error-msg="Please Provide corrrect Answer" class="form-control">
</div>
</div>
    
    
<button>Login  </button>    
</div>   
    
</form>    
    
    
</div>
</div>
</div>
</section>
</div>


</div>
<!--Testimonail Wrap Start-->
<?php //include_once './testimonial.php';?>
<!--Testimonail Wrap End-->


<!--FOOTER START-->
<?php include_once './footer.php';?>
<!--FOOTER END-->


<!--KF KODE WRAPPER WRAP END-->
<!--Bootstrap core JavaScript-->
<?php include_once 'after_footer.php'; ?>


</body>


</html>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>


<script>
$.validate({
modules : 'location, date, security, file',
onModulesLoaded : function() {
$('#country').suggestCountry();
}
});
// Restrict presentation length
$('#presentation').restrictLength( $('#pres-max-length') );

</script>

 <?php } ?>