
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-89524380-1', 'auto');
ga('send', 'pageview');

</script>

<!--Home Page Banner Start-->
<div class="kode-home-banner inner-banner">
<h6>Edit Your Add</h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>Edit Your Add</h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a></li>
<li><a href="<?php echo base_url(); ?>register_login/edit_add">Edit Your Add</a></li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->


<div class="kf_content_wrap">
<section>
<div class="container">
<div class="contact-form">
<div class="row">
<!--<form action="edit-add-process.php" method="post" enctype="multipart/form-data">  -->
 <div class="heading-2">
<h2><br>Edit Your Add</h2>
<i class="border-style-1"></i>
</div>   
 
    <div class="col-md-2"></div>
    
<div class="col-md-8">
   
       
<div class="col-sm-10">
<div class="contact-input">
     <select name="title" id="title" class="form-control mb-10" onchange="showedit(this.value)" required>
<option value="">Select Title Of Add</option>
  <?php
/*   include_once 'connection.php';
  $sql_maincat = "SELECT * FROM adpost where reg_id='$session'";

$result_maincat = $connection->query($sql_maincat);

while ( $row_maincat = $result_maincat->fetch_assoc() ) { 
$title=$row_maincat['title'] ;
$reg_id=$row_maincat['reg_id'] ;
$id=$row_maincat['id'] ;
 */

?>

  <option value="<?php //echo $id;?>"><?php //echo $title;?></option>
<?php //}?>

</select>
</div>
</div>

    

        



  
    
</div>
    
   <div class="col-md-2"></div> 
    

</div>
</div>
</section>
</div>


  <div id="txtHint"></div>   
    
     
</div>

