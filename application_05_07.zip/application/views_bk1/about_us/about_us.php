<!--Home Page Banner Start-->
<div class="kode-home-banner inner-banner">
<h6>About Us</h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>About Us</h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a></li>
<li><a href="<?php echo base_url(); ?>about_us">About Us</a></li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->


<div class="kf_content_wrap">
<!--About Spa Wrap Strat-->
<section>
<div class="container">
<!--About Spa Strat-->
<div class="kf-about-spa">
<!--About Spa Thumb Strat-->
<div class="kf-thumb">
<img src="assets/newimg/about/about-spa.png" alt="best spa company in india" title="best spa company in india"/>
</div>
<!--About Spa Thumb End-->
<!--About Spa Text area Start-->
<div class="text-area">
<!--Heading 2 Start-->
<div class="heading-2">
<h1 class="border-style">About Our Spa</h1>
<i class="border-style-1"></i>
</div>
<!--Heading 2 End-->
<!--About Des Start-->
<div class="kf-abou-des">

<div class="text">

<p align="justify">Spa Company is one of the best and leading companies in India known for delivering the quality services. It gives the unique experience to the clients by our special treatment and massage therapies. Spa experts of our company have designed natural treatments where you will come across with different herbal and ancient techniques, which gives the best mode in the field of relaxation. Our Spa experts are trained and professionals who provide customized services according to the customers need. These experts are friendlier in nature and solve the problem of the clients in an effective way.<br><br>

By offering standardized services, our company has designed individual shower room where you can your own time in case of bathing and steaming. Even the outfits provided by us during spa treatments are disposable in nature which cannot be used again for further Spa treatment. We are best in maintaining the hygiene part where clients will not face any kind of problem in cleanliness part. We maintain the privacy part of the customers and will not disclose any kind of information without taking the clients permission.</p>
</div>
</div>

</div>
<!--About Spa Text area End-->
</div>
<!--About Spa End-->
</div>
</section>
<!--About Spa Wrap End-->

<!--Testimonail Wrap Start-->
<?php include_once './testimonial.php';?>
<!--Testimonail Wrap End-->
<!--Counter Wrap Start-->
<div class="kf-counterup counter-2">
<div class="container">
<!--Counter Wrap Start-->
<ul class="kf-counter">
<!--Counter Des Start-->
<li>
<span class="counter">6885</span>
<i class="icon-icon-34894"></i>
<h6>Satisfied Clients</h6>
</li>
<!--Counter Des End-->
<!--Counter Des Start-->
<li>
<span class="counter">512</span>
<i class="icon-icon-36285"></i>
<h6>Completed projects</h6>
</li>
<!--Counter Des End-->
<!--Counter Des Start-->
<li>
<span class="counter">1769</span>
<i class="icon-icon-88529"></i>
<h6>Likes on Average</h6>
</li>
<!--Counter Des End-->
<!--Counter Des Start-->
<li>
<span class="counter">154</span>
<i class="icon-people"></i>
<h6>We Launched</h6>
</li>
<!--Counter Des End-->
</ul>
<!--Counter Wrap End-->
</div>
</div>
<!--Counter Wrap End-->




</div>
