		<!--Home Page Banner Start-->
		<div class="kode-home-banner inner-banner">
			<h6>Foot Massage</h6>
            <i class="border-style-1"></i>
		</div>
        <div class="kf-banner-bar">
            <div class="container">
                <div class="pull-left">
                    <h6>Foot Massage</h6>
                </div>
                <div class="pull-right">
                    <ul class="breadcrumb">
                        <li><a href="<?php echo base_url(); ?>">Home</a></li>
						<li><a href="<?php echo base_url(); ?>Services/Foot_massage">Foot Massage</a></li>
                      
                    </ul>
                </div>
            </div>
        </div>
		<!--Home Page Banner End-->


		<div class="kf_content_wrap">
            <!--About Spa Wrap Strat-->
            <section>
                <div class="container">
                    <!--About Spa Strat-->
                    <div class="kf-about-spa">
                        
                        <div class="text-area" style="width:100%">
                            <!--Heading 2 Start-->
                            <div class="heading-2">
                                <h2 class="border-style">Foot Massage</h2>
                                <i class="border-style-1"></i>
                            </div>
                            <!--Heading 2 End-->
                            <!--About Des Start-->
                            <div class="kf-abou-des">
                                
                                <div class="text">
                                     
                                   <p align="justify">It helps to relive the pain from the foot where experts are using special oil and lotion over foot. These experts will make you relief by technique of acupressure where your foot points are massaged in a special way.</p><br>
                                      
                                </div>
                                <div class="kf-gallery-wrap">
                            <!--Gallery Thumb Start-->
                           
						   <div class="kf-gallery-wrap">
                            <!--Gallery Thumb Start-->
                            <div class="kf-gallery-thumb col-md-3">
                                <figure>
                                    <img src="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-1.jpg" alt="">
                                    <figcaption><a data-rel="prettyPhoto[]" href="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-1.jpg"><i class="fa fa-search-plus"></i></a></figcaption>
                                </figure>
                            </div>
                            <!--Gallery Thumb End-->
                            <!--Gallery Thumb Start-->
                            <div class="kf-gallery-thumb col-md-3">
                                <figure>
                                    <img src="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-2.jpg" alt="">
                                    <figcaption><a data-rel="prettyPhoto[]" href="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-1.jpg"><i class="fa fa-search-plus"></i></a></figcaption>
                                </figure>
                            </div>
                            <!--Gallery Thumb End-->
                            <!--Gallery Thumb Start-->
                            <div class="kf-gallery-thumb col-md-3">
                                <figure>
                                    <img src="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-3.jpg" alt="">
                                    <figcaption><a data-rel="prettyPhoto[]" href="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-3.jpg"><i class="fa fa-search-plus"></i></a></figcaption>
                                </figure>
                            </div>
                            <!--Gallery Thumb End-->
                            <!--Gallery Thumb Start-->
                            <div class="kf-gallery-thumb col-md-3">
                                <figure>
                                    <img src="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-4.jpg" alt="">
                                    <figcaption><a data-rel="prettyPhoto[]" href="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-3.jpg"><i class="fa fa-search-plus"></i></a></figcaption>
                                </figure>
                            </div>
                              
                        </div>
						  
                             
                        </div>
                            </div>
                            
                        </div>
                        
                        
                        <!--About Spa Text area End-->
                    </div>
                    <!--About Spa End-->
                </div>
            </section>
             
            <!--About Spa Wrap End-->
    
             <!--Testimonail Wrap Start-->
          <?php require_once(APPPATH."views/testimonial/testimonial.php"); ?>
