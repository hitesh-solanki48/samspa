<!--HEADER END-->

<!--Home Page Banner Start-->
<div class="kode-home-banner inner-banner">
<h6>Services</h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>Services</h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a>
</li>
<li><a href="<?php echo base_url(); ?>Services">Services</a>
</li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->


<div class="kf_content_wrap">
<!--About Spa Wrap Strat-->
<section>
<div class="container">
<!--About Spa Strat-->
<div class="row" style="margin-left: 20px;margin-right: 20px;">

<div class="text-area" style="width:100%">
<!--Heading 2 Start-->
<div class="heading-2">
<h1 class="border-style" style="text-align: center;">Our Services</h1>

</div>
<!--Heading 2 End-->
<!--About Des Start-->
<div class="kf-abou-des">

<div class="text">

<img src="<?php echo base_url(); ?>assets/newimg/service/masonary-5.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;" alt="Best Spa Services in Mumbai">
<p align="justify">The term SPA means Sanitas per Aquam which is related with water treatments. In SPA treatment the body of the person is treated with mineral water which is inbounded with special power. Different kind of cost effective services are offered by the company in order to meet the client’s satisfaction. Our experts have designed reasonable packages which can easily meet the demands of low income group people.</p>
<br>
<h3>Some of the Spa packages includes:-</h3>

<ul type="disc" style="width:100%">

<li style="list-style: disc;margin-left: 15px;"> Massage therapy along with herbal facial </li>
<li style="list-style: disc;margin-left: 15px;"> Thai massage along with organic facial</li>
<li style="list-style: disc;margin-left: 15px;"> Body scrub along with body wrap</li>
<li style="list-style: disc;margin-left: 15px;"> Massage of deep tissues along butter moisturizing wrap</li>
<li style="list-style: disc;margin-left: 15px;"> Manicure and Pedicure spa</li>
<li style="list-style: disc;margin-left: 15px;"> Swedish massage and coco butter body wrap</li>


</ul>
<br>

<h4> What does our expert do for your body?</h4>

<img src="<?php echo base_url(); ?>assets/newimg/service/masonary-6.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:right; margin-left: 25px; " alt="Spa Packages in Mumbai">
<p align="justify">For Body scrub, our experts are using moisturizer of coco butter along with whitening scrub which will give you positive result by removing the dead skin along with improving glow. With our honey cleaner we will able to massage your face in the best manner which can easily reach to the deep layer of your skin and gives the positive result by removing the dead cells. Our company is having reasonable body wrap which can be taken by the clients according to budget.
<br>
<br> Apart from that they are also engaged in manicure and pedicure facility which makes their hands and legs clean for some time. Facility of nail art is also provided where different nail art is taken by our customers at fewer prices. Facility of massage is also provided where the clients will come across with Jacuzzi spa which is a kind of hot tub placed anywhere to give the spa treatment automatically. It results in making the body and mind of the customers free from stress and tension. Apart from Jacuzzi other massage includes Thai massage along with western, body head and legs massage. Our company provides the facility of makeup which will make you unique and superb for event.
<br>
<br> Experts will take better care of your face by doing quality facial in the better way using different strokes. By doing facial for the long time, tanning from the face can be easily removed. Our experts are best in providing waxing and other service which makes your skin glow. Experts will be doing the treatment according to the skin. They know which and how face treatment can be provided with give best result in short span of time.</p>
<br>
<hr>
</div>

<h1 class="text" align="center">Services</h1><br>
<div class="text">

<h4><img src="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-3.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;max-width: 25%;" alt="Spa in Mumbai">Spa package :</h4>We have designed different Spa packages according to the needs and requirement of the clients. They may also select the best one according to their need. Our spa packages will include.

<ul type="disc" style="width:100%">

<li style="list-style: disc;margin-left: 15px;">Body treatments with latest techniques</li>
<li style="list-style: disc;margin-left: 15px;">Body treatment with ancient techniques</li>
<li style="list-style: disc;margin-left: 15px;">Skin care treatment</li>
<li style="list-style: disc;margin-left: 15px;">Body care treatment</li>

</ul><br>
<h5>Packages offered by us are cost effective in nature</h5>
</div><hr>
<br>

<div class="text">
<h4>Body wrap and Body Scrub :
</h4><img src="<?php echo base_url(); ?>assets/newimg/service/scrub1.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;max-width: 25%;" alt="Body Spa"><img src="./extra-images/scrub.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:right; margin-left: 25px;max-width: 40%;" alt="Spa Services in Mumbai">We offer different kinds of Body Scrub and wrap treatment where our experts will impart best body treatment by scrubbing the whole body with herbal cream. Then after body is wrapped in order to give you best part of warm hydration along with detoxification. It will provide relaxation and refreshment mode.
</div><hr>

<div class="text">
<h4>Hair services :</h4>
<img src="<?php echo base_url(); ?>assets/newimg/service/hair.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;max-width: 25%;" alt="Hair services">
<img src="<?php echo base_url(); ?>assets/newimg/service/hair-treatments.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:right; margin-left: 25px;max-width: 35%;">Our hair experts will help you to come across with hair coloring services by using eco-friendly and natural products. They help in cutting and styling of you hairs along with applying you the best shampoo for hair growth and shinning.
<hr> </div>

<div class="text">
<h4> Pedicures and manicures :</h4><img src="<?php echo base_url(); ?>assets/newimg/service/Manicure-and-Pedicure.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;max-width:30%; " alt="Pedicures and manicures">
This facility is provided by our experts where you will get the best and unique solution of your hand and legs. Treatment is carried out in the better way by providing customized services according to the need of the customers.
<hr> 
</div>



<div class="text">
<h4>Massage</h4><img src="<?php echo base_url(); ?>assets/newimg/service/massage.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:right; margin-left: 25px; max-width:30%;" alt="Hot Stone Massage">
Different kinds of massage facility is provided by our experts where you will come across with Thai oil massage, foot massage, arms massage, legs massage and hot stone massage. Rates offered by us are affordable in nature.
<hr> 
</div>


<div class="text">
<h4>Makeup </h4><img src="<?php echo base_url(); ?>assets/newimg/service/makeup.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;max-width:25%; " alt="Makeup Services">
This facility is also provided by our experts where they will be doing the makeup according to your face colour. They make you unique and different in the crowd, when going for some special event.
<hr> 
</div>

<div class="text">
<h4>Skin care treatment</h4><img src="<?php echo base_url(); ?>assets/newimg/service/skin.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:right; margin-left: 25px; max-width:30%;" alt="Skin care treatment">
We are best to provide skin care treatment where we care for your skin in the better way by doing herbal facials and scrub which maintains the glow on the skin. We offer different kinds of packages in skin care.
</div>


</div>

</div>


<!--About Spa Text area End-->
</div>
<!--About Spa End-->
</div>
</section>

<!--About Spa Wrap End-->

<!--Testimonail Wrap Start-->
<?php require_once(APPPATH."views/testimonial/testimonial.php"); ?>
<!--Testimonail Wrap End-->

</div>
