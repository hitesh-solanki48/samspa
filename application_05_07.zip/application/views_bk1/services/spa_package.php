<!--Home Page Banner Start-->
<div class="kode-home-banner inner-banner">
<h6>Spa package </h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>Spa package </h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a></li>
<li><a href="<?php echo base_url(); ?>Services/spa_package">Spa package </a></li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->


<div class="kf_content_wrap">
<!--About Spa Wrap Strat-->
<section>
<div class="container">
<!--About Spa Strat-->
<div class="row" style="margin-left: 20px;margin-right: 20px;">

<div class="text-area" style="width:100%">
<!--Heading 2 Start-->

<!--About Des Start-->
<div class="kf-abou-des">


<h1 class="text" align="center">Spa package</h1><br>
<div class="text">

<h4><img src="<?php echo base_url(); ?>assets/newimg/service/gallery-thumb-3.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;max-width: 25%;" alt="Spa in Mumbai"></h4>We have designed different Spa packages according to the needs and requirement of the clients. They may also select the best one according to their need. Our spa packages will include.

<ul type="disc" style="width:100%">

<li style="list-style: disc;margin-left: 25px;">Body treatments with latest techniques</li>
<li style="list-style: disc;margin-left: 25px;">Body treatment with ancient techniques</li>
<li style="list-style: disc;margin-left: 25px;">Skin care treatment</li>
<li style="list-style: disc;margin-left: 25px;">Body care treatment</li>

</ul><br>
<h5>Packages offered by us are cost effective in nature</h5>
</div><hr>
<br>

</div>

</div>


<!--About Spa Text area End-->
</div>
<!--About Spa End-->
</div>
</section>

<!--About Spa Wrap End-->

<!--Testimonail Wrap Start-->
<?php require_once(APPPATH."views/testimonial/testimonial.php"); ?>
