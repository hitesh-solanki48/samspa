<!--Home Page Banner Start-->
<div class="kode-home-banner inner-banner">
<h6>Body wrap and Body Scrub </h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>Body wrap and Body Scrub</h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
 <li><a href="<?php echo base_url(); ?>">Home</a></li>
<li><a href="<?php echo base_url(); ?>Services/body_wrap_and_body_scrub">Body wrap and Body Scrub</a></li>

</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->


<div class="kf_content_wrap">
<!--About Spa Wrap Strat-->
<section>
<div class="container">
<!--About Spa Strat-->
<div class="row" style="margin-left: 20px;margin-right: 20px;margin-top: 20px;margin-bottom: 40px;">
    <h1 class="text" align="center">Body wrap and Body Scrub</h1><br>
    <div class="col-md-4">
        <div class="blog-thumb">
      <img src="<?php echo base_url(); ?>assets/newimg/service/scrub1.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;max-width: 100%;" alt="Body Spa">
    </div>    </div>
     <div class="col-md-4">
        <p style="text-align: justify;margin-top: 10px;">
            <br>
    We offer different kinds of Body Scrub and wrap treatment where our experts will impart best body treatment by scrubbing the whole body with herbal cream. Then after body is wrapped in order to give you best part of warm hydration along with detoxification. It will provide relaxation and refreshment mode.</p>
    </div>
     <div class="col-md-4">
          <div class="blog-thumb">
       <img src="<?php echo base_url(); ?>assets/newimg/service/scrub1.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:right; margin-left: 25px;max-width: 100%;" alt="Spa Services in Mumbai">
    </div></div>
    
        



<!--About Spa Text area End-->
</div>
<!--About Spa End-->
</div>
</section>

<!--About Spa Wrap End-->

<!--Testimonail Wrap Start-->
 <?php require_once(APPPATH."views/testimonial/testimonial.php"); ?>
