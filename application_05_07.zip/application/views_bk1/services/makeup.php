<!--Home Page Banner Start-->
<div class="kode-home-banner inner-banner">
<h6>Makeup</h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>Makeup</h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a></li>
<li><a href="<?php echo base_url(); ?>Services/makeup">Makeup</a></li>

</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->


<div class="kf_content_wrap">
<!--About Spa Wrap Strat-->
<section>
<div class="container">
<!--About Spa Strat-->
<div class="row" style="margin-left: 20px;margin-right: 20px;margin-top: 20px;margin-bottom: 40px;">
<h1 class="text" align="center">Makeup</h1><br>
    <div class="col-md-4">
        <div class="blog-thumb">
<img src="<?php echo base_url(); ?>assets/newimg/service/makeup.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;max-width: 85%;" alt="Spa in Mumbai">
    </div>    </div>
    
    <div class="col-md-8">
        <p style="text-align: justify;margin-top: 20px;">
            <br>
      This facility is also provided by our experts where they will be doing the makeup according to your face colour. They make you unique and different in the crowd, when going for some special event.
        </p>
    </div>
    
    
</div>
</div>
</section>   
</div>


<?php require_once(APPPATH."views/testimonial/testimonial.php"); ?>
