<!--Home Page Banner Start-->
<div class="kode-home-banner inner-banner">
<h6>Hair services </h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>Hair services </h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a></li>
<li><a href="<?php echo base_url(); ?>Services/hair_services">Hair services</a></li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->


<div class="kf_content_wrap">
<!--About Spa Wrap Strat-->
<section>
<div class="container">
<!--About Spa Strat-->
<div class="row" style="margin-left: 20px;margin-right: 20px;margin-top: 20px;margin-bottom: 40px;">
<h1 class="text" align="center">Hair services</h1><br>
 <div class="col-md-4">
        <div class="blog-thumb">
      <img src="<?php echo base_url(); ?>assets/newimg/service/hair.jpg" style="box-shadow: 0 0 4px 1px rgba(121, 85, 72, 0.82);border: 3px groove #FF5722;float:left; margin-right: 25px;max-width: 85%;" alt="Spa in Mumbai">
    </div>    </div> 

<div class="col-md-8">
        <p style="text-align: justify;margin-top: 10px;">
            <br>
 Our hair experts will help you to come across with hair coloring services by using eco-friendly and natural products. They help in cutting and styling of you hairs along with applying you the best shampoo for hair growth and shinning.
        </p>
    </div>
    
</div>
</div>
</section>
</div>
    


<!--About Spa Wrap End-->

<!--Testimonail Wrap Start-->
<?php require_once(APPPATH."views/testimonial/testimonial.php"); ?>
