<?php include('common/header.php');?>
<section class="background-white  text-center">
    <div class="container">
  <div class="fg">

  <form class="zform mt-3" _lpchecked="1">
  <div class="row">
  <div class=" col-lg-4"> 
    <input class="form-control background-white" type="text" placeholder="City Search" required>
  </div>


  <div class=" col-lg-3"> 
 <select class="form-control background-white" >
  <option>Services</option>
  </select></div>
  
  <div class=" col-lg-3"> 
  <select class="form-control background-white">
  <option>Area</option>
  </select>
   
  </div>
  
   <div class=" col-lg-2"> 
  <button class="btn btn-md-lg btn-primary" type="Go"> <span class="color-white fw-600">GO</span></button></div>

  </div>
  </form>
 </div>
 </div>
  </section>


  





    <section class="background-11  text-center">
    <div class="container">
          <div class="row mb-6">
        <div class="col">
              <h3 class="fs-2 fs-md-3"> Premium Listing</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
      <div class="row">


        <div class="col-lg-3  mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/Premium-1.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Swedish Massage Therapy</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>



        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/Premium-2.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Aromatherapy Massage.</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>        
        
        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/Premium-3.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Hot Stone Massage</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/Premium-4.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Deep Tissue Massage</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


      </div>


      <div class="row">


        <div class="col-lg-3  mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/Premium-5.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Shiatsu Massage</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>



        <div class="col-lg-3  mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/Premium-6.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Thai Massage</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>        
        
        <div class="col-lg-3  mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/Premium-7.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Pregnancy Massage</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


        <div class="col-lg-3  mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/Premium-8.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Reflexology</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


      </div>
    </div>
 
    </section>








   <section class="background-white  text-center">
    <div class="container">
          <div class="row mb-6">
        <div class="col">
              <h3 class="fs-2 fs-md-3">Services</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
    <div data-dots="true" data-nav="true" data-items='{"0":{"items":2},"600":{"items":2}}' data-autoplay="true" data-margin="30" data-loop="true" class="owl-carousel owl-theme owl-nav-outer  owl-dot-round">
          <div class="item"><img src="assets/images/services-1.jpg" class="radius-primary"/></div>
          <div class="item"><img src="assets/images/services-2.jpg" class="radius-primary"/></div>
          <div class="item"><img src="assets/images/services-3.jpg" class="radius-primary"/></div>
          <div class="item"><img src="assets/images/services-4.jpg" class="radius-primary"/></div>
          <div class="item"><img src="assets/images/services-5.jpg" class="radius-primary"/></div>
          <div class="item"><img src="assets/images/services-6.jpg" class="radius-primary"/></div>
          <div class="item"><img src="assets/images/services-4.jpg" class="radius-primary"/></div>
          <div class="item"><img src="assets/images/services-5.jpg" class="radius-primary"/></div>
          <div class="item"><img src="assets/images/services-6.jpg" class="radius-primary"/></div>
        </div>
  </div>
  </section>





  

        <section class="background-11  text-center">
    <div class="container">
          <div class="row mb-6">
        <div class="col">
              <h3 class="fs-2 fs-md-3"> Free Listing</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
      <div class="row">


        <div class="col-lg-3  mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-1.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Swedish Massage Therapy</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>



        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-3.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Aromatherapy Massage.</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>        
        
        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-4.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Hot Stone Massage</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-5.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Deep Tissue Massage</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


      </div>


      
    </div>
 
    </section>








     <section class="background-white  text-center">
    <div class="container">
          <div class="row mb-6">
        <div class="col">
              <h3 class="fs-2 fs-md-3">New SPA Reviews</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
      <div class="row">


        <div class="col-lg-3  mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-1.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Body And Beauty</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>



        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-3.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Body And Beauty</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>        
        
        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-4.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Body And Beauty</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-5.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Body And Beauty</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


      </div>


      
    </div>
 
    </section>





    <section class="background-11  text-center">
    <div class="container">
          <div class="row mb-6">
        <div class="col">
              <h3 class="fs-2 fs-md-3">Latest News</h3>
              <hr class="short" data-zanim="{&quot;from&quot;:{&quot;opacity&quot;:0,&quot;width&quot;:0},&quot;to&quot;:{&quot;opacity&quot;:1,&quot;width&quot;:&quot;4.20873rem&quot;},&quot;duration&quot;:0.8}" style="width: 4.20873rem; opacity: 1;">
            </div>
      </div>
          <div class="row">


        <div class="col-lg-3  mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-1.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Body And Beauty</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>



        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-3.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Body And Beauty</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>        
        
        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-4.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Body And Beauty</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


        <div class="col-lg-3 mb-3 mt-3">
    	<div class="cuadro_intro_hover ">
		<p style="text-align:center;">
		<img src="assets/images/portrait-5.jpg" class="img-responsive" alt="">
		</p>
		<div class="caption">
		<div class="blur"></div>
		<div class="caption-text">
		<h3>Body And Beauty</h3>
		<p><b>You will enjoy different kinds.</b> </p>
        <p class="bgp">You will enjoy different kinds of body treatment and skin care treatments through facial and massage. Packages offered.</p>
		</div>
		</div>
		</div>
		</div>


      </div>
   </div>

  </section>

<?php include('common/footer.php');?>
     