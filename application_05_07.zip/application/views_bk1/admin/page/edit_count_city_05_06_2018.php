<?php $this->load->view('admin/partials/admin_header.php'); ?>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Edit Country/State</h3>
            </div>
        </div>
       

		<div class="row">
            <div class="col-md-8 col-md-offset-2">
            
            <?php echo validation_errors(); ?> 
			<?php //echo '<pre>'; print_r($userRow); die; ?> 
			<?php echo form_open_multipart('admin/Page/edit_count_city/'.$userRow[0]['city_country_id']); ?>
                <fieldset>
					<div class="row">
						<div class="col-xs-4">
                            <label>Country Name</label> 
							<input type="hidden" name="city_country_id" value="<?php echo $userRow[0]['city_country_id']; ?>">	
                            <select name="country_id" id="country_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($countList as $val){  ?>
								<option value="<?php echo $val['country_id']; ?>" <?php if($val['country_id'] == $userRow[0]['country_id']) { echo 'selected'; } ?>><?php echo $val['country_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
						<div class="col-xs-4">
                            <label>State Name</label>                            
                            <select name="state_id" id="state_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($stateList as $val){  ?>
								<option value="<?php echo $val['state_id']; ?>" <?php if($val['state_id'] == $userRow[0]['state_id']) { echo 'selected'; } ?>><?php echo $val['state_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
						<div class="col-xs-4">
                            <label>City Name</label>                            
                            <select name="city_id" id="city_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($cityList as $val){  ?>
								<option value="<?php echo $val['city_id']; ?>" <?php if($val['city_id'] == $userRow[0]['city_id']) { echo 'selected'; } ?>><?php echo $val['city_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
					</div>
					<div class="row">
					
                        <div class="col-xs-4">
						 <br>
                            <label>Title</label>                            
                            <input type="text" class="form-control" name="title" value="<?php echo $userRow[0]['title']; ?>">    
                        </div>
                       
                        <div class="col-xs-4">
                        <br>
                            <label for="mileage">Image:</label>
                            <input type="file" class="form-control" name="image" required>
                        </div>
						
						<div class="col-xs-4">
                            <br>
                            <label for="gear">Status:</label>
                            <select name="status" id="status" class="form-control">
                                <option value="1" <?php if($userRow[0]['status'] == 1){ echo 'selected'; } ?>>Active</option>
                                <option value="0" <?php if($userRow[0]['status'] == 0){ echo 'selected'; } ?>>In Active</option>
                            </select>
                        </div>
                    </div>
                    <br>
					<?php if($userRow[0]['image'] != ''){ ?> 
						<div class="row">
							<img src=" <?php echo base_url().'assets/images/country/'. $userRow[0]['image']?>" width="100px" height="100px" />
						</div>
					<?php } ?>
                    
					
                    <br>
                    <input class="btn btn-primary" type="submit" name="buttonSubmit" value="Add Country" />
                                                            
                </fieldset>         
            </form>
            <br>
           
        </div> <!-- /row --> 

        	
        <!-- all models --> 
        

    </div>
</div> <!-- /.col-right --> 
<!-- /page content -->

<?php $this->load->view('admin/partials/admin_footer.php'); ?>



<?php if($this->session->flashdata('message') != NULL) : ?>
    <script>
        swal({
          title: "Success",
          text: "<?php echo $this->session->flashdata('message'); ?>",
          type: "success",
          timer: 1500,
          showConfirmButton: false
        });
    </script>
<?php endif ?>
<!--
    <script src="<?php echo base_url("assets/vendors/datatables.net/js/jquery.dataTables.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/buttons.flash.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/buttons.html5.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-buttons/js/buttons.print.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/datatables.net-scroller/js/datatables.scroller.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/jszip/dist/jszip.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/pdfmake/build/pdfmake.min.js"); ?>"></script>
    <script src="<?php echo base_url("assets/vendors/pdfmake/build/vfs_fonts.js"); ?>"></script>
    
    -->

<?php if($this->session->flashdata('message') != NULL) : ?>
<script>
    swal({
      title: "Success",
      text: "<?php echo $this->session->flashdata('message'); ?>",
      type: "success",
      timer: 1500,
      showConfirmButton: false
    });
</script>
<?php endif ?>