<?php $this->load->view('admin/partials/admin_header.php'); ?>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Edit Post</h3>
            </div>
        </div>
       

		<div class="row">
            <div class="col-md-8 col-md-offset-2">
            
            <?php echo validation_errors(); ?> 
			<?php //echo '<pre>'; print_r($userRow); die; ?> 
			<?php echo form_open_multipart('admin/Page/edit_add_data/'.$userRow[0]['post_id']); ?>
                <fieldset>
				<div class="row">
						<div class="col-xs-4">
						 <br>
                            <label>City/Country</label>                            
                            <select name="city_country_id" id="city_country_id" class="form-control">
								<option value="0">--Select--</option>
                                <?php foreach($countCity as $val){  ?>
								<option value="<?php echo $val['city_country_id']; ?>" <?php if($val['city_country_id'] == $userRow[0]['city_country_id']) { echo 'selected'; } ?>><?php echo $val['title']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
						<div class="col-xs-4">
						 <br>
                            <label>Title</label>                            
                            <input type="text" class="form-control" name="title" value="<?php echo $userRow[0]['title']; ?>">    
                        </div>
                       
                        <div class="col-xs-4">
                        <br>
                            <label for="mileage">Image:</label>
                            <input type="file" class="form-control" name="image">
							<input type="hidden" name="image_hidd" value="<?php echo $userRow[0]['image']; ?>">    
                        </div>
						
					</div>
					<div class="row">
					
                        <div class="col-xs-4">
						 <br>
                            <label>Contact Person</label>                            
                            <input type="text" class="form-control" name="contact_person" value="<?php echo $userRow[0]['contact_person']; ?>">    
                        </div>
                       
                        <div class="col-xs-4">
                        <br>
                            <label for="mileage">Phone:</label>
                            <input type="text" class="form-control" value="<?php echo $userRow[0]['cont_number']; ?>" name="cont_number" required>
                        </div>
						<div class="col-xs-4">
                            <br>
                            <label for="gear">Status:</label>
                            <select name="status" id="status" class="form-control">
                                <option value="1" <?php if($userRow[0]['status'] == 1){ echo 'selected'; } ?>>Active</option>
                                <option value="0" <?php if($userRow[0]['status'] == 0){ echo 'selected'; } ?>>In Active</option>
                            </select>
                        </div>
                    </div>
					<div class="row">
					
                        <div class="col-xs-4">
						 <br>
                            <label>Email</label>                            
                            <input type="text" class="form-control" name="email" value="<?php echo $userRow[0]['email']; ?>">    
                        </div>
                       
                        <div class="col-xs-4">
                        <br>
                            <label for="mileage">Map Link:</label>
                            <input type="text" class="form-control" value="<?php echo $userRow[0]['map_link']; ?>" name="map_link">
                        </div>
						<div class="col-xs-4">
                        <br>
                            <label for="mileage">Location:</label>
                            <input type="text" class="form-control" value="<?php echo $userRow[0]['location']; ?>" placeholder="west mumbai" name="location" required>
                        </div>
                    </div>
					<div class="row">
						<div class="col-xs-4">
						 <br>
                            <label>Com. Address</label>                            
                            <input type="text" class="form-control" name="address" value="<?php echo $userRow[0]['address']; ?>">    
                        </div>
                       
                        <div class="col-xs-4">
						 <br>
                            <label>Alt Tag Image</label>                            
                            <input type="text" class="form-control" name="alt_tag" value="<?php echo $userRow[0]['alt_tag']; ?>">    
                        </div>
                       
                        
                    </div>
                    <br>
					<?php if($userRow[0]['image'] != ''){ ?> 
						<div class="row">
							<img src=" <?php echo base_url().'assets/images/add_data/'. $userRow[0]['image']?>" width="100px" height="100px" />
						</div>
					<?php } ?>
					<br>
                    <div class="row">
					
                       <div class="col-xs-12">
						 <br>
                            <label>Description</label>                            
                            <textarea class="form-control" name="description"><?php echo $userRow[0]['description']; ?></textarea>    
                        </div>
                        
                    </div>
					<div class="row">
					
                        <div class="col-xs-4">
						 <br>
                            <label>Page Title</label>                            
                            <input type="text" class="form-control" name="page_title" value="<?php echo $userRow[0]['page_title']; ?>">    
                        </div>
						<div class="col-xs-4">
						 <br>
                            <label>Meta Title</label>                            
                            <input type="text" class="form-control" name="meta_title" value="<?php echo $userRow[0]['meta_title']; ?>">    
                        </div>
						<div class="col-xs-4">
						 <br>
                            <label>Meta type</label>                            
                            <select name="type" id="type" class="form-control">
                                <option value="0" >--select--</option>
								<option value="1" <?php if($userRow[0]['type'] == 1){ echo 'selected'; } ?>>city</option>
                                <option value="2" <?php if($userRow[0]['type'] == 2){ echo 'selected'; } ?>>country</option>
								<option value="3" <?php if($userRow[0]['type'] == 3){ echo 'selected'; } ?>>state</option>
                            </select>    
                        </div>
                       
						
                    </div>
					<?php //echo '<pre>'; print_r($metaDesc); ?>
					<div class="row appRow">
					<?php $i = 1; if(!empty($metaDesc)) { foreach($metaDesc as $val){ ?>
						<div class='element' id='div_<?php echo $i; ?>'>
							<div class="col-xs-4">
							<input type="hidden" value="<?php echo $val['meta_id']; ?>" name="meta_id[]">
							<br>
								<label for="mileage">Meta Name:</label>
								<input type="text" value="<?php echo $val['meta_name']; ?>" class="form-control" name="meta_name[]">
							</div>
							<div class="col-xs-6">
							<br>
								<label for="mileage">Meta Description:</label>
								<input type="text" class="form-control" value="<?php echo $val['meta_description']; ?>" name="meta_description[]">
							</div>
							<div class="col-xs-2">
							<br>
								<label for="mileage">Button:</label>
								<span class='add form-control'>+</span>
							</div>
						</div>
					<?php $i++; } } else { ?>
						<div class='element' id='div_1'>
							<div class="col-xs-4">
							<br>
								<label for="mileage">Meta Name:</label>
								<input type="text" class="form-control" name="meta_name[]">
							</div>
							<div class="col-xs-6">
							<br>
								<label for="mileage">Meta Description:</label>
								<input type="text" class="form-control" name="meta_description[]">
							</div>
							<div class="col-xs-2">
							<br>
								<label for="mileage">Button:</label>
								<span class='add form-control'>+</span>
							</div>
						</div>
					<?php } ?>
                    </div>
                    <br>
                    <input class="btn btn-primary" type="submit" name="buttonSubmit" value="Add Country" />
                                                            
                </fieldset>         
            </form>
            <br>
           
        </div> <!-- /row --> 

        	
        <!-- all models --> 
        

    </div>
</div> <!-- /.col-right --> 
<!-- /page content -->

<?php $this->load->view('admin/partials/admin_footer.php'); ?>



<?php if($this->session->flashdata('message') != NULL) : ?>
    <script>
        swal({
          title: "Success",
          text: "<?php echo $this->session->flashdata('message'); ?>",
          type: "success",
          timer: 1500,
          showConfirmButton: false
        });
    </script>
<?php endif ?>

<script>

$(document).ready(function(){
	$(".add").click(function(){
	var total_element = $(".element").length;
	var lastid = $(".element:last").attr("id");
	var split_id = lastid.split("_");
	var nextindex = Number(split_id[1]) + 1;

	var max = 5;
  
	if(total_element < max ){
   
		$(".element:last").after("<div class='element' id='div_"+ nextindex +"'></div>");
 
		//html ='<div class="row" id="main_div_'+nextindex+'">';
		html ='	<div class="col-xs-4">';
		html +='	<input type="hidden" value="" name="meta_id[]">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Name:</label>';
		html +='		<input type="text" class="form-control" name="meta_name[]">';
		html +='	</div>';
		html +='	<div class="col-xs-6">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Description:</label>';
		html +='		<input type="text" class="form-control" name="meta_description[]">';
		html +='	</div>';
		html +='	<div class="col-xs-2">';
		html +='	<br>';
		html +='		<label for="mileage">Button:</label>';
		html +='		<span id="remove_' + nextindex + '" class="remove form-control">X</span>';
		html +='	</div>';
		//html +='</div>';
		$("#div_" + nextindex).append(html);
  }
 
 });
	
});

$('.appRow').on('click','.remove',function(){
 
  var id = this.id;
  var split_id = id.split("_");
  var deleteindex = split_id[1];

  // Remove <div> with id
  $("#div_" + deleteindex).remove();

 }); 
	function appendDiv(){
		/* var b = "<?php echo $b; ?>";
		b++;
		html ='<div class="row" id="main_div_'+b+'">';
		html +='	<div class="col-xs-4">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Name:</label>';
		html +='		<input type="text" class="form-control" name="meta_name[]">';
		html +='	</div>';
		html +='	<div class="col-xs-6">';
		html +='	<br>';
		html +='		<label for="mileage">Meta Description:</label>';
		html +='		<input type="text" class="form-control" name="meta_description">';
		html +='	</div>';
		html +='	<div class="col-xs-2">';
		html +='	<br>';
		html +='		<label for="mileage">Button:</label>';
		html +='		<button id="remove_button_'+b+'" class="form-control" onclick="removeDiv();" name="remove_button" >Add</button>';
		html +='	</div>';
		html +='</div>'; */
		
	}
</script>
<?php if($this->session->flashdata('message') != NULL) : ?>
<script>
    swal({
      title: "Success",
      text: "<?php echo $this->session->flashdata('message'); ?>",
      type: "success",
      timer: 1500,
      showConfirmButton: false
    });
</script>
<?php endif ?>