<!--Home Page Banner Start-->

<div class="kode-home-banner inner-banner">
<h6>Our Blog</h6>
<i class="border-style-1"></i>
</div>



<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>Blog</h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a></li>
<li><a href="<?php echo base_url(); ?>blog">Blog</a></li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->


<div class="kf_content_wrap">
<section>
<div class="container">
<div class="row">
<!--Blog 3 Page Content Start-->
<div class="blog-3-page">
<!--Blog 3 Thumb Start-->
<div class="col-md-8">
<?php

//$page= (isset($_GET['page']) && $_GET['page']>0)?(int)$_GET['page']:1;
//$perpage = 20;
//$limit = ($page>1)?($page * $perpage) - $perpage : 0;
//$sql_cat="SELECT SQL_CALC_FOUND_ROWS * FROM blog LIMIT {$limit},{$perpage}";
//
//
//$result_cat=$connection->query($sql_cat);
//
//$total=$connection->query("Select FOUND_ROWS() as total");
//$total=$total->fetch_assoc()['total'];

// $total = mysqli_query($conn, "Select FOUND_ROWS() as total");
// $total = mysqli_fetch_assoc($total)['total'];

//$pages = ceil($total/$perpage);
//while($row_cat=$result_cat->fetch_assoc()){

?>		

<div class="col-md-6 col-sm-6">
<div class="blog-thumb">
<figure>
<a href="blog-details.php?id=<?php //echo $row_cat['id'];?>">
<img src="../admin/uploads/<?php //echo $row_cat['image'] ?>" alt="" height="200">
</a>
</figure>
<div class="text" style="height: 250px;">

<h5>
    <a href="<?php echo base_url(); ?>blog_details?id=<?php //echo $row_cat['id'];?>" title="<?php //echo $row_cat['title'] ?>">
<?php //echo $row_cat['title'] ?>
</a>

</h5>
<p>
<?php //$str = $row_cat['description']; $string = strip_tags($str);if (strlen($string) > 200) { $stringCut = substr($string, 0, 200);$string = substr($stringCut, 0, strrpos($stringCut, ' '));}echo $string;?></p>



<em><span><?php //echo $row_cat['date'] ?></span> </em>
<em><a href="<?php base_url(); ?>blog-details?id=<?php //echo $row_cat['id'];?>">Read More</a></em>
</div>
</div>
</div>

<?php }?>
</div>
 
<!--Blog 3 Thumb Start-->
<div class="col-md-4">
    <div class="blog-thumb">
 <p><a href="Body-Spa-in-Mumbai.php" title="Body spa in Mumbai"><img src="assets/images//icon.png" width="32" height="24"">  Body spa in Mumbai</a></p>
<p><a href="Body-Spa-in-Bangalore.php" title="Spa center in Bangalore"><img src="assets/images//icon.png" width="32" height="24"">  Spa center in Bangalore</a></p>
<p><a href="Body-Spa-in-Delhi.php" title="Spa Deals in Delhi"><img src="assets/images//icon.png" width="32" height="24"">  Spa Deals in Delhi</a></p>
<p><a href="Spa-Center-in-Pune.php" title="Massage parlors in Pune"><img src="assets/images//icon.png" width="32" height="24"">  Massage parlors in Pune</a></p>
<p><a href="Spa-in-Bhopal.php" title="Spa packages in Bhopal"><img src="assets/images//icon.png" width="32" height="24"">  Spa packages in Bhopal</a></p>
<p><a href="Spa-Center-in-Jaipur.php" title="Body Massage in Jaipur"><img src="assets/images//icon.png" width="32" height="24"">  Body Massage in Jaipur</a></p>
<p><a href="Body-Spa-in-Nagpur.php" title="Female massage in Nagpur"><img src="assets/images//icon.png" width="32" height="24"">  Female massage in Nagpur</a></p>
<p><a href="Spa-in-Surat.php" title="Spa center in Surat"><img src="assets/images//icon.png" width="32" height="24"">  Spa center in Surat</a></p>
<p><a href="Spa-in-Agra.php" title="Spa service in  Agra"><img src="assets/images//icon.png" width="32" height="24"">  Spa service in  Agra  </a></p>
<p><a href="Spa-Center-in-Goa.php" title="Spa hotels in Goa"><img src="assets/images//icon.png" width="32" height="24"">  Spa hotels in Goa</a></p>
<p><a href="Spa-Center-in-Chennai.php" title="Body Spa Service in Chennai"><img src="assets/images//icon.png" width="32" height="24"">  Body Spa Service in Chennai</a>  </p> 
    </div>
</div>
<!--Blog 3 Thumb End-->

<!--Blog 3 Thumb End-->
<!--pagination-->
<div class="col-md-12">
<div class="kf-pagination">
<ul class="pagination">
<li><a class="pagination-btn" href="<?php echo base_url(); ?>blog?page=<?php //echo $page-1;?>"><?php echo '<<<';?></a>
</li>
<?php //for($i=1; $i<=$pages; $i++):?>
<li class="<?php //if($page==$i) echo "active"?>"><a href="<?php echo base_url(); ?>blog?page=<?php echo $i?>"><?php echo $i?></a>
</li>
<?php endfor;?>
<li><a class="pagination-btn" href="<?php echo base_url(); ?>blog?page=<?php //if($pages==$page){echo $page=$page;}else{echo $page+1;}?>"><?php echo '>>>';?></a>
</li>
</ul>



</div>
<!--pagination end-->
</div>
</div>
<!--Blog 3 Page Content End-->
</div>
</div>
</section>
</div>
