<!--HEADER END-->
<div class="kode-home-banner inner-banner">
<h6>Country</h6>
<i class="border-style-1"></i>
</div>
<div class="kf-banner-bar">
<div class="container">
<div class="pull-left">
<h6>Country</h6>
</div>
<div class="pull-right">
<ul class="breadcrumb">
<li><a href="<?php echo base_url(); ?>">Home</a></li>
<li><a href="<?php echo base_url(); ?>country">Country</a></li>
</ul>
</div>
</div>
</div>
<!--Home Page Banner End-->




<div class="kf_content_wrap">
<!--Massage Categories Wrap Start-->

<section>
<div class="container">
<!--Heading 1 Start-->
<div class="kf-heading-1" style="margin-bottom: 0">
<span class="icon-icon-36491"><i class="hd-bdr"></i><i class="hd-bdl"></i></span>
<h1>Country</h1>
</div>
<!--Heading 1 End-->
<div class="row">
<div class="kf_content_wrap">
<div class="blog-sidebar">
<div class="container">
<div class="row">
<!--Gallery Wrap Start-->
<div class="kf-gallery-wrap">
<!--Gallery Thumb Start-->
<hr>
<?php //echo '<pre>'; print_r($getCountry); ?>
<?php foreach($getCountry as $val){ ?>
<div class="kf-gallery-thumb col-md-3">
	<a href="<?php echo base_url(); ?>City/index/<?php echo $val['country_id']; ?>">
		<div class="kf-blog-thumb">
			<img src="<?php echo base_url(); ?>assets/images/country/<?php echo $val['image']; ?>" width="100%" height="180" alt="<?php echo $val['alt_tag']; ?>">
			<div class="text">
				<h4><?php echo $val['title']; ?></h4>
			</div>
		</div>
	</a>
</div>

<?php } ?>

</div>
</div>
</div>		
</div>
</section>
</div>

</div>
</div>
</section>
<!--Priceing Table End-->

